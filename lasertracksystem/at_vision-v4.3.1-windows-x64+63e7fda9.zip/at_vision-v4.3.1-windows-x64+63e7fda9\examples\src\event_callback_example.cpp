// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file event_callback_example.cpp
 * @brief Event callback functionality demonstration program
 *
 * This example demonstrates how to use the at_vision SDK's event callback system to subscribe to various event notifications:
 * - Connection/Disconnection events
 * - Heartbeat timeout/Recovery events
 * - Sensor error events
 * - Camera offline/Online/Error/Reconnect events
 * - Serial port error events
 * - RPC timeout/error events
 * - Server notification events
 *
 * @note Event callback thread safety:
 *       The callback function may be called in internal threads (receive thread, heartbeat thread)
 *       Users must ensure that operations in the callback function are thread-safe
 *       For example: use mutex locks to protect shared data, avoid blocking in callbacks
 *
 * @note Event subscription mechanism:
 *       - Multiple calls to setEventCallback() will override the previous callback function
 *       - clearEventCallback() can be used to unsubscribe
 *       - Callbacks will still receive related events when the connection is disconnected
 */

#include <at_vision/logging.h>
#include <at_vision/vision_core.h>
#include <chrono>
#include <iostream>
#include <thread>

using namespace at_vision;

/**
 * @brief Convert event type to string (for easy printing)
 */
std::string EventTypeToString(EventType type)
{
    switch (type)
    {
    case EventType::Connected:
        return "Connected";
    case EventType::Disconnected:
        return "Disconnected";
    case EventType::ConnectionError:
        return "ConnectionError";
    case EventType::HeartbeatTimeout:
        return "HeartbeatTimeout";
    case EventType::HeartbeatRecovered:
        return "HeartbeatRecovered";
    case EventType::SensorError:
        return "SensorError";
    case EventType::CameraOffline:
        return "CameraOffline";
    case EventType::CameraOnline:
        return "CameraOnline";
    case EventType::CameraError:
        return "CameraError";
    case EventType::CameraReconnect:
        return "CameraReconnect";
    case EventType::SerialPortError:
        return "SerialPortError";
    case EventType::RpcTimeout:
        return "RpcTimeout";
    case EventType::RpcError:
        return "RpcError";
    case EventType::ServerNotification:
        return "ServerNotification";
    default:
        return "Unknown";
    }
}

/**
 * @brief Convert timestamp to readable time string
 */
std::string TimestampToString(int64_t timestamp_ms)
{
    auto time_point = std::chrono::system_clock::time_point(std::chrono::milliseconds(timestamp_ms));
    auto time_t = std::chrono::system_clock::to_time_t(time_point);

    char buffer[100];
#ifdef _WIN32
    std::tm tm_buf{};
    ::localtime_s(&tm_buf, &time_t);
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &tm_buf);
#else
    std::tm tm_buf{};
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localtime_r(&time_t, &tm_buf));
#endif

    // Add milliseconds part
    int ms = timestamp_ms % 1000;
    return std::string(buffer) + "." + std::to_string(ms);
}

int main()
{
    // 1. Set log level
    logging::set_level(logging::Level::Debug);

    // Optional: disable console log output (recommended for production)
    // logging::disable_console();

    std::cout << "========================================\n";
    std::cout << "    at_vision Event Callback Example   \n";
    std::cout << "========================================\n\n";

    try
    {
        // 2. Create RPC client
        auto client = createVision();
        std::cout << "SDK Version: " << client->getVersion() << "\n\n";

        // 3. Set event callback function
        std::cout << "[*] Setting up event callback...\n";
        auto conf = client->getReconnectConfig();
        conf.enabled = true;
        client->setReconnectConfig(conf);
        client->setEventCallback([](const Event& event) {
            // Event callback function (may be called in internal threads, ensure thread safety)

            std::cout << "\n========== EVENT RECEIVED ==========\n";
            std::cout << "Event Type:  " << EventTypeToString(event.type) << " (" << static_cast<int>(event.type) << ")\n";
            std::cout << "Message:     " << event.message << "\n";
            std::cout << "Timestamp:   " << TimestampToString(event.timestamp) << " (" << event.timestamp << " ms)\n";

            if (!event.data_json.empty())
            {
                std::cout << "Data (JSON): " << event.data_json << "\n";
            }

            std::cout << "====================================\n\n";
        });

        // 4. Discover Sensors
        std::cout << "[*] Discovering sensors (timeout: 3 seconds)...\n";
        std::error_code discover_ec;
        auto sensors = discoverSensors(discover_ec, 3000);

        if (sensors.empty())
        {
            std::cout << "[!] No sensors found. Please check network connection.";
            if (discover_ec)
            {
                std::cout << " (" << discover_ec.message() << ")";
            }
            std::cout << "\n";
            std::cout << "[*] Press Enter to exit...\n";
            std::cin.get();
            return 1;
        }

        std::cout << "[+] Found " << sensors.size() << " sensor(s):\n";
        for (size_t i = 0; i < sensors.size(); ++i)
        {
            const auto& sensor = sensors[i];
            std::cout << "    [" << i << "] " << sensor.sensorId << " (" << sensor.sensorIp << ")"
                      << " - " << sensor.sensorType << "\n";
        }

        // 5. Connect to first sensor
        std::cout << "\n[*] Connecting to sensor: " << sensors[0].sensorId << "...\n";
        auto connectEc = client->connect(sensors[0]);

        if (connectEc)
        {
            std::cout << "[!] Failed to connect. Check the event log above.\n";
            std::cout << "[*] Press Enter to exit...\n";
            std::cin.get();
            return 1;
        }
        SerialPort sno, sno2;
        auto ec = client->getSettings()->getSerialPort(sno);
        auto setting = client->getSettings();
        auto q1 = setting->getImageQuality(ec);
        if (ec)
        {
            std::cerr << "Failed to get image quality: " << ec.message() << std::endl;
            return 1;
        }
        ec = setting->setImageQuality(ImageQuality::Compressed);
        ec = setting->setSerialPort(SerialPort::COM1);
        ec = client->getSettings()->getSerialPort(sno2);
        ec = setting->setImageTransferMode(ImageTransferMode::LaserOnly);
        auto q2 = setting->getImageQuality(ec);
        if (ec)
        {
            std::cerr << "Failed to get image quality: " << ec.message() << std::endl;
            return 1;
        }
        RobotConf config;
        ec = setting->getRobotConfig(config);
        std::cout << "Image Quality changed from " << static_cast<int>(q1) << " to " << static_cast<int>(q2) << "\n";
        std::cout << ec.message() << " sno: " << static_cast<int>(sno) << " sno2: " << static_cast<int>(sno2) << "\n";
        std::cout << "[+] Connection established (Connected event should be triggered above)\n";

        // 6. Keep connection active, wait for events
        std::cout << "\n[*] Connection active. Monitoring events...\n";
        std::cout << "    - Try disconnecting the sensor to trigger ConnectionError\n";
        std::cout << "    - Wait for heartbeat timeout (~9 seconds of no response)\n";
        std::cout << "    - Watch for server notifications\n";
        std::cout << "\n[*] Press Enter to disconnect and exit...\n";

        // Wait for user input
        std::cin.get();

        // 8. Program exit (triggers Disconnected event, but callback has been cleared, no event received)
        std::cout << "\n[*] Exiting...\n";

    } catch (const std::exception& e)
    {
        std::cerr << "[!] Exception: " << e.what() << "\n";
        return 1;
    }

    return 0;
}

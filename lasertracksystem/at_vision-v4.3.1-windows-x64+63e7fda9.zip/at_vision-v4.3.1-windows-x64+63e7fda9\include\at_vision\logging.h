// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

#pragma once

#include "at_vision/export.h"

namespace at_vision {
namespace logging {

/**
 * \~chinese @brief 日志级别枚举 \~english @brief Log level enumeration
 */
enum class Level
{
    Trace = 0,    ///< \~chinese 最详细的追踪信息 \~english Most detailed trace information
    Debug = 1,    ///< \~chinese 调试信息 \~english Debug information
    Info = 2,     ///< \~chinese 一般信息（默认） \~english General information; default level
    Warn = 3,     ///< \~chinese 警告信息 \~english Warning information
    Error = 4,    ///< \~chinese 错误信息 \~english Error information
    Critical = 5, ///< \~chinese 严重错误 \~english Critical error
    Off = 6       ///< \~chinese 关闭日志 \~english Disable logging
};

/**
 * \~chinese @brief 设置日志级别 \~english @brief Sets the log level
 * \~chinese @param level 日志级别 \~english @param level Log level
 *
 * \~chinese 日志系统会在首次使用时自动初始化，无需手动调用初始化函数。 \~english The logging system initializes automatically on first use; no manual initialization is required.
 *
 * \~chinese 默认配置： \~english Default configuration:
 * \~chinese - 日志目录：./logs \~english - Log directory: ./logs
 * \~chinese - 日志级别：Debug 模式 = Debug，Release 模式 = Info \~english - Log level: Debug in Debug builds, Info in Release builds
 * \~chinese - 控制台输出：Debug 模式默认启用，Release 模式默认关闭 \~english - Console output: enabled by default in Debug builds and disabled by default in Release builds
 * \~chinese - 文件输出：始终启用 \~english - File output: always enabled
 * \~chinese - 文件大小：10MB 轮转，保留 5 个文件 \~english - File size: rotated at 10 MB, keeping 5 files
 *
 * \~chinese 可在运行时动态调整日志详细程度： \~english The log verbosity can be adjusted at runtime:
 *
 * \~chinese 示例： \~english Example:
 * @code
 * // Use Debug level during development
 * at_vision::logging::set_level(at_vision::logging::Level::Debug);
 *
 * // Use Info level in production
 * at_vision::logging::set_level(at_vision::logging::Level::Info);
 *
 * // Disable logging completely
 * at_vision::logging::set_level(at_vision::logging::Level::Off);
 * @endcode
 */
AT_VISION_API void set_level(Level level);

/**
 * \~chinese @brief 启用控制台日志输出 \~english @brief Enables console log output
 *
 * \~chinese 在运行时动态添加控制台 sink，日志会同时输出到控制台和文件。 \~english Adds a console sink at runtime so logs are written to both console and file.
 * \~chinese 控制台 sink 会使用当前的日志级别。 \~english The console sink uses the current log level.
 *
 * \~chinese @note Debug 模式下默认已启用，Release 模式下默认关闭 \~english @note Enabled by default in Debug builds and disabled by default in Release builds
 * \~chinese @note 如果控制台输出已启用，此函数无效果 \~english @note This function has no effect if console output is already enabled
 * \~chinese @note 日志系统未初始化时会自动初始化 \~english @note The logging system is initialized automatically if needed
 *
 * \~chinese 示例： \~english Example:
 * @code
 * // Temporarily enable console logging in Release builds
 * at_vision::logging::enable_console();
 * @endcode
 */
AT_VISION_API void enable_console();

/**
 * \~chinese @brief 禁用控制台日志输出 \~english @brief Disables console log output
 *
 * \~chinese 在运行时动态移除控制台 sink，日志只会输出到文件。 \~english Removes the console sink at runtime so logs are written only to files.
 * \~chinese 适用于生产环境或后台服务场景，可减少性能开销。 \~english Useful for production or background services to reduce runtime overhead.
 *
 * \~chinese @note Debug 模式下默认启用，Release 模式下默认关闭 \~english @note Enabled by default in Debug builds and disabled by default in Release builds
 * \~chinese @note 如果控制台输出已禁用，此函数无效果 \~english @note This function has no effect if console output is already disabled
 * \~chinese @note 禁用后仍可通过 enable_console() 重新启用 \~english @note Console output can be re-enabled later with enable_console()
 *
 * \~chinese 示例： \~english Example:
 * @code
 * // Disable console output in Debug builds, for example during performance tests
 * at_vision::logging::disable_console();
 * @endcode
 */
AT_VISION_API void disable_console();
} // namespace logging
} // namespace at_vision

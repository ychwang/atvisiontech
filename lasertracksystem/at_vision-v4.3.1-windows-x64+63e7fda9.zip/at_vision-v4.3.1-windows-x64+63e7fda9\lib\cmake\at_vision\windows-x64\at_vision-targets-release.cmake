#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "at_vision::at_vision" for configuration "Release"
set_property(TARGET at_vision::at_vision APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(at_vision::at_vision PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/windows-x64/release/at_vision.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/windows-x64/release/at_vision.dll"
  )

list(APPEND _cmake_import_check_targets at_vision::at_vision )
list(APPEND _cmake_import_check_files_for_at_vision::at_vision "${_IMPORT_PREFIX}/lib/windows-x64/release/at_vision.lib" "${_IMPORT_PREFIX}/bin/windows-x64/release/at_vision.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

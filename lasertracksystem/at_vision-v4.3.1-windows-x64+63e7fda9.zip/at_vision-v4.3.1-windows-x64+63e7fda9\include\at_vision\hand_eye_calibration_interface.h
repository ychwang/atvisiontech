// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file hand_eye_calibration_interface.h
 * \~chinese @brief 手眼标定接口定义 \~english Hand-eye calibration interface definitions
 * \~english @brief Hand-eye calibration interface definitions
 */

#pragma once

#include <array>
#include <string>
#include <system_error>
#include <vector>
#include "at_vision/export.h"
#include "at_vision/type_def.h"

namespace at_vision {

// 使用通用 Pose6D / Use the common Pose6D type

/**
 * \~chinese @brief 手眼标定输入数据 \~english Hand-eye calibration input data
 * \~english @brief Hand-eye calibration input data
 *
 * \~chinese @note robot_points 和 sensor_points 均需至少 3 个点，且数量必须一致。 \~english @note robot_points and sensor_points must each contain at least 3 points, and their counts must match.
 *       \~chinese 位置单位为毫米（mm），角度单位为度（°）。 \~english Position units are millimeters (mm), and angle units are degrees.
 */
struct HandEyeCalibrationInput {
    /**
     * \~chinese @brief 从机器人读取的 TCP 相对法兰的工具偏置，单位 mm/度；不是当前 TCP 位姿。
     * \~english @brief Robot tool offset: TCP relative to flange, in mm/degrees, not the current TCP pose.
     */
    Pose6D tcp_position;
    /**
     * \~chinese @brief TCP 对准固定标定目标时，在机器人基坐标系中的位姿，单位 mm/度。
     * \~chinese @note 单独记录基点；采样期间保持此姿态与工具偏置不变。
     * \~english @brief TCP pose in the robot base frame when touching the fixed target, in mm/degrees.
     * \~english @note Record separately; keep this orientation and the tool offset throughout sampling.
     */
    Pose6D base_position;
    /**
     * \~chinese @brief 机器人坐标点集 \~english @brief Robot coordinate point set
     * \~chinese @note 至少 3 个点，且与 sensor_points 数量一致 \~english @note At least 3 points are required, and the count must match sensor_points
     */
    /**
     * \~chinese @details 由调用方从机器人控制器读取基坐标系中的 TCP 位姿；SDK 不代读机器人。
     * 第 i 项与 sensor_points[i] 对应同一次静止采样。当前服务端求解使用各项 XYZ 和基点 WPR，
     * 不使用逐点 WPR 补偿姿态变化；基点不作为额外样本加入数组。
     * \~english @details The application reads TCP poses in the base frame from the robot controller.
     * Pair entry i with sensor_points[i] from the same stationary acquisition. The current solver uses
     * sample XYZ and base orientation, not per-sample WPR to compensate rotation. Exclude the base point.
     */
    std::vector<Pose6D> robot_points;
    /**
     * \~chinese @brief 传感器识别点坐标集 \~english @brief Coordinate set of points detected by the sensor
     * \~chinese @note 至少 3 个点，且与 robot_points 数量一致 \~english @note At least 3 points are required, and the count must match robot_points
     */
    /**
     * \~chinese @details 来源：IRpcClient::setLaserSeamResultCallback() 的 result.seam_point_bd。
     * 按 {x_3d, y_3d, z_3d} 原顺序复制，单位 mm，传感器坐标系；无需交换 X/Y 或变换到机器人系。
     * 所有点观察同一固定目标，与 robot_points 逐项配对；至少三组，避免重复或共线样本。
     * 回调在内部线程执行，跨线程缓存需同步；到位后获取新鲜有效数据，不直接使用默认零值。
     * \~english @details Source: result.seam_point_bd in IRpcClient::setLaserSeamResultCallback().
     * Copy {x_3d, y_3d, z_3d} unchanged, in mm in the sensor frame; do not swap X/Y or transform to robot.
     * Observe one fixed target, pair with robot_points, and collect at least three non-collinear pairs.
     * Synchronize cross-thread caches and acquire fresh valid data after settling; do not use defaults.
     * @see LaserSeamResult::seam_point_bd
     */
    std::vector<Point3D> sensor_points;
};

/**
 * \~chinese @brief 手眼标定输出数据 \~english Hand-eye calibration output data
 * \~english @brief Hand-eye calibration output data
 *
 * \~chinese @note 输出字段说明： \~english @note Output field descriptions:
 *   \~chinese - success: 标定是否成功 \~english - success: whether calibration succeeded
 *   \~chinese - error_message: 错误信息（成功时为空） \~english - error_message: error message; empty on success
 *   \~chinese - result: 标定结果（xyzwpr 格式，Pose6D） \~english - result: calibration result (xyzwpr format, Pose6D)
 *   \~chinese - error_matrix: 误差矩阵（3x3） \~english - error_matrix: error matrix (3x3)
 */
struct HandEyeCalibrationOutput {
    /**
     * \~chinese @brief 标定是否成功 \~english @brief Whether calibration succeeded
     */
    bool success{false};
    /**
     * \~chinese @brief 错误信息（成功时为空） \~english @brief Error message; empty on success
     */
    std::string error_message;
    /**
     * \~chinese @brief 标定结果（xyzwpr 格式，Pose6D） \~english @brief Calibration result (xyzwpr format, Pose6D)
     */
    Pose6D result;
    /**
     * \~chinese @brief 误差矩阵（3x3） \~english @brief Error matrix (3x3)
     */
    std::array<std::array<double, 3>, 3> error_matrix{};
};

/**
 * \~chinese @brief 手眼标定接口 \~english Hand-eye calibration interface
 * \~chinese @details 提供最小化的手眼标定调用能力，输入一组标定数据，返回对应的标定结果数据。 \~english Provides a minimal hand-eye calibration call that accepts calibration data and returns the corresponding result.
 *
 * \~english @brief Hand-eye calibration interface
 * \~english @details Provides a minimal hand-eye calibration entry point that accepts a set of calibration input values and returns the corresponding
 * calibration result values.
 */
class AT_VISION_API IHandEyeCalibration {
public:
    virtual ~IHandEyeCalibration() = default;

    /**
     * \~chinese @brief 执行手眼标定 \~english Runs hand-eye calibration
     * \~english @brief Run hand-eye calibration
     *
     * \~chinese @param input 标定输入数据 \~english Calibration input data
     * \~english @param input Calibration input values
     * \~chinese @param[out] ec 错误码，成功时为空 error_code \~english Error code; empty error_code indicates success
     * \~english @param[out] ec Error code output. Empty on success.
     * \~chinese @return 标定输出数据，包含 success/error_message/result/error_matrix \~english Calibration output data containing success, error_message, result, and error_matrix
     * \~english @return Calibration output including success/error_message/result/error_matrix.
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~english @note This method should be called after connecting to the sensor.
     */
    virtual HandEyeCalibrationOutput calibrate(const HandEyeCalibrationInput& input, std::error_code& ec) = 0;
};

} // namespace at_vision

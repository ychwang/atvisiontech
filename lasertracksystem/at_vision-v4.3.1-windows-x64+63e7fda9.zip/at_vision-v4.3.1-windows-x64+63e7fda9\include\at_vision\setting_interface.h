// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file setting_interface.h
 * \~chinese @brief 传感器设置接口定义 \~english @brief Sensor settings interface definitions
 */

#pragma once

#include "at_vision/export.h"
#include "at_vision/type_def.h"
#include <memory>
#include <string>
#include <system_error>

namespace at_vision {

/**
 * \~chinese @brief 传感器设置接口 \~english @brief Sensor settings interface
 *
 * \~chinese 提供对传感器运行时配置的访问和修改功能，包括图像传输质量、 \~english Provides access to and modification of sensor runtime settings,
 * including image transfer quality,
 * \~chinese 传输模式以及串口配置等设置 \~english transfer mode, serial-port configuration, and related settings
 */
class AT_VISION_API ISettings {
public:
    virtual ~ISettings() = default;

    /**
     * \~chinese @brief 设置图像传输质量 \~english @brief Sets image transfer quality
     *
     * \~chinese @param quality 图像质量设置 \~english @param quality Image quality setting
     *                \~chinese - Compressed: 压缩传输，质量低，速度快 \~english - Compressed: compressed transfer with lower quality and higher speed
     *                \~chinese - Original: 原始传输，质量高，速度慢 \~english - Original: raw transfer with higher quality and lower speed
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 设置会立即生效，影响后续接收的图像 \~english @note The setting takes effect immediately and affects subsequently received
     * images
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     *
     * @code
     * auto settings = client->getSettings();
     * auto ec = settings->setImageQuality(ImageQuality::Original);
     * if (!ec) {
     *     std::cout << "图像质量设置成功" << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code setImageQuality(ImageQuality quality) = 0;

    /**
     * \~chinese @brief 获取当前图像传输质量 \~english @brief Gets the current image transfer quality
     *
     * \~chinese @return 当前的图像质量设置 \~english @return Current image quality setting
     *
     * \~chinese @param[out] ec 错误码，成功时清空 \~english @param[out] ec Error code; cleared on success
     * \~chinese @note 失败返回 Compressed，占位值不可作为实际配置使用；必须检查 ec。
     * \~english @note On failure returns Compressed as a placeholder; check ec before using the value.
     * \~chinese @note 未连接返回 NotConnected，缓存缺失返回 NotInitialized，格式错误返回 OperationFailed。
     * \~english @note Reports NotConnected, NotInitialized for missing cache, or OperationFailed for malformed data.
     */
    virtual ImageQuality getImageQuality(std::error_code& ec) const = 0;

    /**
     * \~chinese @brief 设置图像传输模式 \~english @brief Sets image transfer mode
     *
     * \~chinese @param mode 传输模式 \~english @param mode Transfer mode
     *             \~chinese - ImageOnly: 只传输图像 \~english - ImageOnly: transfer images only
     *             \~chinese - LaserOnly: 只传输激光线 \~english - LaserOnly: transfer laser lines only
     *             \~chinese - Both: 同时传输图像和激光线 \~english - Both: transfer images and laser lines together
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 设置会立即生效，影响后续传输的数据类型 \~english @note The setting takes effect immediately and affects the type of data
     * transferred later
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     *
     * @code
     * auto settings = client->getSettings();
     * auto ec = settings->setImageTransferMode(ImageTransferMode::Both);
     * if (!ec) {
     *     std::cout << "传输模式设置成功" << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code setImageTransferMode(ImageTransferMode mode) = 0;

    /**
     * \~chinese @brief 获取当前图像传输模式 \~english @brief Gets the current image transfer mode
     *
     * \~chinese @return 当前的传输模式设置 \~english @return Current transfer mode setting
     *
     * \~chinese @note 如果未连接到传感器，返回默认值 Both \~english @note If the sensor is not connected, return default value Both
     */
    virtual ImageTransferMode getImageTransferMode() const = 0;

    /**
     * \~chinese @brief 设置串口号（仅 WINDOWS_X64 平台支持） \~english @brief Sets the serial port number; supported only on WINDOWS_X64
     *
     * \~chinese @param port 串口枚举值（COM1-COM20） \~english @param port Serial port enum value (COM1-COM20)
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 仅在 WINDOWS_X64 平台的传感器上有效 \~english @note Valid only for sensors on the WINDOWS_X64 platform
     * \~chinese @note 其他平台调用此方法会返回 UnsupportedPlatform 错误 \~english @note Calling this method on other platforms returns
     * UnsupportedPlatform
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 设置后可能需要重启传感器才能生效 \~english @note The sensor may need to be rebooted for the setting to take effect
     *
     * @code
     * auto settings = client->getSettings();
     * if (sensor.platform == "WINDOWS_X64") {
     *     auto ec = settings->setSerialPort(SerialPort::COM3);
     *     if (!ec) {
     *         std::cout << "串口设置成功" << std::endl;
     *     }
     * }
     * @endcode
     */
    virtual std::error_code setSerialPort(SerialPort port) = 0;

    /**
     * \~chinese @brief 获取当前串口号（仅 WINDOWS_X64 平台支持） \~english @brief Gets the current serial port number; supported only on WINDOWS_X64
     *
     * \~chinese @param[out] port 输出串口枚举值 \~english @param[out] port Output serial port enum value
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 仅在 WINDOWS_X64 平台的传感器上有效 \~english @note Valid only for sensors on the WINDOWS_X64 platform
     * \~chinese @note 其他平台调用此方法会返回 UnsupportedPlatform 错误 \~english @note Calling this method on other platforms returns
     * UnsupportedPlatform
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     *
     * @code
     * auto settings = client->getSettings();
     * if (sensor.platform == "WINDOWS_X64") {
     *     SerialPort port;
     *     auto ec = settings->getSerialPort(port);
     *     if (!ec) {
     *         std::cout << "当前串口: COM" << static_cast<int>(port) << std::endl;
     *     }
     * }
     * @endcode
     */
    virtual std::error_code getSerialPort(SerialPort& port) const = 0;

    /**
     * \~chinese @brief 设置相机IP地址 \~english @brief Sets the camera IP address
     *
     * \~chinese @param ip 相机IP地址字符串（例如："192.168.1.100"） \~english @param ip Camera IP address string, for example "192.168.1.100"
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note IP地址需满足以下条件： \~english @note The IP address must satisfy the following conditions:
     *       \~chinese - 必须是合法 IPv4 格式（x.x.x.x，每段 0-255） \~english - Must be a valid IPv4 address in x.x.x.x format with each octet in
     * 0-255
     *       \~chinese - 必须是C类地址（192-223.x.x.x） \~english - Must be a Class C address (192-223.x.x.x)
     *       \~chinese - 不能以127开头 \~english - Must not start with 127
     *       \~chinese - 不能以1结尾 \~english - Must not end with 1
     *       \~chinese - 不能以0结尾 \~english - Must not end with 0
     *       \~chinese - 不能以255结尾 \~english - Must not end with 255
     *       \~chinese - 不能是APIPA地址（169.254.x.x） \~english - Must not be an APIPA address (169.254.x.x)
     *       \~chinese - 不能以0开头 \~english - Must not start with 0
     *       \~chinese - 不能是224.0.0.0及以上的D/E类地址 \~english - Must not be a class D/E address (224.0.0.0 and above)
     *
     * @code
     * auto settings = client->getSettings();
     * auto ec = settings->setCameraIp("192.168.1.100");
     * if (!ec) {
     *     std::cout << "相机IP设置成功" << std::endl;
     * } else {
     *     std::cerr << "设置失败: " << ec.message() << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code setCameraIp(const std::string& ip) = 0;

    /**
     * \~chinese @brief 获取当前相机IP地址 \~english @brief Gets the current camera IP address
     *
     * \~chinese @param[out] ip 输出相机IP地址字符串 \~english @param[out] ip Output camera IP address string
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 如果初始化数据中没有camera_ip字段，将返回空字符串 \~english @note Returns an empty string if the initialization data does not
     * contain camera_ip
     *
     * @code
     * auto settings = client->getSettings();
     * std::string ip;
     * auto ec = settings->getCameraIp(ip);
     * if (!ec) {
     *     std::cout << "当前相机IP: " << ip << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code getCameraIp(std::string& ip) const = 0;

    /**
     * \~chinese @brief 判断当前传感器是否支持景深范围设置 \~english @brief Checks whether the current sensor supports depth range settings

     * *
     * \~chinese @return 支持返回 true；未连接、未知型号或不支持型号返回 false
     * \~english @return true if supported; false if
     * disconnected, unknown, or unsupported
     *
     * \~chinese @note 该接口不发起 RPC，仅基于当前连接与初始化缓存判断
     * \~english @note
     * This method does not send RPC requests; it checks the current connection and initialization cache
     * \~chinese @note 仅表示设置能力；返回 false 不代表 getDepthLimits()/getDepthRange() 不可读取。
     * \~english @note Reports setting support only; false does not imply that depth reads are unavailable.
     */
    virtual bool isDepthRangeSupported() const = 0;

    /**
     * \~chinese @brief 获取当前传感器完整成像高度对应的最大景深范围 \~english @brief Gets the maximum depth limits for the full image height
     *
     * \~chinese @param[out] limits 输出景深上下限，单位为整数 mm
     * \~english @param[out] limits Output depth limits in integer millimeters

     * * \~chinese @return 错误码，成功返回空 error_code
     * \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用
     * \~english @note Call after connecting to the sensor
     * \~chinese @note 根据型号参数进行本地换算，不发起 RPC；读取不受 isDepthRangeSupported() 限制。
     * \~english @note Calculated locally from model parameters without RPC; not gated by isDepthRangeSupported().
     * \~chinese @note 型号缺少参数时返回 SettingUnsupportedPlatform；读取成功不表示允许设置景深。
     * \~english @note Missing parameters return SettingUnsupportedPlatform; reading does not imply setting support.
     * \~chinese @note 单位为 mm，端点向外取整；零点为 CMOS 中心行参考深度，不含 UI 修正或边距。
     * \~english @note Integer mm, rounded outward relative to the CMOS center-row depth; no UI correction or margins.
     */
    virtual std::error_code getDepthLimits(DepthRange& limits) const = 0;

    /**
     * \~chinese @brief 校验候选景深范围是否可用于当前传感器
     * \~english @brief Validates whether a candidate depth range can be used by
     * the current sensor
     *
     * \~chinese @param range 候选景深范围，单位为整数 mm
     * \~english @param range Candidate depth range in
     * integer millimeters
     * \~chinese @return 错误码，成功返回空 error_code
     * \~english @return Error code; an empty error_code indicates a
     * valid range
     *
     * \~chinese @note 本接口不发起 RPC，也不修改传感器或初始化缓存
     * \~english @note This method performs no RPC and
     * does not modify the sensor or initialization cache
     */
    virtual std::error_code validateDepthRange(const DepthRange& range) const = 0;

    /**
     * \~chinese @brief 设置当前使用的景深范围 \~english @brief Sets the current depth-of-field range
     *
     * \~chinese @param range 景深范围，单位为整数 mm
     * \~english @param range Depth range in integer millimeters
     * \~chinese @return
     * 错误码，成功返回空 error_code
     * \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用
     * \~english @note Call after connecting to the sensor
     * \~chinese @note 设置会换算为相机 ROI 并写入传感器配置，通常需要重启服务后完全生效
     * \~english @note The range is converted to camera ROI settings and may require service restart to fully take effect
     */
    virtual std::error_code setDepthRange(const DepthRange& range) = 0;

    /**
     * \~chinese @brief 获取当前使用的景深范围 \~english @brief Gets the current depth-of-field range
     *
     * \~chinese @param[out] range 输出当前景深范围，单位为整数 mm
     * \~english @param[out] range Output current depth range in integer
     * millimeters
     * \~chinese @return 错误码，成功返回空 error_code
     * \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用
     * \~english @note Call after connecting to the sensor
     * \~chinese @note 根据型号参数进行本地换算，不发起 RPC；读取不受 isDepthRangeSupported() 限制。
     * \~english @note Calculated locally from model parameters without RPC; not gated by isDepthRangeSupported().
     * \~chinese @note 型号缺少参数时返回 SettingUnsupportedPlatform；读取成功不表示允许设置景深。
     * \~english @note Missing parameters return SettingUnsupportedPlatform; reading does not imply setting support.
     * \~chinese @note 单位为 mm，端点向外取整；零点为 CMOS 中心行参考深度，不含 UI 修正或边距。
     * \~english @note Integer mm, rounded outward relative to the CMOS center-row depth; no UI correction or margins.
     * \~chinese @note 使用初始化缓存中的当前 ROI；缺少 ROI 数据返回 SettingRpcFailed，无效 ROI 返回 SettingInvalidValue。
     * \~english @note Uses cached ROI; missing data returns SettingRpcFailed, invalid ROI returns SettingInvalidValue.
     */
    virtual std::error_code getDepthRange(DepthRange& range) const = 0;

    /**
     * \~chinese @brief 设置机器人配置（支持部分更新） \~english @brief Sets robot configuration; partial updates are supported
     *
     *
     * \~chinese @param config 机器人配置更新信息（只更新有值的字段） \~english @param config Robot configuration update data; only fields with values
     * are updated
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 只更新RobotConfUpdate中有值（has_value）的字段 \~english @note Only fields with values in RobotConfUpdate are updated
     * \~chinese @note 可以同时设置所有字段，也可以只设置部分字段 \~english @note All fields can be set at once, or only a subset can be updated
     *
     * @code
     * auto settings = client->getSettings();
     *
     * // Example 1: set a complete configuration
     * RobotConfUpdate config;
     * config.robot_type = RobotType::Fanuc;
     * config.robot_ip = "192.168.1.100";
     * config.robot_port = 8000;
     * auto ec = settings->setRobotConfig(config);
     *
     * // Example 2: update only the IP address
     * RobotConfUpdate update;
     * update.robot_ip = "192.168.1.101";
     * ec = settings->setRobotConfig(update);
     * @endcode
     */
    virtual std::error_code setRobotConfig(const RobotConfUpdate& config) = 0;

    /**
     * \~chinese @brief 获取当前机器人配置 \~english @brief Gets the current robot configuration
     *
     * \~chinese @param[out] config 输出机器人配置信息 \~english @param[out] config Output robot configuration information
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     *
     * @code
     * auto settings = client->getSettings();
     * RobotConf config;
     * auto ec = settings->getRobotConfig(config);
     * if (!ec) {
     *     std::cout << "机器人类型: " << static_cast<int>(config.robot_type) << std::endl;
     *     std::cout << "机器人IP: " << config.robot_ip << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code getRobotConfig(RobotConf& config) const = 0;
};

} // namespace at_vision

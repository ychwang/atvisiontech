// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/** @file  type_def.h
 *  \~chinese @brief 数据类型的定义 \~english @brief enum type definitions
 **/

#pragma once

#include "at_vision/export.h"
#include <cstdint>
#include <string>
#include <vector>
#include <optional>

namespace at_vision {
/**
 * \~chinese @brief 三维点坐标 \~english 3D point coordinate
 * \~english @brief 3D point coordinate
 */
struct Point3D {
    double x{};
    double y{};
    double z{};
};

/**
 * \~chinese @brief 二维点坐标模板 \~english @brief 2D point coordinate template
 * \~chinese 用于表示任意数值类型的二维坐标点。
 * \~english Used to represent a 2D coordinate point with any numeric type.
 * \~chinese @tparam T 坐标分量类型
 * \~english @tparam T Coordinate component type
 */
template <typename T>
struct Point2DT {
    T x{}; ///< \~chinese X 坐标 \~english X coordinate
    T y{}; ///< \~chinese Y 坐标 \~english Y coordinate

    bool operator==(const Point2DT& other) const { return x == other.x && y == other.y; }

    bool operator!=(const Point2DT& other) const { return !(*this == other); }
};

template <typename T>
using Point2D = Point2DT<T>;

/**
 * \~chinese @brief 圆结构体 \~english @brief Circle structure
 */
struct CircleStruct {
    bool valid = false;   ///< \~chinese 是否有效 \~english Validity flag
    double centerX = 0.0; ///< \~chinese 圆心 X 坐标 \~english Circle center X coordinate
    double centerY = 0.0; ///< \~chinese 圆心 Y 坐标 \~english Circle center Y coordinate
    double radius = 0.0;  ///< \~chinese 半径 \~english Radius
};
/**
 * \~chinese @brief 错误类型枚举 \~english @brief Error type enumeration
 */
enum class ErrorType : uint8_t
{
    None = 0,
    General = 1,
    Timeout = 2,
    InvalidData = 3,
    // 根据需要添加更多类型 / Add more types as needed
};
// 用于微小焊缝 / Used for micro welds
struct LineInfo {
    float fSlope = 0.0f;     ///< \~chinese 斜率 \~english Slope
    float fIntercept = 0.0f; ///< \~chinese 截距 \~english Intercept
};
/**
 * \~chinese @brief 焊缝点结构体 \~english @brief Seam point structure
 */
struct SeamPoint {
    float x = 0.0f;                         ///< \~chinese 2D X 坐标 \~english 2D X coordinate
    float y = 0.0f;                         ///< \~chinese 2D Y 坐标 \~english 2D Y coordinate
    int state = 0;                          ///< \~chinese 状态 \~english State
    bool error = false;                     ///< \~chinese 是否有错误 \~english Whether an error exists
    ErrorType error_type = ErrorType::None; ///< \~chinese 错误类型 \~english Errortype

    // 3D 坐标 / 3D coordinate
    double x_3d = 0.0;
    double y_3d = 0.0;
    double z_3d = 0.0;

    // UI 坐标 / UI coordinate
    double x_ui = 0.0;
    double y_ui = 0.0;
    double z_ui = 0.0;
};

/**
 * \~chinese @brief 直线参数结构体 \~english @brief Line parameter structure
 */
struct LineParamStruct {
    double angle = 0.0;   ///< \~chinese 角度 \~english Angle
    double length = 0.0;  ///< \~chinese 长度 \~english Length
    double start_x = 0.0; ///< \~chinese 起点 X \~english Start point X
    double start_y = 0.0; ///< \~chinese 起点 Y \~english Start point Y
    double end_x = 0.0;   ///< \~chinese 终点 X \~english End point X
    double end_y = 0.0;   ///< \~chinese 终点 Y \~english End point Y
};

/**
 * \~chinese @brief 算法分析结果数据结构体（包含焊缝点、激光线、错误信息等） \~english @brief Algorithm analysis result structure containing seam
 * points, laser lines, and error information
 */
struct LaserSeamResult {
    /**
     * \~chinese @brief 激光状态 \~english @brief Laser state
     */
    enum State
    {
        UNDEFINED = -1,       ///< \~chinese 未定义 \~english Undefined
        MANUAL_CLOSE = 0b00,  ///< \~chinese 手动关闭 \~english Manually closed
        MANUAL_OPEN = 0b01,   ///< \~chinese 手动开启 \~english Manually opened
        MACHINE_CLOSE = 0b10, ///< \~chinese 机器关闭算法 \~english Machine command closes the algorithm
        MACHINE_OPEN = 0b11   ///< \~chinese 机器人开启算法 \~english Robot command opens the algorithm
    };
    SeamPoint seam_point; ///< \~chinese 焊缝点信息 \~english Seam point information

    /**
     * \~chinese
     * @brief 二维图像中的激光条纹纵向像素坐标。
     *
     * `laser[i]` 表示图像第 `i` 列中激光条纹的纵向像素坐标，对应的二维像素点为
     * `(u, v) = (i, laser[i])`，单位为像素。回调结果中的 `laser.size()` 等于图像宽度；值为 0
     * 表示该列没有有效的激光条纹点。
     *
     * \~english
     * @brief Vertical pixel coordinates of the laser stripe in the 2D image.
     *
     * `laser[i]` is the vertical pixel coordinate of the laser stripe in image column `i`. The corresponding
     * 2D pixel is `(u, v) = (i, laser[i])`, measured in pixels. In callback results, `laser.size()` equals the
     * image width; a value of 0 indicates that the column has no valid laser stripe point.
     */
    std::vector<int> laser;
    /**
     * \~chinese
     * @brief 轮廓 3D 坐标，按坐标分量存储而非按点存储。
     *
     * `laser_3D[row][index]` 表示第 `index` 个轮廓点的一个坐标分量：`row` 为 0、1、2 时分别为 X、Y、Z。
     * 自动扫描和点云转换均按此约定将第 `index` 个点组合为
     * `{laser_3D[0][index], laser_3D[1][index], laser_3D[2][index]}`。三个数组等长时，点数为
     * `laser_3D[0].size()`；调用方应先确认三个数组存在且等长。
     * \~english
     * @brief Profile 3D coordinates stored by coordinate component, not by point.
     *
     * `laser_3D[row][index]` is one coordinate of contour point `index`: rows 0, 1, and 2 represent X, Y,
     * and Z respectively. Automatic scanning and point-cloud conversion form point `index` as
     * `{laser_3D[0][index], laser_3D[1][index], laser_3D[2][index]}`. When all three arrays have equal length,
     * the point count is `laser_3D[0].size()`; confirm that they exist and have equal length before use.
     */
    std::vector<std::vector<double>> laser_3D;
    std::vector<std::vector<double>> laser_3D_real; ///< \~chinese 用于先验坐标转换 \~english Used for prior coordinate conversion
    std::vector<std::vector<double>> laser_3d_fpga; ///< \~chinese FPGA 3D 坐标 \~english FPGA 3D coordinates

    int mid_index = 0;                             ///< \~chinese 微小焊缝中间点 \~english Micro weld midpoint
    std::vector<LineInfo> vec_line_all;            ///< \~chinese 微小焊缝斜率和截距 \~english Slope and intercept for micro welds
    std::vector<int> seam_line;                    ///< \~chinese 微小焊缝线 \~english Micro weld line
    std::vector<std::vector<double>> seam_line_3D; ///< \~chinese 微小焊缝线 3D 坐标 \~english 3D coordinates of the micro weld line
    SeamPoint point_roi_start;                     ///< \~chinese 微小焊缝 ROI 起点 \~english Micro weld ROI start point
    SeamPoint point_roi_end;                       ///< \~chinese 微小焊缝 ROI 终点 \~english Micro weld ROI end point

    double angle_3D = 0.0;
    double thickness_3D = 0.0;
    double weld_area = 0.0; ///< \~chinese 焊缝面积 \~english Weld area
    double gap_3D = 0.0;

    SeamPoint seam_point_1;
    SeamPoint seam_point_2;
    /**
     * \~chinese
     * @brief 手眼标定特征点（BD：标定），由传感器结果报文提供。
     * @details 在 IRpcClient::setLaserSeamResultCallback() 回调中读取本字段，将
     * x_3d、y_3d、z_3d 按原顺序复制到 HandEyeCalibrationInput::sensor_points。
     * 三维坐标位于传感器坐标系，单位 mm；不要使用二维 x/y、UI 坐标或自行交换坐标轴。
     * 每个点须与同次静止采样的机器人 TCP 位姿配对，所有采样观察同一个固定目标。
     * @note 当前接收器仅填充本字段的三个 *_3d 分量；state/error 的默认值不证明采样有效。
     * 应确认有效 JOB、开光、目标识别及新鲜数据，并检查坐标为有限数。
     * @see HandEyeCalibrationInput::sensor_points
     * \~english
     * @brief Hand-eye calibration feature point (BD means calibration), supplied by sensor result packets.
     * @details Read this field in IRpcClient::setLaserSeamResultCallback() and copy x_3d, y_3d, z_3d
     * in order into HandEyeCalibrationInput::sensor_points. Coordinates are in the sensor frame, in mm.
     * Do not use pixel x/y or UI coordinates, or swap axes. Pair each point with the robot TCP pose
     * from the same stationary acquisition; observe the same fixed target throughout calibration.
     * @note The receiver fills only the three *_3d components here; default state/error values do not
     * prove validity. Check the active JOB, laser, target detection, freshness and finite coordinates.
     * @see HandEyeCalibrationInput::sensor_points
     */
    SeamPoint seam_point_bd;

    int weld_type = 0; ///< \~chinese 焊缝类型 \~english Seam type

    std::vector<LineParamStruct> lines = {};          ///< \~chinese 直线算法参数 \~english Line algorithm parameters
    bool show_all_lines = false;                      ///< \~chinese 是否显示全部直线 \~english Whether to show all lines
    std::vector<LineParamStruct> lines_computed = {}; ///< \~chinese 计算得到的直线参数 \~english Computed line parameters

    std::vector<int> line_points; ///< \~chinese 直线算法端点 \~english Line algorithm endpoint

    std::vector<CircleStruct> result_circle; ///< \~chinese 直线圆弧算法结果 \~english Line circle algorithm result
    int error_code = 0;                      ///< \~chinese 错误码 \~english Error code

    /** \~chinese @brief 当前任务编号 \~english @brief Current Job number */
    int current_job_no = 0;
    int job_weld_type = 0;
    State laser_state = State::UNDEFINED; ///< \~chinese 激光状态 \~english Laser state
    bool robot_connected = false;         ///< \~chinese 机器人连接状态 \~english Robot connection state
    std::string job_name;
};

/**
 * \~chinese @brief 传感器型号枚举（如 aTrac150/aTrac250/aTrac400 等） \~english @brief Sensor model enumeration, such as aTrac150, aTrac250, and
 * aTrac400
 */
enum class SensorModelType : int
{
    None = 0, ///< \~chinese 未知或未提供 \~english Unknown or not provided
    ATrac150 = 1,
    ATrac250 = 2,
    ATrac400 = 3,
    ATrac2D = 4,
    ATrac250H = 5,
    ATrac250W = 6,
    ATrac400G = 7,
    ATrac250C = 8,
    ATrac400GH = 9,
    ATrac250WEO = 10, ///< \~chinese aTrac-250WEO 型号 \~english aTrac-250WEO model
    ATrac250WE = 11   ///< \~chinese aTrac-250WE 型号 \~english aTrac-250WE model
};

/**
 * \~chinese @brief 传感器搜索返回的连接状态枚举
 * \~english @brief Connection status reported by sensor discovery responses
 */
enum class SensorStatus : int
{
    Unknown = -1,         ///< \~chinese 未知或未提供 \~english Unknown or not provided
    NotInSameNetwork = 0, ///< \~chinese 与本机不在同一网段 \~english Not in the same subnet as the host
    SensorNormal = 1,              ///< \~chinese 正常，可连接 \~english Normal and connectable
    SensorOccupied = 2,            ///< \~chinese 被其他 UI 占用 \~english Occupied by another UI
    CameraModuleDisconnected = 6   ///< \~chinese 相机模组未连接，仍可连接 \~english Camera module disconnected but still connectable
};

/**
 * \~chinese @brief 传感器信息结构体 \~english @brief Sensor information structure
 */
struct SensorInfo {
    std::string sensorId;   ///< \~chinese 传感器唯一标识 \~english Unique sensor identifier
    std::string sensorIp;   ///< \~chinese 传感器 IP 地址 \~english Sensor IP address
    std::string platform;   ///< \~chinese 传感器运行平台 \~english Sensor runtime platform
    std::string macAddress; ///< \~chinese 传感器 MAC 地址 \~english Sensor MAC address
    /**
     * \~chinese @brief 传感器类别字符串（设备广播原始字段）
     * \~english @brief Sensor type string from the raw device broadcast field
     */
    std::string sensorType;
    SensorModelType sensorModelType = SensorModelType::None; ///< \~chinese 传感器型号枚举 \~english Sensor model type
    /**
     * \~chinese @brief 传感器搜索返回的连接状态
     * \~english @brief Connection status reported by the sensor discovery response
     */
    SensorStatus sensorStatus = SensorStatus::Unknown;
    std::string subnetMask;            ///< \~chinese 子网掩码 \~english Subnet mask
    std::string gateway;               ///< \~chinese 网关地址 \~english Gateway address
    std::string softwareVersionNumber; ///< \~chinese 软件版本号 \~english Software version number
    std::string firmwareVersionNumber; ///< \~chinese 固件版本号 \~english Firmware version number
    int cameraWidth = 0;               ///< \~chinese 相机图像宽度 \~english Camera image width
    int cameraHeight = 0;              ///< \~chinese 相机图像高度 \~english Camera image height
    int resWidth = 0;                  ///< \~chinese 输出分辨率宽度 \~english Output resolution width
    int resHeight = 0;                 ///< \~chinese 输出分辨率高度 \~english Output resolution height
    /**
     * \~chinese @brief 图像传输质量，0 表示压缩传输，1 表示原始传输
     * \~english @brief Image transfer quality: 0 means compressed transfer, 1 means original transfer
     */
    int imageQuality = 0;
    /**
     * \~chinese @brief 接收该搜索响应的本机网卡 IP 地址
     * \~english @brief Local network interface IP address that received this discovery response
     */
    std::string localIp;
    /**
     * \~chinese @brief 该搜索响应 UDP 报文的发送端 IP 地址
     * \~english @brief UDP peer IP address that sent this discovery response
     */
    std::string peerIp;
    /**
     * \~chinese @brief 是否来自嵌入式独立广播进程
     * \~chinese @details 仅当设备回包同时包含数据库连接状态与激光服务运行状态字段时为 true。
     * \~english @brief Whether the response came from the embedded standalone broadcast process
     * \~english @details This is true only when the device response contains both database connection
     * status and laser service running status fields.
     */
    bool standaloneBroadcast = false;
    /**
     * \~chinese @brief 设备 eMMC 序列号
     * \~chinese @details 该字段来自独立广播回包；普通搜索回包未提供时为空字符串。
     * \~english @brief Device eMMC serial number
     * \~english @details This field comes from standalone broadcast responses and remains empty when
     * ordinary discovery responses do not provide it.
     */
    std::string emmcSerial;
    /**
     * \~chinese @brief 设备端数据库连接状态
     * \~chinese @details 该字段来自独立广播回包；未提供时默认 false。
     * \~english @brief Device-side database connection status
     * \~english @details This field comes from standalone broadcast responses and defaults to false
     * when it is not provided.
     */
    bool dbConnected = false;
    /**
     * \~chinese @brief 设备端激光服务运行状态
     * \~chinese @details 该字段来自独立广播回包；未提供时默认 false。
     * \~english @brief Device-side laser service running status
     * \~english @details This field comes from standalone broadcast responses and defaults to false
     * when it is not provided.
     */
    bool laserServiceRunning = false;
};

/**
 * \~chinese @brief 事件类型枚举 \~english @brief Event type enumeration
 */
enum class EventType : int
{
    Unknown = -1, ///< \~chinese 未知事件类型 \~english Unknown event type
    // ========== 连接相关事件 / Connection-related events ==========
    Connected = 0,       ///< \~chinese 连接成功 \~english Connection success
    Disconnected = 1,    ///< \~chinese 连接断开 \~english Connection disconnected
    ConnectionError = 2, ///< \~chinese 连接错误 \~english Connection error

    // ========== 心跳相关事件 / Heartbeat-related events ==========
    HeartbeatTimeout = 10,   ///< \~chinese 心跳超时 \~english Heartbeat timeout
    HeartbeatRecovered = 11, ///< \~chinese 心跳恢复 \~english Heartbeat recovery

    // ========== 传感器相关事件 / Sensor-related events ==========
    SensorError = 20,     ///< \~chinese 传感器错误 \~english Sensor error
    CameraOffline = 21,   ///< \~chinese 相机掉线 \~english Camera offline
    CameraOnline = 22,    ///< \~chinese 相机上线 \~english Camera online
    CameraError = 23,     ///< \~chinese 相机操作错误（曝光/初始化/关闭等） \~english Camera operation error (exposure/init/close etc.)
    CameraReconnect = 24, ///< \~chinese 相机重连中；清除通知映射为 CameraOnline \~english Camera reconnecting; clear maps to CameraOnline

    // ========== 串口相关事件 / Serial-port-related events ==========
    SerialPortError = 30, ///< \~chinese 串口错误 \~english Serial port error

    // ========== RPC 相关事件 / RPC-related events ==========
    RpcTimeout = 40, ///< \~chinese RPC 调用超时 \~english RPC call timeout
    RpcError = 41,   ///< \~chinese RPC 调用错误 \~english RPC call error

    // ========== 服务端通知 / Server notification ==========
    ServerNotification = 50 ///< \~chinese 服务端主动推送的通知 \~english Notification pushed by the server
};

/**
 * \~chinese @brief 事件数据结构体 \~english @brief Event data structure
 */
struct Event {
    EventType type = EventType::Unknown; ///< \~chinese 事件类型，默认 Unknown \~english Event type; defaults to Unknown
    std::string message;                 ///< \~chinese 事件消息（人类可读的描述） \~english Event message; human-readable description
    int64_t timestamp = 0; ///< \~chinese 时间戳（毫秒，自 1970-01-01 00:00:00 UTC） \~english Timestamp in milliseconds since 1970-01-01 00:00:00 UTC
    std::string data_json; ///< \~chinese 附加数据（JSON 格式字符串，可选） \~english Additional data as an optional JSON string
};

/**
 * \~chinese @brief 自动重连配置结构体 \~english @brief Auto-reconnect configuration structure
 */
struct ReconnectConfig {
    bool enabled = false; ///< \~chinese 是否启用自动重连（默认关闭） \~english Whether auto reconnect is enabled; disabled by default
    int maxAttempts =
        3; ///< \~chinese 最大重连尝试次数（默认 3 次，-1 表示无限重连） \~english Maximum reconnect attempts; default is 3, and -1 means unlimited
    int intervalMs = 5000;       ///< \~chinese 重连间隔（毫秒，默认 5 秒） \~english Reconnect interval in milliseconds; default is 5 seconds
    bool backoffEnabled = false; ///< \~chinese 是否启用指数退避（每次重连间隔翻倍） \~english Whether exponential backoff is enabled; the interval
                                 ///< doubles after each attempt
    int maxIntervalMs = 60000;   ///< \~chinese 最大重连间隔（毫秒，默认 60 秒，仅在启用退避时有效） \~english Maximum reconnect interval in
                                 ///< milliseconds; default is 60 seconds and only applies when backoff is enabled
};

/**
 * \~chinese @brief 心跳检测配置结构体 \~english @brief Heartbeat detection configuration structure
 */
struct HeartbeatConfig {
    int intervalMs = 3000; ///< \~chinese 心跳发送间隔（毫秒，默认 3 秒） \~english Heartbeat interval in milliseconds; default is 3 seconds
    int timeoutMs = 2000;  ///< \~chinese 单次心跳 RPC 超时（毫秒，默认 2 秒） \~english Heartbeat RPC timeout in milliseconds; default is 2 seconds
    int maxFailCount = 3;  ///< \~chinese 连续失败次数阈值（默认 3 次） \~english Consecutive failure threshold; default is 3
};

/**
 * \~chinese @brief 图像传输质量枚举 \~english @brief Image transfer quality enumeration
 */
enum class ImageQuality : int
{
    Compressed = 0, ///< \~chinese 压缩传输（质量低，速度快） \~english Compressed transfer with lower quality and higher speed
    Original = 1    ///< \~chinese 原始传输（质量高，速度慢） \~english Original transfer with higher quality and lower speed
};

/**
 * \~chinese @brief 图像传输模式枚举 \~english @brief Image transfer mode enumeration
 */
enum class ImageTransferMode : int
{
    ImageOnly = 0, ///< \~chinese 只传输图像 \~english Transfer images only
    LaserOnly = 1, ///< \~chinese 只传输激光线 \~english Transfer laser lines only
    Both = 2       ///< \~chinese 同时传输图像和激光线,默认使用此模式 \~english Transfer images and laser lines together; this is the default mode
};

/**
 * \~chinese @brief 串口号枚举（仅 WINDOWS_X64 平台支持） \~english @brief Serial port enumeration supported only on WINDOWS_X64
 *
 * \~chinese 定义了 COM1 到 COM20 的串口号，用于传感器串口配置 \~english Defines COM1 through COM20 serial port numbers for sensor serial-port
 * configuration
 */
enum class SerialPort : int
{
    COM1 = 0,   ///< \~chinese 串口 1 \~english Serial port 1
    COM2 = 1,   ///< \~chinese 串口 2 \~english Serial port 2
    COM3 = 2,   ///< \~chinese 串口 3 \~english Serial port 3
    COM4 = 3,   ///< \~chinese 串口 4 \~english Serial port 4
    COM5 = 4,   ///< \~chinese 串口 5 \~english Serial port 5
    COM6 = 5,   ///< \~chinese 串口 6 \~english Serial port 6
    COM7 = 6,   ///< \~chinese 串口 7 \~english Serial port 7
    COM8 = 7,   ///< \~chinese 串口 8 \~english Serial port 8
    COM9 = 8,   ///< \~chinese 串口 9 \~english Serial port 9
    COM10 = 9,  ///< \~chinese 串口 10 \~english Serial port 10
    COM11 = 10, ///< \~chinese 串口 11 \~english Serial port 11
    COM12 = 11, ///< \~chinese 串口 12 \~english Serial port 12
    COM13 = 12, ///< \~chinese 串口 13 \~english Serial port 13
    COM14 = 13, ///< \~chinese 串口 14 \~english Serial port 14
    COM15 = 14, ///< \~chinese 串口 15 \~english Serial port 15
    COM16 = 15, ///< \~chinese 串口 16 \~english Serial port 16
    COM17 = 16, ///< \~chinese 串口 17 \~english Serial port 17
    COM18 = 17, ///< \~chinese 串口 18 \~english Serial port 18
    COM19 = 18, ///< \~chinese 串口 19 \~english Serial port 19
    COM20 = 19  ///< \~chinese 串口 20 \~english Serial port 20
};

/**
 * \~chinese @brief 机器人类型枚举 \~english @brief Robot type enumeration
 *
 * \~chinese 定义了支持的所有机器人品牌和型号 \~english Defines all supported robot brands and models
 */
enum class RobotType : int
{
    None = 0,             ///< \~chinese 无机器人 \~english No robot
    Fanuc = 1,            ///< \~chinese 发那科 \~english Fanuc
    GSK = 2,              ///< \~chinese 广数GSK \~english GSK
    Xinsida = 3,          ///< \~chinese 新时达 \~english Xinsida
    Qianjiang = 4,        ///< \~chinese 钱江 \~english Qianjiang
    AotaiTcpIp = 5,       ///< \~chinese 奥太Tcp/Ip \~english AotaiTcp/Ip
    AotaiModbus = 6,      ///< \~chinese 奥太Modbus \~english AotaiModbus
    EFORT = 7,            ///< \~chinese EFORT机器人 \~english EFORT robot
    Other = 8,            ///< \~chinese 其他 \~english Other
    Nabot = 9,            ///< \~chinese 纳博特 \~english Nabot
    Yaskawa = 10,         ///< \~chinese 安川 \~english Yaskawa
    Kawasaki = 11,        ///< \~chinese 川崎 \~english Kawasaki
    Zhiliuxing = 12,      ///< \~chinese 智流形 \~english Zhiliuxing
    AotaiLibModbus = 13,  ///< \~chinese 奥太libModbus \~english Aotai libModbus
    Daniu = 14,           ///< \~chinese 大牛机器人 \~english Daniu robot
    Estun = 15,           ///< \~chinese 埃斯顿 \~english Estun
    Siasun = 16,          ///< \~chinese 新松机器人 \~english Siasun robot
    KUKA = 17,            ///< \~chinese KUKA机器人 \~english KUKA robot
    Kaindi = 18,          ///< \~chinese 凯恩帝系统 \~english Kaindi system
    Mufei = 19,           ///< \~chinese 牧菲系统 \~english Mufei system
    Canopus = 20,         ///< \~chinese 卡诺普机器人 \~english Canopus robot
    ABB = 21,             ///< ABB
    Chaifu = 22,          ///< \~chinese 柴孚机器人 \~english Chaifu robot
    Chuanxi = 23,         ///< \~chinese 传习机器人 \~english Chuanxi robot
    AUBO = 24,            ///< \~chinese AUBO机器人 \~english AUBO robot
    Xinkong = 25,         ///< \~chinese 新控机器人 \~english Xinkong robot
    Yunhua = 26,          ///< \~chinese 云华机器人 \~english Yunhua robot
    CanopusB = 27,        ///< \~chinese 卡诺普B \~english CanopusB
    YaskawaAT = 28,       ///< \~chinese 安川AT \~english YaskawaAT
    KUKAB = 29,           ///< \~chinese 库卡B \~english KUKAB
    Brant = 30,           ///< \~chinese 伯朗特 \~english Brant
    PipelineSpecial = 31, ///< \~chinese 管道专用 \~english Pipeline special
    ATXD = 32,            ///< ATXD
    HRG = 33,             ///< \~chinese 哈工现代 \~english HRG
    Luoshi = 34,          ///< \~chinese 珞石机器人 \~english Luoshi robot
    Canopus25 = 35,       ///< \~chinese 卡诺普2.5 \~english Canopus2.5
    PipelineTrolley = 36, ///< \~chinese 管道小车 \~english Pipeline trolley
    GGX = 37,             ///< \~chinese 国工信 \~english Guogongxin
    BCEBD = 38,           ///< \~chinese 博创尔必地 \~english Bochuang Erbidi
    ChaifuSelf = 39,      ///< \~chinese 柴孚自研系统 \~english Chaifu in-house system
    Huayan = 40,          ///< \~chinese 华沿机器人 \~english Huayan robot
    HikRobot = 41,        ///< \~chinese 海康机器人 \~english Hikrobot
    Panasonic = 42        ///< \~chinese 松下机器人 \~english Panasonic robot
};

/**
 * \~chinese @brief 机器人配置结构体 \~english @brief Robot configuration structure
 *
 * \~chinese 用于存储机器人通信和控制相关的配置参数 \~english Stores configuration parameters related to robot communication and control
 *
 * \~chinese @note robot_ip + robot_port 表示机器人通信端点。
 * \~english @note robot_ip and robot_port identify the robot communication endpoint.
 *
 * \~chinese @note station_number 仅用于支持 UNITID 的机器人类型。
 * \~english @note station_number is used only by UNITID-capable robot types.
 */
struct RobotConf {
    RobotType robot_type = RobotType::None; ///< \~chinese 机器人类型 \~english Robot type
    std::string robot_ip;                   ///< \~chinese 机器人IP地址（TCP/IP通信使用） \~english Robot IP address used for TCP/IP communication
    int robot_port = 0;                     ///< \~chinese 机器人通信端口 \~english Robot communication port
    int station_number =
        0;                 ///< \~chinese 站号/从站ID（支持 UNITID 的机器人使用） \~english Station number/slave ID used by UNITID-capable robot types
    int protocol_type = 0; ///< \~chinese 通信协议类型（0:普通端口, 1:支持UNITID, 2:其他） \~english Communication protocol type: 0 for
                           ///< standard port, 1 for UNITID-capable, 2 for other protocols
};

/**
 * \~chinese @brief 机器人配置更新结构体 \~english @brief Robot configuration update structure
 *
 * \~chinese 用于部分更新机器人配置，只更新有值的字段 \~english Used for partial robot configuration updates; only fields with values are updated
 * \~chinese 使用 std::optional 包装每个字段，未赋值的字段不会更新 \~english Uses std::optional for each field; fields without values are not updated
 *
 * @code
 * RobotConfUpdate update;
 * update.robot_ip = "192.168.1.100";  // update.robot_ip = "192.168.1.100"; only updates IP, other fields remain unchanged
 * @endcode
 */
struct RobotConfUpdate {
    std::optional<RobotType> robot_type; ///< \~chinese 机器人类型（可选） \~english Robot type (optional)
    std::optional<std::string> robot_ip; ///< \~chinese 机器人IP地址（可选） \~english Robot IP address (optional)
    std::optional<int> robot_port;       ///< \~chinese 机器人通信端口（可选） \~english Robot communication port; optional
    std::optional<int> station_number;   ///< \~chinese 站号/从站ID（可选） \~english Station number/slave ID (optional)
};

/**
 * \~chinese @brief 图像格式类型枚举 \~english @brief Image format type enumeration
 * \~chinese 图像格式类型枚举
 * \~english Image format type enumeration
 */
enum class ImageType : int
{
    RAW = 0, ///< \~chinese RAW格式（8位灰度图，原始图像） \~english RAW format (8-bit grayscale, original image)
    JPG = 1  ///< \~chinese JPG格式（压缩图像） \~english JPG format (compressed image)
};

/**
 * \~chinese @brief 图像数据结构体 \~english @brief Image data structure
 * \~chinese 图像数据结构体
 * \~english Image data structure
 */
struct Image {
    int width = 0;                   ///< \~chinese 图像宽度 \~english Image width
    int height = 0;                  ///< \~chinese 图像高度 \~english Image height
    ImageType type = ImageType::JPG; ///< \~chinese 图像格式类型（默认BMP） \~english Image format type (default BMP)
    std::vector<uint8_t> data;       ///< \~chinese 图像数据（按行优先存储） \~english Image data (stored in row-major order)
};

/**
 * \~chinese @brief 景深范围结构体 \~english @brief Depth-of-field range structure
 * \~chinese 景深范围结构体
 * \~english Depth range structure
 *
 * \~chinese 用于表示景深的上下限或当前使用范围，单位 mm，取整数边界
 * \~english Used to represent the upper/lower limits or current depth range in
 * integer millimeters
 */
struct DepthRange {
    int min = 0; ///< \~chinese 下限（或当前范围的最小值），单位 mm \~english Lower limit in mm
    int max = 0; ///< \~chinese 上限（或当前范围的最大值），单位 mm \~english Upper limit in mm
};

/**
 * \~chinese @brief 六自由度位姿（xyzwpr） \~english 6-DoF pose (xyzwpr)
 * \~english @brief 6-DoF pose in xyzwpr format
 */
struct Pose6D {
    double x{};
    double y{};
    double z{};
    double w{};
    double p{};
    double r{};
};
} // namespace at_vision

// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file line_template_example.cpp
 * @brief Line template weld configuration example.
 *
 * This example demonstrates the workflow for creating a LineTemplate job:
 * - Discover sensors and connect.
 * - Create a process and a LineTemplate job.
 * - Enable laser and collect one profile frame.
 * - Pass selected LaserSeamResult feature/profile indexes to the SDK template helper.
 * - Save local template images rendered from
 *
 * LaserSeamResult::laser.
 * - Update line template parameters with JointLineTemplateAlgoInfoUpdate.
 * - Read the job back and
 * verify that the
 * template string was stored.
 *
 * @note JointLineTemplateAlgoTemplate follows the UI template creation rules. Feature points come
 * from
 * LaserSeamResult::line_points, selected points come from the laser/profile index list, and
 * serialization derives the legacy
 * line_combine_templete_string plus default L/C constraints.
 */

#include <at_vision/algorithm_interface.h>
#include <at_vision/algorithm_type_def.h>
#include <at_vision/logging.h>
#include <at_vision/type_def.h>
#include <at_vision/vision_core.h>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

using namespace at_vision;

namespace {

void printSeparator(const std::string& title)
{
    std::cout << "\n========== " << title << " ==========\n" << std::endl;
}

std::vector<int> parseIntList(const std::string& text)
{
    std::vector<int> values;
    std::stringstream stream(text);
    std::string item;
    while (std::getline(stream, item, ','))
    {
        item.erase(std::remove_if(item.begin(), item.end(), [](unsigned char ch) { return std::isspace(ch) != 0; }), item.end());
        if (!item.empty())
        {
            values.push_back(std::stoi(item));
        }
    }
    return values;
}

double clampValue(double value, double lower, double upper)
{
    return (std::min)((std::max)(value, lower), upper);
}

bool writePpmFile(const std::vector<unsigned char>& pixels, int width, int height, const std::filesystem::path& path)
{
    std::ofstream file(path, std::ios::binary);
    if (!file)
    {
        std::cerr << "Error: failed to open PPM file for writing: " << path.string() << std::endl;
        return false;
    }

    file << "P6\n" << width << " " << height << "\n255\n";
    file.write(reinterpret_cast<const char*>(pixels.data()), static_cast<std::streamsize>(pixels.size()));
    return file.good();
}

int estimateLaserImageHeight(const std::vector<int>& laser)
{
    std::vector<int> positiveValues;
    positiveValues.reserve(laser.size());
    for (const int value : laser)
    {
        if (value > 0)
        {
            positiveValues.push_back(value);
        }
    }

    if (positiveValues.empty())
    {
        return 720;
    }

    std::sort(positiveValues.begin(), positiveValues.end());
    const size_t p95Index = (std::min)(positiveValues.size() - 1, positiveValues.size() * 19 / 20);
    return static_cast<int>(clampValue(static_cast<double>(positiveValues[p95Index] + 80), 360.0, 1080.0));
}

bool saveLaserTemplatePpm(const LaserSeamResult& result,
                          const std::vector<int>& pointIndexes,
                          const std::filesystem::path& fullPath,
                          const std::filesystem::path& roiPath)
{
    if (result.laser.empty())
    {
        std::cerr << "Warning: laser 2D profile is empty; local template images were not saved." << std::endl;
        return false;
    }

    const int width = static_cast<int>(result.laser.size());
    const int height = estimateLaserImageHeight(result.laser);
    std::vector<unsigned char> pixels(static_cast<size_t>(width * height * 3), 0x36);

    const auto setPixel = [&](int x, int y, unsigned char r, unsigned char g, unsigned char b) {
        if (x < 0 || y < 0 || x >= width || y >= height)
        {
            return;
        }
        const size_t offset = static_cast<size_t>((y * width + x) * 3);
        pixels[offset + 0] = r;
        pixels[offset + 1] = g;
        pixels[offset + 2] = b;
    };

    const auto drawDisk = [&](int cx, int cy, int radius, unsigned char r, unsigned char g, unsigned char b) {
        for (int dy = -radius; dy <= radius; ++dy)
        {
            for (int dx = -radius; dx <= radius; ++dx)
            {
                if (dx * dx + dy * dy <= radius * radius)
                {
                    setPixel(cx + dx, cy + dy, r, g, b);
                }
            }
        }
    };

    const auto drawLine = [&](int x0, int y0, int x1, int y1, unsigned char r, unsigned char g, unsigned char b) {
        const int dx = std::abs(x1 - x0);
        const int sx = x0 < x1 ? 1 : -1;
        const int dy = -std::abs(y1 - y0);
        const int sy = y0 < y1 ? 1 : -1;
        int err = dx + dy;
        while (true)
        {
            drawDisk(x0, y0, 1, r, g, b);
            if (x0 == x1 && y0 == y1)
            {
                break;
            }
            const int e2 = 2 * err;
            if (e2 >= dy)
            {
                err += dy;
                x0 += sx;
            }
            if (e2 <= dx)
            {
                err += dx;
                y0 += sy;
            }
        }
    };

    const auto toLaserPixel = [&](int index) {
        const int x = static_cast<int>(clampValue(static_cast<double>(index), 0.0, static_cast<double>(width - 1)));
        const int y = static_cast<int>(clampValue(static_cast<double>(result.laser[static_cast<size_t>(x)]), 0.0, static_cast<double>(height - 3)));
        return std::pair<int, int>{x, y};
    };

    for (size_t i = 1; i < result.laser.size(); ++i)
    {
        if (result.laser[i - 1] <= 0 || result.laser[i] <= 0)
        {
            continue;
        }
        const auto [x0, y0] = toLaserPixel(static_cast<int>(i - 1));
        const auto [x1, y1] = toLaserPixel(static_cast<int>(i));
        drawLine(x0, y0, x1, y1, 255, 0, 0);
    }

    std::vector<std::pair<int, int>> selectedPixels;
    selectedPixels.reserve(pointIndexes.size());
    for (const int featureIndex : result.line_points)
    {
        if (featureIndex < 0 || static_cast<size_t>(featureIndex) >= result.laser.size())
        {
            continue;
        }

        const auto [x, y] = toLaserPixel(featureIndex);
        drawDisk(x, y, 6, 255, 255, 255);
        drawDisk(x, y, 3, 0x36, 0x36, 0x36);
    }

    for (const int index : pointIndexes)
    {
        if (index < 0 || static_cast<size_t>(index) >= result.laser.size())
        {
            std::cerr << "Warning: point index " << index << " is outside laser 2D range [0," << result.laser.size() << ")." << std::endl;
            continue;
        }
        selectedPixels.push_back(toLaserPixel(index));
    }

    for (size_t i = 0; i + 1 < selectedPixels.size(); i += 2)
    {
        drawLine(selectedPixels[i].first, selectedPixels[i].second, selectedPixels[i + 1].first, selectedPixels[i + 1].second, 25, 118, 210);
    }
    for (size_t i = 0; i < selectedPixels.size(); ++i)
    {
        const auto [x, y] = selectedPixels[i];
        drawDisk(x, y, i % 2 == 0 ? 7 : 5, i % 2 == 0 ? 245 : 255, i % 2 == 0 ? 190 : 255, i % 2 == 0 ? 0 : 255);
    }

    if (!writePpmFile(pixels, width, height, fullPath))
    {
        return false;
    }

    if (selectedPixels.empty())
    {
        return true;
    }

    int minX = selectedPixels.front().first;
    int maxX = selectedPixels.front().first;
    int minY = selectedPixels.front().second;
    int maxY = selectedPixels.front().second;
    for (const auto& pixel : selectedPixels)
    {
        minX = (std::min)(minX, pixel.first);
        maxX = (std::max)(maxX, pixel.first);
        minY = (std::min)(minY, pixel.second);
        maxY = (std::max)(maxY, pixel.second);
    }

    const int leftBorder = 20;
    const int rightBorder = 20;
    const int topBorder = 80;
    const int bottomBorder = 20;
    minX = (std::max)(0, minX - leftBorder);
    maxX = (std::min)(width - 1, maxX + rightBorder);
    minY = (std::max)(0, minY - topBorder);
    maxY = (std::min)(height - 1, maxY + bottomBorder);

    const int roiWidth = (std::max)(1, maxX - minX + 1);
    const int roiHeight = (std::max)(1, maxY - minY + 1);
    std::vector<unsigned char> roiPixels(static_cast<size_t>(roiWidth * roiHeight * 3), 0);
    for (int y = 0; y < roiHeight; ++y)
    {
        const size_t sourceOffset = static_cast<size_t>(((minY + y) * width + minX) * 3);
        const size_t targetOffset = static_cast<size_t>(y * roiWidth * 3);
        std::copy_n(pixels.begin() + static_cast<std::ptrdiff_t>(sourceOffset),
                    static_cast<size_t>(roiWidth * 3),
                    roiPixels.begin() + static_cast<std::ptrdiff_t>(targetOffset));
    }

    return writePpmFile(roiPixels, roiWidth, roiHeight, roiPath);
}

std::vector<int> normalizePointIndexes(std::vector<int> pointIndexes)
{
    std::sort(pointIndexes.begin(), pointIndexes.end());
    return pointIndexes;
}

std::vector<int> selectDefaultPointIndexes(const LaserSeamResult& result)
{
    std::vector<int> indexes = result.line_points;
    if (indexes.size() > 8)
    {
        indexes.resize(8);
    }
    if (indexes.size() % 2 != 0)
    {
        indexes.pop_back();
    }
    if (indexes.size() >= 4)
    {
        return normalizePointIndexes(indexes);
    }

    return {};
}

} // namespace

int main(int argc, char* argv[])
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    at_vision::logging::set_level(at_vision::logging::Level::Debug);
    std::cout << "LineTemplate Configuration Demo" << std::endl;

    // The optional first argument is a comma-separated endpoint index list.
    // Every two indexes form one line segment after x/index sorting. At most eight points are supported.
    const bool hasPointIndexArgument = argc > 1;
    const std::vector<int> argumentPointIndexes = hasPointIndexArgument ? parseIntList(argv[1]) : std::vector<int>{};
    const std::filesystem::path outputDir = argc > 2 ? std::filesystem::path(argv[2]) : std::filesystem::path("line_template_output");

    printSeparator("Step 1: Discover Sensors");
    std::error_code discoverEc;
    auto sensors = at_vision::discoverSensors(discoverEc, 5000);
    if (sensors.empty())
    {
        std::cerr << "Error: no sensors found" << std::endl;
        if (discoverEc)
        {
            std::cerr << "  " << discoverEc.message() << std::endl;
        }
        return 1;
    }

    for (size_t i = 0; i < sensors.size(); ++i)
    {
        std::cout << "  [" << i << "] " << sensors[i].sensorId << " (" << sensors[i].sensorIp << ") - " << sensors[i].sensorType << std::endl;
    }

    printSeparator("Step 2: Connect Sensor");
    auto client = at_vision::createVision();
    auto connectEc = client->connect(sensors[0]);
    if (connectEc)
    {
        std::cerr << "Error: failed to connect: " << connectEc.message() << " (0x" << std::hex << connectEc.value() << std::dec << ")" << std::endl;
        return 1;
    }
    std::cout << "Connected to: " << sensors[0].sensorId << std::endl;

    printSeparator("Step 3: Get Algorithm Interface");
    auto algo = client->getAlgorithmInterface();
    if (!algo)
    {
        std::cerr << "Error: failed to get algorithm interface" << std::endl;
        return 1;
    }

    printSeparator("Step 4: Ensure Laser Off");
    algo->setLaserEnabled(false);

    printSeparator("Step 5: Create Process");
    std::error_code ec;
    const std::string processName = "LineTemplate Demo";
    auto processes = algo->getProcessList(ec);
    if (ec)
    {
        std::cerr << "Failed to get Process list: " << ec.message() << std::endl;
        return 1;
    }
    auto processIt = std::find_if(processes.begin(), processes.end(), [&](const ProcessInfo& process) { return process.name == processName; });
    if (processIt != processes.end())
    {
        std::cout << "Deleting existing process: " << processIt->name << " (ID: " << processIt->id << ")" << std::endl;
        ec = algo->deleteProcess(processIt->id);
        if (ec)
        {
            std::cerr << "Error: failed to delete existing process: " << ec.message() << std::endl;
            return 1;
        }
    }

    auto process = algo->addProcess(processName, "demo", "Line template configuration demo", ec);
    if (ec)
    {
        std::cerr << "Error: failed to create process: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "Created process: " << process.name << " (ID: " << process.id << ")" << std::endl;

    printSeparator("Step 6: Create LineTemplate Job");
    auto job = algo->addJob(process.id, SeamType::LineTemplate, 101, "demo_line_template", ec);
    if (ec)
    {
        std::cerr << "Error: failed to create LineTemplate job: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "Created job: " << job.name << " (ID: " << job.id << ")" << std::endl;

    printSeparator("Step 7: Switch to Job");
    job = algo->switchJob(job, ec);
    if (ec)
    {
        std::cerr << "Error: failed to switch job: " << ec.message() << std::endl;
        return 1;
    }

    auto lineTemplateInfo = std::dynamic_pointer_cast<JointLineTemplateAlgoInfo>(job.algo_info);
    if (!lineTemplateInfo)
    {
        std::cerr << "Error: algo_info is not JointLineTemplateAlgoInfo" << std::endl;
        return 1;
    }

    printSeparator("Step 8: Enable Laser and Collect Data");
    std::mutex resultMutex;
    std::condition_variable resultCv;
    LaserSeamResult laserResult;
    bool laserReceived = false;

    client->setLaserSeamResultCallback([&](const LaserSeamResult& result) {
        if (result.laser_state == LaserSeamResult::MANUAL_OPEN || result.laser_state == LaserSeamResult::MACHINE_OPEN)
        {
            std::lock_guard<std::mutex> lock(resultMutex);
            laserResult = result;
            laserReceived = true;
            resultCv.notify_all();
        }
    });

    auto laserEc = algo->setLaserEnabled(true);
    if (laserEc)
    {
        std::cerr << "Error: failed to enable laser: " << laserEc.message() << std::endl;
        return 1;
    }

    {
        std::unique_lock<std::mutex> lock(resultMutex);
        if (!resultCv.wait_for(lock, std::chrono::seconds(10), [&] { return laserReceived; }))
        {
            std::cerr << "Error: timeout waiting for laser data" << std::endl;
            algo->setLaserEnabled(false);
            return 1;
        }
    }

    algo->setLaserEnabled(false);
    std::cout << "Received laser profile, laser points: " << laserResult.laser.size() << ", laser_3D rows: " << laserResult.laser_3D.size()
              << std::endl;

    printSeparator("Step 9: Select Line Template Points");
    const std::vector<int> pointIndexes =
        hasPointIndexArgument ? normalizePointIndexes(argumentPointIndexes) : selectDefaultPointIndexes(laserResult);
    std::cout << "Template point indexes:";
    for (const int index : pointIndexes)
    {
        std::cout << " " << index;
    }
    std::cout << std::endl;
    std::cout << "Template line count: " << pointIndexes.size() / 2 << std::endl;

    printSeparator("Step 10: Save Local Template Images");
    std::error_code fsEc;
    std::filesystem::create_directories(outputDir, fsEc);
    if (fsEc)
    {
        std::cerr << "Warning: failed to create output directory " << outputDir.string() << ": " << fsEc.message() << std::endl;
    }
    else
    {
        const auto fullLaserPath = outputDir / "line_template_laser.ppm";
        const auto roiLaserPath = outputDir / "line_template_roi.ppm";
        if (saveLaserTemplatePpm(laserResult, pointIndexes, fullLaserPath, roiLaserPath))
        {
            std::cout << "Saved LaserSeamResult template image: " << fullLaserPath.string() << std::endl;
            std::cout << "Saved LaserSeamResult template ROI image: " << roiLaserPath.string() << std::endl;
        }
    }

    printSeparator("Step 11: Create Line Template");
    JointLineTemplateAlgoTemplate lineTemplate;
    lineTemplate.laser = laserResult.laser;
    lineTemplate.laser_3D = laserResult.laser_3D;
    lineTemplate.feature_points = laserResult.line_points;
    lineTemplate.selected_points = pointIndexes;

    JointLineTemplateAlgoInfoUpdate update;
    update.job_id = job.id;
    update.line_template_algo_template = lineTemplate;
    // UI BaseLineCombineGraphicsView::saveImg() also sends JPEG base64 template images:
    // update.image_b = encodeJpegToBase64(renderedLaserTemplateImage);
    // update.image_s = encodeJpegToBase64(croppedTemplateRoiImage);
    // This dependency-free SDK example does not encode JPEG/PNG, so image_b and image_s are not sent.
    std::cout << "LaserSeamResult data is sent through JointLineTemplateAlgoTemplate." << std::endl;
    std::cout << "SDK serialization derives the template string, line count, and UI default constraints." << std::endl;
    std::cout << "image_b/image_s are left untouched; see pseudocode comments in the example." << std::endl;

    std::string serializedUpdate;
    const auto serializeEc = update.serialize(serializedUpdate);
    if (serializeEc)
    {
        std::cerr << "Error: failed to serialize LineTemplate params: " << serializeEc.message() << std::endl;
        return 1;
    }
    std::cout << "Serialized LineTemplate algo payload: " << serializedUpdate << std::endl;

    ec = algo->updateAlgoParams(job, update);
    if (ec)
    {
        std::cerr << "Error: failed to update LineTemplate params: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "LineTemplate parameters updated successfully" << std::endl;

    printSeparator("Step 12: Verify Template (Read Back)");
    auto verifyJob = algo->getJobInfo(job.id, ec);
    if (ec)
    {
        std::cerr << "Error: failed to get job info: " << ec.message() << std::endl;
        return 1;
    }

    auto verifyInfo = std::dynamic_pointer_cast<JointLineTemplateAlgoInfo>(verifyJob.algo_info);
    if (!verifyInfo)
    {
        std::cerr << "Error: read-back algo_info is not JointLineTemplateAlgoInfo" << std::endl;
        return 1;
    }

    std::cout << "Read-back template string: " << verifyInfo->line_combine_template_string << std::endl;
    std::cout << "Read-back weld type: " << verifyInfo->line_combine_weld_type << std::endl;
    const auto& firstLine = verifyInfo->line_combine_lines[0];
    const auto& firstCombine = verifyInfo->line_combine_combines[0];
    std::cout << "Read-back L1 angle: [" << firstLine.angle.min << ", " << firstLine.angle.max << "], length_min: " << firstLine.length_min
              << std::endl;
    std::cout << "Read-back C1 angle: [" << firstCombine.angle.min << ", " << firstCombine.angle.max << "], x: [" << firstCombine.x.min << ", "
              << firstCombine.x.max << "], y: [" << firstCombine.y.min << ", " << firstCombine.y.max << "], weight: " << firstCombine.weight
              << std::endl;
    if (!verifyInfo->line_combine_template_string.empty())
    {
        std::cout << "  [OK] Template data was stored." << std::endl;
    }
    else
    {
        std::cout << "  [WARN] Template data is empty after read-back" << std::endl;
    }

    printSeparator("Complete");
    std::cout << "LineTemplate demo finished successfully." << std::endl;
    return 0;
}

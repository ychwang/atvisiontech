// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file sensor_manager_example.cpp
 * @brief Sensor manager example - demonstrates automatic sensor discovery, selection and connection
 *
 * This example provides a practical sensor management tool class that supports:
 * - Automatically search and list all sensors
 * - Select sensor by No. or IP address
 * - Automatically select the first online sensor
 * - Connection management and state display
 *
 * Use cases:
 * - Need to select one sensor from multiple sensors for operation
 * - Need to automatically find and connect to the first available sensor
 * - Interactive management and monitoring of sensor connection state
 */

#include <at_vision/vision_core.h>
#include <at_vision/type_def.h>
#include <iostream>
#include <iomanip>
#include <memory>
#include <thread>
#include <chrono>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;

const char* sensor_status_to_string(at_vision::SensorStatus status)
{
    switch (status)
    {
    case at_vision::SensorStatus::NotInSameNetwork:
        return "not in same network";
    case at_vision::SensorStatus::SensorNormal:
        return "normal";
    case at_vision::SensorStatus::SensorOccupied:
        return "occupied";
    case at_vision::SensorStatus::CameraModuleDisconnected:
        return "camera module disconnected";
    case at_vision::SensorStatus::Unknown:
    default:
        return "unknown";
    }
}

const char* sensor_model_type_to_string(at_vision::SensorModelType type)
{
    switch (type)
    {
    case at_vision::SensorModelType::ATrac150:
        return "aTrac-150";
    case at_vision::SensorModelType::ATrac250:
        return "aTrac-250";
    case at_vision::SensorModelType::ATrac400:
        return "aTrac-400";
    case at_vision::SensorModelType::ATrac2D:
        return "aTrac-2D";
    case at_vision::SensorModelType::ATrac250H:
        return "aTrac-250H";
    case at_vision::SensorModelType::ATrac250W:
        return "aTrac-250W";
    case at_vision::SensorModelType::ATrac400G:
        return "aTrac-400G";
    case at_vision::SensorModelType::ATrac250C:
        return "aTrac-250C";
    case at_vision::SensorModelType::ATrac400GH:
        return "aTrac-400GH";
    case at_vision::SensorModelType::ATrac250WEO:
        return "aTrac-250WEO";
    case at_vision::SensorModelType::ATrac250WE:
        return "aTrac-250WE";
    case at_vision::SensorModelType::None:
    default:
        return "none";
    }
}

const char* bool_to_string(bool value)
{
    return value ? "true" : "false";
}

void print_sensor_info(const at_vision::SensorInfo& sensor, int index)
{
    std::cout << "\n========== Sensor #" << (index + 1) << " ==========\n";
    std::cout << std::left;
    std::cout << std::setw(25) << "Sensor ID:" << sensor.sensorId << "\n";
    std::cout << std::setw(25) << "Sensor IP:" << sensor.sensorIp << "\n";
    std::cout << std::setw(25) << "MAC address:" << sensor.macAddress << "\n";
    std::cout << std::setw(25) << "Platform:" << sensor.platform << "\n";
    std::cout << std::setw(25) << "Sensor type:" << sensor.sensorType << "\n";
    std::cout << std::setw(25) << "Sensor model type:" << sensor_model_type_to_string(sensor.sensorModelType) << " ("
              << static_cast<int>(sensor.sensorModelType) << ")\n";
    std::cout << std::setw(25) << "Sensor status:" << sensor_status_to_string(sensor.sensorStatus) << " (" << static_cast<int>(sensor.sensorStatus)
              << ")\n";
    std::cout << std::setw(25) << "Subnet mask:" << sensor.subnetMask << "\n";
    std::cout << std::setw(25) << "Gateway:" << sensor.gateway << "\n";
    std::cout << std::setw(25) << "Software version:" << sensor.softwareVersionNumber << "\n";
    std::cout << std::setw(25) << "Firmware version:" << sensor.firmwareVersionNumber << "\n";
    std::cout << std::setw(25) << "Camera width:" << sensor.cameraWidth << "\n";
    std::cout << std::setw(25) << "Camera height:" << sensor.cameraHeight << "\n";
    std::cout << std::setw(25) << "Resolution width:" << sensor.resWidth << "\n";
    std::cout << std::setw(25) << "Resolution height:" << sensor.resHeight << "\n";
    std::cout << std::setw(25) << "Image quality mode:" << sensor.imageQuality << "\n";
    std::cout << std::setw(25) << "Local IP:" << sensor.localIp << "\n";
    std::cout << std::setw(25) << "Peer IP:" << sensor.peerIp << "\n";
    std::cout << std::setw(25) << "Standalone broadcast:" << bool_to_string(sensor.standaloneBroadcast) << "\n";
    std::cout << std::setw(25) << "eMMC serial:" << sensor.emmcSerial << "\n";
    std::cout << std::setw(25) << "DB connected:" << bool_to_string(sensor.dbConnected) << "\n";
    std::cout << std::setw(25) << "Laser service running:" << bool_to_string(sensor.laserServiceRunning) << "\n";
    std::cout << "================================\n";
}

class SensorManager {
public:
    SensorManager() : selected_sensor_index_(-1) {}

    // Search and list all sensors
    bool discover(int timeout_ms = 1000)
    {
        std::cout << "Searching for sensors...\n";
        std::error_code discover_ec;
        sensors_ = at_vision::discoverSensors(discover_ec, timeout_ms);

        if (sensors_.empty())
        {
            std::cerr << "No sensors found";
            if (discover_ec)
            {
                std::cerr << " (" << discover_ec.message() << ")";
            }
            std::cerr << "\n";
            return false;
        }

        std::cout << "Discovered " << sensors_.size() << " sensor(s)\n";
        list_sensors();
        return true;
    }

    // List all sensors
    void list_sensors() const
    {
        constexpr int table_width = 96;
        constexpr int no_width = 6;
        constexpr int sensor_id_width = 24;
        constexpr int ip_width = 20;
        constexpr int status_width = 22;

        std::cout << "\nAvailable sensor list:\n";
        std::cout << std::string(table_width, '-') << "\n";
        std::cout << std::left << std::setw(no_width) << "No." << std::setw(sensor_id_width) << "Sensor ID" << std::setw(ip_width) << "IP address"
                  << std::setw(status_width) << "Status" << "Version\n";
        std::cout << std::string(table_width, '-') << "\n";

        for (size_t i = 0; i < sensors_.size(); ++i)
        {
            const auto& s = sensors_[i];
            const std::string no = "[" + std::to_string(i + 1) + "]";
            std::cout << std::left << std::setw(no_width) << no << std::setw(sensor_id_width) << s.sensorId << std::setw(ip_width) << s.sensorIp
                      << std::setw(status_width) << sensor_status_to_string(s.sensorStatus) << s.softwareVersionNumber << "\n";
        }
        std::cout << std::string(table_width, '-') << "\n";
    }

    // Select sensor by index
    bool select_sensor(size_t index)
    {
        if (index >= sensors_.size())
        {
            std::cerr << "Invalid sensor index\n";
            return false;
        }

        selected_sensor_index_ = index;
        const auto& sensor = sensors_[index];

        std::cout << "Selected sensor: " << sensor.sensorId << " (" << sensor.sensorIp << ")\n";
        return true;
    }

    // Select sensor by IP address
    bool select_sensor_by_ip(const std::string& ip)
    {
        for (size_t i = 0; i < sensors_.size(); ++i)
        {
            if (sensors_[i].sensorIp == ip)
            {
                return select_sensor(i);
            }
        }
        std::cerr << "No sensor found with IP " << ip << "\n";
        return false;
    }

    // Automatically select the first online sensor
    bool auto_select()
    {
        for (size_t i = 0; i < sensors_.size(); ++i)
        {
            if (sensors_[i].sensorStatus == at_vision::SensorStatus::SensorNormal)
            {
                return select_sensor(i);
            }
        }

        // If no online sensor, select the first one
        if (!sensors_.empty())
        {
            std::cout << "No online sensor found; selecting the first one...\n";
            return select_sensor(0);
        }

        return false;
    }

    // Get selected sensor information
    const at_vision::SensorInfo* get_selected_sensor() const
    {
        if (selected_sensor_index_ < 0 || selected_sensor_index_ >= static_cast<int>(sensors_.size()))
        {
            return nullptr;
        }
        return &sensors_[selected_sensor_index_];
    }

    // Connect to the selected sensor (example)
    bool connect()
    {
        const auto* sensor = get_selected_sensor();
        if (!sensor)
        {
            std::cerr << "No sensor selected\n";
            return false;
        }

        std::cout << "\nConnecting to sensor...\n";
        std::cout << "   Sensor ID: " << sensor->sensorId << "\n";
        std::cout << "   IP address:   " << sensor->sensorIp << "\n";
        std::cout << "   Resolution:    " << sensor->resWidth << "x" << sensor->resHeight << "\n";

        // Create vision instance
        vision_client_ = at_vision::createVision();
        const auto connect_ec = vision_client_->connect(*sensor);
        if (connect_ec)
        {
            std::cerr << "Connection failed: " << connect_ec.message() << " (0x" << std::hex << connect_ec.value() << std::dec << ")\n";
            vision_client_.reset();
            return false;
        }

        std::cout << "Connected successfully\n";
        std::cout << "   SDK version:  " << vision_client_->getVersion() << "\n";

        return true;
    }

    // Get vision client
    at_vision::IRpcClient* get_client() { return vision_client_.get(); }

    void show_selected_sensor_info() const
    {
        const auto* sensor = get_selected_sensor();
        if (!sensor)
        {
            std::cout << "No sensor selected\n";
            return;
        }

        print_sensor_info(*sensor, selected_sensor_index_);
    }

private:
    std::vector<at_vision::SensorInfo> sensors_;
    int selected_sensor_index_;
    std::unique_ptr<at_vision::IRpcClient> vision_client_;
};

// Interactive menu
void interactive_mode(SensorManager& manager)
{
    std::cout << "\n========== Interactive mode ==========\n";

    while (true)
    {
        std::cout << "\nSelect an action:\n";
        std::cout << "  1. Rediscover sensors\n";
        std::cout << "  2. List sensors\n";
        std::cout << "  3. Select sensor by number\n";
        std::cout << "  4. Select sensor by IP\n";
        std::cout << "  5. Automatically select an online sensor\n";
        std::cout << "  6. Connect to the selected sensor\n";
        std::cout << "  7. Show selected sensor information\n";
        std::cout << "  0. Exit\n";
        std::cout << "\nPlease choose (0-7): ";

        int choice;
        std::cin >> choice;

        switch (choice)
        {
        case 0:
            std::cout << "Exiting program\n";
            return;

        case 1:
            manager.discover(1000);
            break;

        case 2:
            manager.list_sensors();
            break;

        case 3: {
            size_t index;
            std::cout << "Enter sensor number: ";
            std::cin >> index;
            manager.select_sensor(index - 1);
            break;
        }

        case 4: {
            std::string ip;
            std::cout << "Enter sensor IP address: ";
            std::cin >> ip;
            manager.select_sensor_by_ip(ip);
            break;
        }

        case 5:
            manager.auto_select();
            break;

        case 6:
            manager.connect();
            break;

        case 7:
            manager.show_selected_sensor_info();
            break;

        default:
            std::cout << "Invalid selection\n";
        }
    }
}

// Automatic mode: search and connect
void auto_mode(SensorManager& manager)
{
    std::cout << "\n========== Automatic mode ==========\n";

    // 1. Discover Sensors
    if (!manager.discover(3000))
    {
        std::cerr << "Discovery failed\n";
        return;
    }

    // 2. Auto select
    if (!manager.auto_select())
    {
        std::cerr << "Auto selection failed\n";
        return;
    }

    // 3. Connect
    if (!manager.connect())
    {
        std::cerr << "Connection failed\n";
        return;
    }

    std::cout << "\nAuto connection succeeded!\n";
}

int main(int argc, char* argv[])
{
#ifdef _WIN32
    // [Key] Set console output to UTF-8
    SetConsoleOutputCP(CP_UTF8); // 65001
    SetConsoleCP(CP_UTF8);       // Input also set to UTF-8 (optional)
#endif

    std::cout << "========================================\n";
    std::cout << "   Sensor manager example\n";
    std::cout << "========================================\n";

    SensorManager manager;

    // Select mode based on command line arguments
    if (argc > 1 && std::string(argv[1]) == "--auto")
    {
        auto_mode(manager);
    }
    else
    {
        interactive_mode(manager);
    }

    return 0;
}

// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file job_import_export_example.cpp
 * @brief Job import/export demonstration program
 *
 * This example demonstrates how to use the IAlgorithm interface for:
 * - Exporting all Job data to an encrypted .atjob file
 * - Importing all Job data from an encrypted .atjob file
 *
 * @note Export will create parent directories automatically if they don't exist.
 * @note Import is a destructive operation that overwrites all existing data on the sensor.
 * @note After import, it is recommended to restart the sensor.
 */

#include <at_vision/vision_core.h>
#include <at_vision/algorithm_interface.h>
#include <at_vision/logging.h>
#include <iostream>
#include <string>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

using namespace at_vision;

int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
#endif

    // Discover sensors
    std::error_code ec;
    auto sensors = discoverSensors(ec);
    if (ec || sensors.empty())
    {
        std::cerr << "No sensor found: " << ec.message() << std::endl;
        return 1;
    }

    // Create client and connect
    auto client = createVision();
    ec = client->connect(sensors[0]);
    if (ec)
    {
        std::cerr << "Connect failed: " << ec.message() << std::endl;
        return 1;
    }

    auto algorithm = client->getAlgorithmInterface();

    // ===== Export all jobs =====
    std::string exportPath = "D:/backup/jobs/export.atjob";
    std::cout << "Exporting all jobs to: " << exportPath << std::endl;

    ec = algorithm->exportAllJobs(exportPath);
    if (ec)
    {
        std::cerr << "Export failed: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "Export success!" << std::endl;

    // ===== Import all jobs =====
    std::cout << "\nImporting all jobs from: " << exportPath << std::endl;

    ec = algorithm->importAllJobs(exportPath);
    if (ec)
    {
        std::cerr << "Import failed: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "Import success! Please restart the sensor." << std::endl;

    return 0;
}

// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/** @file aotai_tcp_channel.h
 *  \~chinese @brief AoTai TCP 常驻通道公共接口
 *  \~english @brief Public interface for the persistent AoTai TCP channel
 */

#pragma once

#include "at_vision/export.h"
#include "at_vision/type_def.h"
#include <cstdint>
#include <functional>
#include <system_error>
#include <vector>

namespace at_vision {

/**
 * \~chinese @brief AoTai TCP 持续推送帧
 * \~english @brief AoTai TCP continuous stream frame
 */
struct AoTaiTcpStreamFrame {
    uint32_t sequence_id = 0;     ///< \~chinese 当前 TCP 连接内的序号，重连后可重置 \~english Sequence within the current connection
    int64_t timestamp_ms = 0;     ///< \~chinese 服务端时间戳，0 表示无有效值 \~english Server timestamp; zero means unavailable
    uint8_t job_id = 0;           ///< \~chinese 当前 2D JOB 编号 \~english Current 2D JOB identifier
    bool point_valid = false;     ///< \~chinese 点坐标是否有效 \~english Whether the point is valid
    Point3D point;                ///< \~chinese 当前点坐标 \~english Current point
    bool contour_valid = false;   ///< \~chinese 轮廓是否有效 \~english Whether the contour is valid
    std::vector<Point3D> contour; ///< \~chinese 轮廓点 \~english Contour points
};

/**
 * \~chinese @brief AoTai TCP 推送帧回调
 * \~english @brief Callback for AoTai TCP stream frames
 */
using AoTaiTcpStreamCallback = std::function<void(const AoTaiTcpStreamFrame& frame)>;

/**
 * \~chinese @brief AoTai TCP 常驻通道接口
 * \~english @brief Persistent AoTai TCP channel interface
 */
class AT_VISION_API IAoTaiTcpChannel {
public:
    virtual ~IAoTaiTcpChannel() = default;

    /**
     * \~chinese @brief 设置推送帧回调，空回调表示取消订阅
     * \~english @brief Sets the stream callback; an empty callback unsubscribes
     * \~chinese @param callback 推送帧回调
     * \~english @param
     * callback Stream frame callback
     * \~chinese @note 回调在内部接收线程执行，调用方应保证线程安全且避免长时间阻塞
     * \~english @note The
     * callback runs on an internal receive thread; keep it thread-safe and non-blocking
     */
    virtual void setStreamCallback(AoTaiTcpStreamCallback callback) = 0;

    /**
     * \~chinese @brief 连接当前传感器的 46991 端口并开启推送
     * \~english @brief Connects to port 46991 of the current sensor and starts streaming
     * \~chinese @param timeoutMs 连接和握手超时，单位毫秒
     * \~english @param timeoutMs Connection and handshake timeout in milliseconds
     * \~chinese @return 成功返回空错误码
     * \~english @return Empty error code on success
     */
    virtual std::error_code startStream(int timeoutMs = 2000) = 0;

    /**
     * \~chinese @brief 停止推送并清除缓存
     * \~english @brief Stops streaming and clears the cached frame
     * \~chinese @param timeoutMs 停止确认超时，单位毫秒
     * \~english @param timeoutMs Stop acknowledgement timeout in milliseconds
     * \~chinese @return 成功返回空错误码
     * \~english @return Empty error code on success
     */
    virtual std::error_code stopStream(int timeoutMs = 2000) = 0;

    /**
     * \~chinese @brief 获取最近一次有效推送帧
     * \~english @brief Gets the latest valid stream frame
     * \~chinese @param frame 输出最近一帧
     * \~english @param frame Receives the latest frame
     * \~chinese @return 无缓存时返回 ErrorCode::NotInitialized
     * \~english @return ErrorCode::NotInitialized when no frame is cached
     */
    virtual std::error_code getLatestStreamFrame(AoTaiTcpStreamFrame& frame) const = 0;

    /**
     * \~chinese @brief 查询通道当前是否正在接收推送
     * \~english @brief Reports whether the channel is currently receiving stream data
     * \~chinese @return 开启确认完成且接收循环运行时返回 true，重连期间返回 false
     * \~english @return True after enable confirmation while the
     * receive loop is running; false while reconnecting
     */
    virtual bool isStreamRunning() const = 0;

    /**
     * \~chinese @brief 设置独立的通道重连配置，仅停止状态可调用
     * \~english @brief Sets channel-specific reconnect configuration while stopped
     * \~chinese @param config 重连配置
     * \~english @param config Reconnect configuration
     * \~chinese @return 成功返回空错误码
     * \~english @return Empty error code on success
     */
    virtual std::error_code setReconnectConfig(const ReconnectConfig& config) = 0;

    /**
     * \~chinese @brief 获取通道重连配置
     * \~english @brief Gets the channel reconnect configuration
     * \~chinese @return 当前重连配置
     * \~english @return Current reconnect configuration
     */
    virtual ReconnectConfig getReconnectConfig() const = 0;
};

} // namespace at_vision

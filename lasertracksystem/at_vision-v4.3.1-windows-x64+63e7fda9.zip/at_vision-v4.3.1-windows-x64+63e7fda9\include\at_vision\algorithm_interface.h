// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file algorithm_interface.h
 * \~chinese @brief 算法控制接口定义 \~english @brief Algorithm control interface definitions
 *
 * \~chinese 提供 Process 和 Job 的切换、参数管理以及激光控制等功能 \~english Provides Process and Job switching, parameter management, and laser control.
 */

#pragma once

#include "at_vision/export.h"
#include "at_vision/algorithm_type_def.h"
#include <memory>
#include <optional>
#include <string>
#include <system_error>
#include <vector>

namespace at_vision {

/**
 * \~chinese @brief 算法控制接口 \~english @brief Algorithm control interface
 *
 * \~chinese 提供对传感器算法流程的控制功能，包括： \~english Provides control functions for the sensor algorithm workflow, including:
 * \~chinese - Process（工艺库）的切换和查询 \~english - switching and querying Process libraries
 * \~chinese - Job（任务）的切换、查询和参数管理 \~english - switching, querying, and parameter management for Jobs
 * \~chinese - 激光开关控制（与 Job 关联） \~english - laser on/off control associated with Jobs
 */
class AT_VISION_API IAlgorithm {
public:
    using Ptr = std::shared_ptr<IAlgorithm>;
    virtual ~IAlgorithm() = default;

    // ========== Process（工艺库）管理 / Process library management ==========

    /**
     * \~chinese @brief 切换当前 Process（工艺库） \~english @brief Switches the current Process (process library)
     *
     * @param processId Process ID
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 切换 Process 后，当前 Job 会重置为该 Process 下的默认 Job \~english @note After switching Process, the current Job is reset to the default Job under that Process
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 切换前需确保激光已关闭，否则返回 ErrorCode::InvalidState \~english @note The laser must be disabled before switching; otherwise returns ErrorCode::InvalidState
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * auto ec = algorithm->switchProcess(1);
     * if (!ec) {
     *     std::cout << "切换 Process 成功" << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code switchProcess(int processId) = 0;

    /**
     * \~chinese @brief 获取所有可用的 Process 列表 \~english @brief Gets all available Process entries
     *
     * \~chinese @param[out] ec 错误码，成功时清空 \~english @param[out] ec Error code; cleared on success
     * \~chinese @return Process 信息列表，失败返回空列表 \~english @return Process information list; empty on failure
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * std::error_code ec;
     * auto processes = algorithm->getProcessList(ec);
     * if (ec) { return; }
     * for (const auto& p : processes) {
     *     std::cout << "Process ID: " << p.id
     *               << ", Name: " << p.name << std::endl;
     * }
     * @endcode
     */
    virtual std::vector<ProcessInfo> getProcessList(std::error_code& ec) = 0;

    /**
     * \~chinese @brief 获取当前激活的 ProcessId \~english @brief Gets the currently active Process ID
     *
     * \~chinese @return 当前 ProcessId 如果未激活则 id 为 -1 \~english @return Current Process ID; -1 means inactive
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     */
    virtual int getCurrentProcessId() = 0;

    /**
     * \~chinese @brief 获取当前激活的 JobId \~english @brief Gets the currently active Job ID
     *
     * \~chinese @return 当前 JobId 如果未激活则 JobId <= 0 \~english @return Current Job ID; Job ID <= 0 means inactive
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     */
    virtual int getCurrentJobId() = 0;

    /**
     * \~chinese @brief 添加新的 Process（工艺库） \~english @brief Adds a new Process library
     *
     * \~chinese @param name Process 名称（最大20字符） \~english @param name Process name (max 20 characters)
     * \~chinese @param operatorName 操作员名称（最大20字符） \~english @param operatorName Operator name (max 20 characters)
     * \~chinese @param description Process 描述信息（最大100字符） \~english @param description Process description (max 100 characters)
     * \~chinese @param ec 输出错误码，成功返回空 error_code \~english @param ec Output error code; empty error_code indicates success
     * \~chinese @return 新增的 ProcessInfo 对象，失败返回空 ProcessInfo \~english @return The newly added ProcessInfo object; an empty ProcessInfo is returned on failure
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * std::error_code ec;
     * auto processInfo = algorithm->addProcess("新工艺", "张三", "测试工艺库", ec);
     * if (!ec) {
     *     std::cout << "添加 Process 成功，ID: " << processInfo.id << std::endl;
     * }
     * @endcode
     */
    virtual ProcessInfo addProcess(const std::string& name, const std::string& operatorName, const std::string& description, std::error_code& ec) = 0;

    /**
     * \~chinese @brief 修改 Process（工艺库）信息 \~english @brief Modifies Process (process library) information
     *
     * @param processInfo ProcessInfo
     * \~chinese @param name Process 名称（可选，最大20字符） \~english @param name Process name (optional, max 20 characters)
     * \~chinese @param operatorName 操作员名称（可选，最大20字符） \~english @param operatorName Operator name (optional, max 20 characters)
     * \~chinese @param description Process 描述信息（可选，最大100字符） \~english @param description Process description (optional, max 100 characters)
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 至少需要提供一个可选参数 \~english @note At least one optional parameter must be provided
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     */
    virtual std::error_code updateProcessInfo(const ProcessInfo& processInfo,
                                              const std::optional<std::string>& name,
                                              const std::optional<std::string>& operatorName,
                                              const std::optional<std::string>& description) = 0;

    /**
     * \~chinese @brief 删除 Process（工艺库） \~english @brief Deletes Process (process library)
     *
     * @param processId Process ID
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 删除前需确保激光已关闭，否则返回 ErrorCode::InvalidState \~english @note The laser must be disabled before deleting; otherwise returns ErrorCode::InvalidState
     */
    virtual std::error_code deleteProcess(int processId) = 0;

    // ========== Job（任务）管理 / Job management ==========

    /**
     * \~chinese @brief 切换当前 Job（任务） \~english @brief Switches the current Job (job)
     *
     * \~chinese @param jobInfo Job 信息（包含 process_id 与 job_no） \~english @param jobInfo Job information containing process_id and job_no
     * \~chinese @param ec 输出错误码，成功返回空 error_code \~english @param ec Output error code; empty error_code indicates success
     * \~chinese @return 切换后的 Job 信息，失败返回空 JobInfo \~english @return The switched Job information; an empty JobInfo is returned on failure
     *
     * \~chinese @note Job 必须属于当前激活的 Process \~english @note The Job must belong to the currently active Process
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 建议传入 getJobInfo、getCurrentJobInfo 或 getJobList 返回的 JobInfo，避免手动构造导致字段缺失
     * \~english @note Prefer passing JobInfo returned by getJobInfo, getCurrentJobInfo, or getJobList instead of constructing it manually
     * \~chinese @note 成功返回的 JobInfo 包含 image_params 和 algo_info，可作为当前 Job 的完整参数快照
     * \~english @note On success, the returned JobInfo includes image_params and algo_info and can be used as a complete parameter snapshot
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * std::error_code ec;
     * auto jobInfo = algorithm->getJobInfo(1, 5, ec);
     * if (ec) {
     *     return;
     * }
     * auto job = algorithm->switchJob(jobInfo, ec);
     * if (!ec) {
     *     std::cout << "切换 Job 成功" << std::endl;
     * }
     * @endcode
     */
    virtual JobInfo switchJob(const JobInfo& jobInfo, std::error_code& ec) = 0;

    /**
     * \~chinese @brief 获取当前 Job（任务）信息 \~english @brief Gets the current Job information
     *
     * \~chinese @param ec 输出错误码，成功返回空 error_code \~english @param ec Output error code; empty error_code indicates success
     * \~chinese @return 当前 Job 信息，失败返回空 JobInfo \~english @return Current Job information, an empty JobInfo is returned on failure
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 成功返回的 JobInfo 包含 image_params 和 algo_info
     * \~english @note On success, the returned JobInfo includes image_params and algo_info
     */
    virtual JobInfo getCurrentJobInfo(std::error_code& ec) = 0;

    /**
     * \~chinese @brief 根据 Job ID 获取 Job（任务）信息 \~english @brief Gets Job (job) information by Job ID
     *
     * \~chinese @param jobId Job ID（必须大于 0） \~english @param jobId Job ID; must be greater than 0
     * \~chinese @param ec 输出错误码，成功返回空 error_code \~english @param ec Output error code; empty error_code indicates success
     * \~chinese @return Job 信息，失败返回空 JobInfo \~english @return Job information, an empty JobInfo is returned on failure
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 成功返回的 JobInfo 包含 image_params 和 algo_info
     * \~english @note On success, the returned JobInfo includes image_params and algo_info
     */
    virtual JobInfo getJobInfo(int jobId, std::error_code& ec) = 0;

    /**
     * \~chinese @brief 根据 Process ID 和 Job 编号获取 Job（任务）信息 \~english @brief Gets Job information by Process ID and Job number
     *
     * \~chinese @param processId Process ID（必须大于等于 0） \~english @param processId Process ID; must be greater than or equal to 0
     * \~chinese @param jobNo Job 编号（范围：1-252） \~english @param jobNo Job number; valid range is 1 to 252
     * \~chinese @param ec 输出错误码，成功返回空 error_code \~english @param ec Output error code; empty error_code indicates success
     * \~chinese @return Job 信息，失败返回空 JobInfo \~english @return Job information, an empty JobInfo is returned on failure
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 成功返回的 JobInfo 包含 image_params 和 algo_info
     * \~english @note On success, the returned JobInfo includes image_params and algo_info
     */
    virtual JobInfo getJobInfo(int processId, int jobNo, std::error_code& ec) = 0;

    /**
     * \~chinese @brief 获取指定 Process 下的所有 Job 列表 \~english @brief Gets all Jobs under the specified Process
     *
     * \~chinese @param processId Process ID（-1 表示查询当前 Process） \~english @param processId Process ID; -1 queries the current Process
     * \~chinese @param ec 输出错误码，成功返回空 error_code \~english @param ec Output error code; empty error_code indicates success
     * \~chinese @return Job 信息列表，失败返回空列表 \~english @return Job information list, an empty list is returned on failure
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 返回空列表可能是真的没有 Job，也可能是发生了错误，请检查 ec \~english @note An empty list may mean there are no Jobs or an error occurred; check ec
     * \~chinese @note 列表项仅包含 Job 基础字段（id、job_no、process_id、name、weld_type），image_params 和 algo_info 不会填充
     * \~english @note List items contain only basic Job fields; image_params and algo_info are not populated
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * std::error_code ec;
     * // Query all Jobs under the current Process
     * auto jobs = algorithm->getJobList(-1, ec);
     * if (!ec) {
     *     for (const auto& job : jobs) {
     *         std::cout << "Job ID: " << job.id
     *                   << ", Name: " << job.name << std::endl;
     *     }
     * } else {
     *     std::cerr << "获取 Job 列表失败: " << ec.message() << std::endl;
     * }
     * @endcode
     */
    virtual std::vector<JobInfo> getJobList(int processId, std::error_code& ec) = 0;

    /**
     * \~chinese @brief 添加新的 Job（任务） \~english @brief Adds a new Job
     *
     * \~chinese @param processId 所属的 Process ID \~english @param processId Owning Process ID
     * \~chinese @param seamType 焊缝类型 \~english @param seamType Seam type
     * \~chinese @param jobNo Job 编号 \~english @param jobNo Job number
     * \~chinese @param jobName Job 名称 \~english @param jobName Job name
     * \~chinese @param ec 输出错误码，成功返回空 error_code \~english @param ec Output error code; empty error_code indicates success
     * \~chinese @return 添加成功后的 Job 信息，失败返回空 JobInfo \~english @return The Job information after a successful add; an empty JobInfo is returned on failure
     *
     * \~chinese @note Job 将被添加到指定的 Process 下 \~english @note The Job is added under the specified Process
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 返回的 JobInfo 不是完整算法参数快照，algo_info 为空；需要调用 getJobInfo、getCurrentJobInfo 或 switchJob 获取完整 JobInfo
     * \~english @note The returned JobInfo is not a complete algorithm parameter snapshot and has an empty algo_info; call getJobInfo,
     * getCurrentJobInfo, or switchJob
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * std::error_code ec;
     * auto job = algorithm->addJob(1, SeamType::Lap, 10, "测试焊缝", ec);
     * if (!ec) {
     *     std::cout << "添加 Job 成功，Job ID: " << job.id << std::endl;
     * }
     * @endcode
     */
    virtual JobInfo addJob(int processId, SeamType seamType, int jobNo, const std::string& jobName, std::error_code& ec) = 0;

    /**
     * \~chinese @brief 修改 Job 名称 \~english @brief Modify Job name
     *
     * @param jobInfo JobInfo
     * \~chinese @param jobName Job 名称 \~english @param jobName Job name
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 建议传入接口返回的 JobInfo，避免手动构造导致 id、process_id 或 weld_type 缺失
     * \~english @note Prefer passing JobInfo returned by the SDK APIs to avoid missing id, process_id, or weld_type
     */
    virtual std::error_code updateJobName(const JobInfo& jobInfo, const std::string& jobName) = 0;

    /**
     * \~chinese @brief 删除 Job（任务） \~english @brief Deletes Job (job)
     *
     * \~chinese @param jobInfo Job 信息 \~english @param jobInfo Job information
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 建议传入接口返回的 JobInfo，避免手动构造导致 id、process_id 或 weld_type 缺失
     * \~english @note Prefer passing JobInfo returned by the SDK APIs to avoid missing id, process_id, or weld_type
     * \~chinese @note 删除前需确保激光已关闭，否则返回 ErrorCode::InvalidState \~english @note The laser must be disabled before deleting; otherwise returns ErrorCode::InvalidState
     */
    virtual std::error_code deleteJob(const JobInfo& jobInfo) = 0;

    // ========== Job 参数管理 / Job parameter management ==========

    /**
     * \~chinese @brief 更新指定 Job 的图像参数 \~english @brief Updates image parameters for the specified Job
     *
     * @param jobInfo JobInfo
     * \~chinese @param update 图像参数更新对象，仅包含需要更新的字段 \~english @param update Image parameter update object containing only fields to update
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 建议传入 getJobInfo、getCurrentJobInfo 或 switchJob 返回的完整 JobInfo，避免手动构造导致 weld_type 缺失
     * \~english @note Prefer passing complete JobInfo returned by getJobInfo, getCurrentJobInfo, or switchJob to avoid missing weld_type
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * ImageParamsUpdate update;
     * update.cam_expose = 100;
     * update.laser_extension = 50;
     * auto ec = algorithm->updateJobParams(jobInfo, update);
     * if (!ec) {
     *     std::cout << "参数更新成功" << std::endl;
     * } else {
     *     std::cerr << "参数更新失败: " << ec.message() << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code updateJobParams(const JobInfo& jobInfo, const ImageParamsUpdate& update) = 0;

    /**
     * \~chinese @brief 增量更新算法参数 \~english @brief Incrementally updates algorithm parameters
     *
     * @param jobInfo JobInfo
     * \~chinese @param update 参数更新对象，仅包含需要更新的字段 \~english @param update Parameter update object containing only fields to update
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 建议传入 getJobInfo、getCurrentJobInfo 或 switchJob 返回的完整 JobInfo，避免手动构造导致 weld_type 或 algo_info 缺失
     * \~english @note Prefer passing complete JobInfo returned by getJobInfo, getCurrentJobInfo, or switchJob to avoid missing weld_type or algo_info
     */
    virtual std::error_code updateAlgoParams(const JobInfo& jobInfo, const AlgoBaseInfoUpdate& update) = 0;

    /**
     * \~chinese @brief 重置指定 Job 的算法参数为默认值 \~english @brief Resets algorithm parameters of the specified Job to default values
     *
     * @param jobId Job ID
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     */
    virtual std::error_code resetAlgoParams(int jobId) = 0;

    // ========== Job 导入导出 / Job import and export ==========

    /**
     * \~chinese @brief 导出所有 Job 数据为加密文件（.atjob 格式） \~english @brief Exports all Job data to an encrypted file (.atjob format)
     *
     * \~chinese @param filePath 导出文件路径（建议使用 .atjob 扩展名） \~english @param filePath Export file path (recommend using .atjob extension)
     * \~chinese @param timeout_ms RPC 等待超时时间，单位毫秒，默认 30000（30 秒） \~english @param timeout_ms RPC wait timeout in milliseconds; default 30000 (30 seconds)
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 导出 JSON 根节点会记录当前传感器软件版本；首个连字符后的构建信息会被忽略
     * \~english @note The exported JSON root records the current sensor software version; build information after the first hyphen is omitted
     * \~chinese @note 当前传感器软件版本为空时返回 SensorInvalidInfo
     * \~english @note Returns SensorInvalidInfo when the current sensor software version is empty
     * \~chinese @note 若传感器正在执行其他导入/导出操作，会返回 OperationFailed \~english @note Returns OperationFailed if the sensor is already performing another import/export operation
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * auto ec = algorithm->exportAllJobs("D:/backup/export.atjob");
     * if (!ec) {
     *     std::cout << "Export success" << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code exportAllJobs(const std::string& filePath, int timeout_ms = 30000) = 0;

    /**
     * \~chinese @brief 从加密文件导入所有 Job 数据（会覆盖传感器上现有数据） \~english @brief Imports all Job data from an encrypted file, overwriting existing data on the sensor
     *
     * \~chinese @param filePath 加密文件路径（.atjob 文件） \~english @param filePath Encrypted file path (.atjob file)
     * \~chinese @param timeout_ms RPC 等待超时时间，单位毫秒，默认 30000（30 秒） \~english @param timeout_ms RPC wait timeout in milliseconds; default 30000 (30 seconds)
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 此操作会清空传感器上现有的所有 Process/Job/算法参数数据后重新写入，不可逆 \~english @note This operation clears all existing Process/Job/algorithm parameter data on the sensor before writing; it is irreversible
     * \~chinese @note 文件含 version 时，主次版本须相同，且文件补丁版本不得高于当前传感器；不含 version 的旧文件保持兼容
     * \~english @note A versioned file requires the same major/minor version and a patch version no newer than the sensor;
     * files without version remain supported
     * \~chinese @note 版本不兼容返回 JobImportVersionMismatch；字段无效返回 InvalidParameter；当前传感器版本为空或无效返回 SensorInvalidInfo
     * \~english @note Returns JobImportVersionMismatch for mismatch, InvalidParameter for an invalid field,
     * or SensorInvalidInfo if the sensor version is empty or invalid
     * \~chinese @note 导入完成后必须重启传感器以使所有设置生效 \~english @note The sensor must be restarted after import for all settings to take effect
     * \~chinese @note 若传感器正在执行其他导入/导出操作，会返回 OperationFailed \~english @note Returns OperationFailed if the sensor is already performing another import/export operation
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * auto ec = algorithm->importAllJobs("D:/backup/export.atjob");
     * if (!ec) {
     *     std::cout << "Import success, please restart the sensor" << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code importAllJobs(const std::string& filePath, int timeout_ms = 30000) = 0;

    // ========== 激光控制 / laser control ==========

    /**
     * \~chinese @brief 控制指定 Job 的激光开关 \~english @brief Controls the laser on/off state for the specified Job
     * \~chinese @param enabled true=开启激光，false=关闭激光 \~english @param enabled true enables the laser; false disables the laser
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 激光控制与具体的 Job 关联，不同 Job 可能有不同的激光配置 \~english @note Laser control is associated with a specific Job; different Jobs may have different laser configurations
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     * \~chinese @note 部分传感器平台可能不支持激光控制，会返回 ErrorCode::NotSupported \~english @note Some sensor platforms may not support laser control and return ErrorCode::NotSupported
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * // Enable the laser for Job 5
     * auto ec = algorithm->setLaserEnabled(5, true);
     * if (!ec) {
     *     std::cout << "激光开启成功" << std::endl;
     * } else {
     *     std::cerr << "激光控制失败: " << ec.message() << std::endl;
     * }
     *
     * // Disable the laser
     * algorithm->setLaserEnabled(5, false);
     * @endcode
     */
    virtual std::error_code setLaserEnabled(bool enabled) = 0;

    /**
     * \~chinese @brief 获取指定算法类型的参数配置范围 \~english @brief Gets the parameter configuration range for the specified algorithm type
     *
     * \~chinese @param seamType 焊缝类型（例如：SeamType::LineLeftLap） \~english @param seamType Seam type, for example SeamType::LineLeftLap
     * \~chinese @param[out] configDict 输出参数配置字典 \~english @param[out] configDict Output parameter configuration dictionary
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * ParamConfigDict config;
     * auto ec = algorithm->getParamConfigRange(SeamType::LineLeftLap, config);
     * if (!ec) {
     *     std::cout << "获取参数范围成功，焊缝类型: " << static_cast<int>(SeamType::LineLeftLap) << std::endl;
     *     for (const auto& param : config.params) {
     *         std::cout << "参数: " << param.param_name
     *                   << ", 类型: " << param.param_type
     *                   << ", 范围: [" << param.param_min << ", " << param.param_max << "]"
     *                   << ", 默认值: " << param.param_default << std::endl;
     *     }
     * }
     * @endcode
     */
    virtual std::error_code getParamConfigRange(SeamType seamType, ParamConfigDict& configDict) = 0;

    /**
     * \~chinese @brief 获取指定算法类型和参数名的参数配置 \~english @brief Gets the parameter configuration for the specified algorithm type and parameter name
     *
     * \~chinese @param seamType 焊缝类型（例如：SeamType::LineLeftLap） \~english @param seamType Seam type, for example SeamType::LineLeftLap
     * \~chinese @param paramName 参数名（例如："line_left_lap_fit_threshold"） \~english @param paramName Parameter name, for example "line_left_lap_fit_threshold"
     * \~chinese @param[out] configItem 输出参数配置项 \~english @param[out] configItem Output parameter configuration item
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 需要在连接到传感器后调用 \~english @note Call after connecting to the sensor
     *
     * @code
     * auto algorithm = client->getAlgorithmInterface();
     * ParamConfigItem config;
     * auto ec = algorithm->getParamConfigItem(SeamType::LineLeftLap, "line_left_lap_fit_threshold", config);
     * if (!ec) {
     *     std::cout << "参数: " << config.param_name
     *               << ", 类型: " << config.param_type
     *               << ", 最小值: " << config.param_min
     *               << ", 最大值: " << config.param_max
     *               << ", 步长: " << config.param_step
     *               << ", 默认值: " << config.param_default << std::endl;
     * }
     * @endcode
     */
    virtual std::error_code getParamConfigItem(SeamType seamType, const std::string& paramName, ParamConfigItem& configItem) = 0;
};

} // namespace at_vision

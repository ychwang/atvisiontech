// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file algorithm_param_config_item_example.cpp
 * @brief Demonstrate how to query single algorithm parameter configuration items
 */

#include <at_vision/vision_core.h>
#include <iostream>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;

int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    std::cout << "at_vision single parameter configuration query example" << std::endl;

    std::error_code discover_ec;
    const auto sensors = discoverSensors(discover_ec, 5000);
    if (sensors.empty())
    {
        std::cerr << "No sensors found";
        if (discover_ec)
        {
            std::cerr << ": " << discover_ec.message();
        }
        std::cerr << std::endl;
        return 1;
    }

    auto client = createVision();
    const auto connect_ec = client->connect(sensors.front());
    if (connect_ec)
    {
        std::cerr << "Connection failed: " << connect_ec.message() << std::endl;
        return 2;
    }

    auto algorithm = client->getAlgorithmInterface();
    if (!algorithm)
    {
        std::cerr << "Failed to get algorithm interface" << std::endl;
        return 3;
    }

    ParamConfigItem item;
    const auto ec = algorithm->getParamConfigItem(
        SeamType::LineLeftLap,
        "line_left_lap_fit_threshold",
        item);

    if (ec)
    {
        std::cerr << "Failed to query parameter configuration: " << ec.message() << std::endl;
        return 4;
    }

    std::cout << "Parameter name: " << item.param_name << std::endl;
    std::cout << "Type: " << item.param_type << std::endl;
    std::cout << "Min value: " << item.param_min << std::endl;
    std::cout << "Max value: " << item.param_max << std::endl;
    std::cout << "Step: " << item.param_step << std::endl;
    std::cout << "Default value: " << item.param_default << std::endl;

    return 0;
}

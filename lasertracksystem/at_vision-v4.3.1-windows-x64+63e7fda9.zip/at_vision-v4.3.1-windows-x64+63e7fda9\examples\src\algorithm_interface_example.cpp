// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file algorithm_interface_example.cpp
 * @brief Algorithm control interface and Laser Control demonstration program
 *
 * This example demonstrates how to use the IAlgorithm interface for the following operations:
 * - Process (craft library) management: query, switch, add, modify, delete
 * - Job (task) management: query, switch, add, modify, delete
 * - Job parameter management: update image parameters, update algorithm parameters
 * - Laser switch control: turn on/off laser for specified Job
 *
 * @note Relationship between Process and Job:
 *       - Process is the craft library, containing multiple Jobs
 *       - Job is the specific task, belonging to a Process
 *       - After switching Process, Current Job will be reset to the default Job of that Process
 *
 * @note Laser Control Description:
 *       - Laser Control is associated with specific Job
 *       - Different Jobs may have different laser configurations
 *       - Some sensor platforms may not support Laser Control (will return NotSupported error)
 */

#include <at_vision/vision_core.h>
#include <at_vision/algorithm_interface.h>
#include <at_vision/algorithm_type_def.h>
#include <at_vision/type_def.h>
#include <at_vision/logging.h>
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <sstream>
#include <cctype>

#ifdef _WIN32
#define NOMINMAX // Prevent Windows.h from defining min/max macros conflicting with std::min/max
#include <windows.h>
#endif

using namespace at_vision;

template <typename T>
std::string serialize_for_display(const T& value)
{
    std::string out;
    if (value.serialize(out))
    {
        return "{}";
    }
    return out;
}

void print_separator(const std::string& title)
{
    std::cout << "\n========== " << title << " ==========\n" << std::endl;
}

void print_process_info(const at_vision::ProcessInfo& info)
{
    std::cout << "  Process ID: " << info.id << "\n"
              << "  Name: " << info.name << "\n"
              << "  Operator: " << info.operator_name << "\n"
              << "  Description: " << info.description << std::endl;
}

void print_job_info(const at_vision::JobInfo& info)
{
    std::cout << "  Job ID: " << info.id << "\n"
              << "  Job No: " << info.job_no << "\n"
              << "  Process ID: " << info.process_id << "\n"
              << "  Name: " << info.name << std::endl;
}

std::vector<int> parse_int_list(const std::string& text)
{
    std::vector<int> values;
    std::stringstream stream(text);
    std::string item;
    while (std::getline(stream, item, ','))
    {
        std::string trimmed;
        trimmed.reserve(item.size());
        for (unsigned char ch : item)
        {
            if (!std::isspace(ch))
            {
                trimmed.push_back(static_cast<char>(ch));
            }
        }

        if (!trimmed.empty())
        {
            values.push_back(std::stoi(trimmed));
        }
    }
    return values;
}

int main(int argc, char* argv[])
{
#ifdef _WIN32
    // [Key] Set console output to UTF-8
    SetConsoleOutputCP(CP_UTF8); // 65001
    SetConsoleCP(CP_UTF8);       // Input also set to UTF-8 (optional)
#endif
    // Set log level
    at_vision::logging::set_level(at_vision::logging::Level::Debug);

    std::cout << "at_vision algorithm interface and laser control demo\n" << std::endl;

    // 1. Discover Sensors
    print_separator("Discover Sensors");
    std::cout << "Searching for sensors on the LAN..." << std::endl;
    std::error_code discover_ec;
    auto sensors = at_vision::discoverSensors(discover_ec, 5000);

    if (sensors.empty())
    {
        std::cerr << "Error: no sensors found. Please check the network connection";
        if (discover_ec)
        {
            std::cerr << " (" << discover_ec.message() << ")";
        }
        std::cerr << std::endl;
        return 1;
    }

    std::cout << "Found " << sensors.size() << " sensor(s):" << std::endl;
    for (size_t i = 0; i < sensors.size(); ++i)
    {
        std::cout << "[" << i << "] " << sensors[i].sensorId << " (" << sensors[i].sensorIp << ") - " << sensors[i].sensorType << std::endl;
    }

    // Select first sensor to connect
    const auto& targetSensor = sensors[0];
    std::cout << "\nSelected sensor: " << targetSensor.sensorId << std::endl;

    // 2. Create client and connect
    print_separator("Connect Sensor");
    auto client = at_vision::createVision();
    auto connectEc = client->connect(targetSensor);
    if (connectEc)
    {
        std::cerr << "Error: failed to connect to sensor: " << connectEc.message() << " (error code: 0x" << std::hex << connectEc.value() << ")"
                  << std::dec << std::endl;
        return 1;
    }
    std::cout << "Connected to sensor: " << targetSensor.sensorId << std::endl;

    // 3. Get algorithm control interface
    print_separator("Get Algorithm Interface");
    auto algorithm = client->getAlgorithmInterface();
    if (!algorithm)
    {
        std::cerr << "Error: failed to get algorithm interface" << std::endl;
        return 1;
    }
    std::cout << "Algorithm control interface acquired" << std::endl;

    // 4. Query Process List
    print_separator("Query Process List");
    std::error_code processEc;
    auto processes = algorithm->getProcessList(processEc);
    if (processEc)
    {
        std::cerr << "Failed to get Process list: " << processEc.message() << std::endl;
        return 1;
    }
    if (processes.empty())
    {
        std::cout << "Warning: no available Process exists" << std::endl;
    }
    else
    {
        std::cout << "Found " << processes.size() << " Process entry/entries:\n" << std::endl;
        for (const auto& proc : processes)
        {
            print_process_info(proc);
            std::cout << std::endl;
        }
    }

    // 5. Get Current Process
    print_separator("Current Process");
    auto currentProcess = algorithm->getCurrentProcessId();
    auto jobID = algorithm->getCurrentJobId();
    if (currentProcess != -1)
    {
        std::cout << "Current active Process ID: " << currentProcess << std::endl;
        std::cout << "Current active Job ID: " << jobID << std::endl;
    }
    else
    {
        std::cout << "No Process is currently active" << std::endl;
    }

    // 5.1 Add New Process demonstration (optional, commented out to avoid affecting existing data)
    print_separator("Add New Process");

    // First check if a Process with the same name exists, if so delete it
    auto resProcessIter = std::find_if(processes.begin(), processes.end(), [](const ProcessInfo& proc) { return proc.name == "Test Process"; });

    if (resProcessIter != processes.end())
    {
        std::cout << "✓ Process already exists: " << resProcessIter->name << " (ID: " << resProcessIter->id << ")" << std::endl;
        auto delEc = algorithm->deleteProcess(resProcessIter->id);
        if (!delEc)
        {
            std::cout << "✓ Deleted duplicate Process: " << resProcessIter->name << " (ID: " << resProcessIter->id << ")" << std::endl;
            // Re-query Process List
            processes = algorithm->getProcessList(processEc);
            if (processEc)
            {
                std::cerr << "Failed to get Process list: " << processEc.message() << std::endl;
                return 1;
            }
        }
        else
        {
            std::cerr << "✗ Failed to delete duplicate Process: " << delEc.message() << std::endl;
        }
    }

    std::error_code ec_add_process;
    auto addedProcess = algorithm->addProcess("Test Process", "operator", "Example test process library", ec_add_process);
    if (!ec_add_process)
    {
        std::cout << "✓ Added Process successfully, ID: " << addedProcess.id << std::endl;
        // Re-query Process List to verify
        processes = algorithm->getProcessList(processEc);
        if (processEc)
        {
            std::cerr << "Failed to get Process list: " << processEc.message() << std::endl;
            return 1;
        }
        std::cout << "Current total: " << processes.size() << " Process entry/entries" << std::endl;

        // Update Process information demonstration
        std::cout << "\nTrying to update Process information..." << std::endl;
        auto updateEc = algorithm->updateProcessInfo(addedProcess,
                                                     std::make_optional("Updated Test Process"),              // Update name
                                                     std::nullopt,                                            // Keep operator unchanged
                                                     std::make_optional("Updated test process description")); // Update description
        if (!updateEc)
        {
            std::cout << "✓ Updated Process information successfully" << std::endl;
            // Re-query Process List to verify update results
            processes = algorithm->getProcessList(processEc);
            if (processEc)
            {
                std::cerr << "Failed to get Process list: " << processEc.message() << std::endl;
                return 1;
            }
            auto updatedProcessIter =
                std::find_if(processes.begin(), processes.end(), [&addedProcess](const ProcessInfo& proc) { return proc.id == addedProcess.id; });
            if (updatedProcessIter != processes.end())
            {
                std::cout << "Updated Process information:" << std::endl;
                print_process_info(*updatedProcessIter);
            }
        }
        else
        {
            std::cerr << "✗ Failed to update Process information: " << updateEc.message() << std::endl;
        }
    }
    else
    {
        std::cerr << "✗ Failed to add Process: " << ec_add_process.message() << std::endl;
    }
    {
        // 6. Switch Process (if there are multiple)
        if (processes.size() > 1)
        {
            print_separator("Switch Process");
            int targetProcessId = processes.at(1).id; // Switch to the second Process
            std::cout << "Trying to switch to Process ID: " << targetProcessId << std::endl;

            auto ec = algorithm->switchProcess(targetProcessId);
            if (!ec)
            {
                std::cout << "✓ Process switched successfully" << std::endl;

                // Verify switch results
                auto currentProcess = algorithm->getCurrentProcessId();
                if (currentProcess == targetProcessId)
                {
                    std::cout << "✓ Confirmed current Process: " << targetProcessId << std::endl;
                }
            }
            else
            {
                std::cerr << "✗ Failed to switch Process: " << ec.message() << std::endl;
            }
        }
        print_separator("Current Process");
        auto currentProcess = algorithm->getCurrentProcessId();
        auto jobID = algorithm->getCurrentJobId();
        if (currentProcess != -1)
        {
            std::cout << "Current active Process ID: " << currentProcess << std::endl;
            std::cout << "Current active Job ID: " << jobID << std::endl;
        }
        else
        {
            std::cout << "No Process is currently active" << std::endl;
        }
    }
    // 7. Query Job list
    // New calling method:
    std::error_code ec;
    auto jobs = algorithm->getJobList(algorithm->getCurrentProcessId(), ec);
    if (!ec)
    {
        if (jobs.empty())
        {
            std::cout << "Warning: the current Process has no available Jobs" << std::endl;
        }
        // Success, jobs may be empty (meaning no Job)
        for (const auto& job : jobs)
        {
            std::cout << "Job: " << job.name << std::endl;
        }
    }
    else
    {
        // Failure, need to handle error
        std::cerr << "Failed to get Job list: " << ec.message() << std::endl;
    }

    // 7.1 Add New Job demonstration (optional, commented out to avoid affecting existing data)
    if (!processes.empty())
    {
        print_separator("Add New Job");
        int targetProcessId = algorithm->getCurrentProcessId();

        auto resIter = std::find_if(jobs.begin(), jobs.end(), [](const JobInfo& job) { return job.job_no == 103 && job.name == "Test Weld Job"; });
        if (resIter != jobs.end())
        {
            std::cout << "✓ Job already exists: " << resIter->name << " (Job No: " << resIter->job_no << ")" << std::endl;
            auto delEc = algorithm->deleteJob(*resIter);
            if (!delEc)
            {
                std::cout << "✓ Deleted duplicate Job: " << resIter->name << " (Job No: " << resIter->job_no << ")" << std::endl;
            }
            else
            {
                std::cerr << "✗ Failed to delete duplicate Job: " << delEc.message() << std::endl;
            }
        }
        auto resJobInfo = algorithm->addJob(targetProcessId, SeamType::LineLeftLap, 103, "Test Weld Job", ec);
        if (!ec)
        {
            std::cout << "✓ Added Job successfully to Process " << targetProcessId << ", " << serialize_for_display(resJobInfo) << std::endl;
            // Re-query Job list to verify
            jobs = algorithm->getJobList(targetProcessId, ec);
            std::cout << "Process " << targetProcessId << " currently has " << jobs.size() << " Job entry/entries" << std::endl;

            // Update Job name demonstration
            std::cout << "\nTrying to update Job name..." << std::endl;
            auto updateJobEc = algorithm->updateJobName(resJobInfo, "Updated Test Weld Job");
            if (!updateJobEc)
            {
                std::cout << "✓ Updated Job name successfully" << std::endl;
                // Re-query Job list to verify update results
                jobs = algorithm->getJobList(targetProcessId, ec);
                auto updatedJobIter = std::find_if(jobs.begin(), jobs.end(), [&resJobInfo](const JobInfo& job) { return job.id == resJobInfo.id; });
                if (updatedJobIter != jobs.end())
                {
                    std::cout << "Updated Job information:" << std::endl;
                    print_job_info(*updatedJobIter);
                }
            }
            else
            {
                std::cerr << "✗ Failed to update Job name: " << updateJobEc.message() << std::endl;
            }
        }
        else
        {
            std::cerr << "✗ Failed to add Job: " << ec.message() << std::endl;
        }
    }

    client->getSettings()->setImageQuality(ImageQuality::Original);
    // Set image callback (can be set before or after connect)
    client->setImageCallback([](const Image& image) {
        // Write to file
        try
        {
            std::string filename = (image.type == ImageType::JPG) ? "test.jpg" : "test.RAW";
            std::ofstream file(filename, std::ios::binary);
            if (file.is_open())
            {
                file.write(reinterpret_cast<const char*>(image.data.data()), image.data.size());
                file.close();
            }
            else
            {
                std::cerr << "✗ Failed to open file: " << filename << std::endl;
            }
        } catch (const std::exception& e)
        {
            std::cerr << "✗ Failed to save image: " << e.what() << std::endl;
        }
    });
    client->setLaserSeamResultCallback([](const LaserSeamResult& result) {
        if (result.laser_state == -1 || result.laser_state == 0b00 || result.laser_state == 0b10)
        {
            return;
        }
        std::cout << "Received LaserSeamResult: "
                  << "SeamPoint=" << result.seam_point.y_3d << "," << result.seam_point.z_3d << " "
                  << " laser_state=" << result.laser_state << std::endl;
    });
    client->getAlgorithmInterface()->setLaserEnabled(true);

    // 8. Get Current Job
    print_separator("Current Job");
    auto currentJobId = algorithm->getCurrentJobId();
    if (currentJobId == -1)
    {
        std::cout << "No Job is currently active" << std::endl;
    }

    // 9. Switch Job (if there are multiple)
    if (jobs.size() > 0)
    {
        print_separator("Switch Job");
        const auto& targetJob = jobs.back();
        std::cout << "Trying to switch to Job ID: " << targetJob.id << std::endl;

        std::error_code ec;
        auto switchedJob = algorithm->switchJob(targetJob, ec);
        if (!ec)
        {
            std::cout << "✓ Job switched successfully" << serialize_for_display(switchedJob) << "\n"
                      << serialize_for_display(*switchedJob.algo_info) << std::endl;

            // Verify switch results
            if (switchedJob.id == targetJob.id)
            {
                std::cout << "✓ Confirmed current Job: " << switchedJob.name << std::endl;
            }

            // Update image parameters demonstration
            std::cout << "\nTrying to update image parameters..." << std::endl;
            ImageParamsUpdate imgUpdate;
            imgUpdate.cam_expose = 900;             // Set exposure time to 100
            imgUpdate.laser_extension = 10;         // Set laser intensity to 80
            imgUpdate.surface_light_extension = 66; // Set surface light intensity to 60

            auto imgUpdateEc = algorithm->updateJobParams(switchedJob, imgUpdate);
            if (!imgUpdateEc)
            {
                std::cout << "✓ Updated image parameters successfully" << std::endl;
            }
            else
            {
                std::cerr << "✗ Failed to update image parameters: " << imgUpdateEc.message() << std::endl;
            }

            // Update algorithm parameters demonstration
            std::cout << "\nTrying to update algorithm parameters..." << std::endl;
            // For different seam types, the corresponding specific algorithm parameter update class should be used
            // Since LineTemplate may not have a dedicated update class, we use JointLineTemplateAlgoInfoUpdate as an example
            LineLeftLapAlgoInfoUpdate algoUpdate;
            algoUpdate.job_id = switchedJob.id;
            algoUpdate.thinning_threshold = 120; // Set fixed threshold
            algoUpdate.line_left_lap_fit_threshold = 12;
            algoUpdate.thinning_adaptive = false; // Disable adaptive threshold
            auto algoUpdateEc = algorithm->updateAlgoParams(switchedJob, algoUpdate);
            if (!algoUpdateEc)
            {
                std::cout << "✓ Updated algorithm parameters successfully" << std::endl;
            }
            else
            {
                std::cerr << "✗ Failed to update algorithm parameters: " << algoUpdateEc.message() << std::endl;
            }

            // Reset algorithm parameters demonstration
            std::cout << "\nTrying to reset algorithm parameters..." << std::endl;
            auto resetAlgoEc = algorithm->resetAlgoParams(switchedJob.id);
            if (!resetAlgoEc)
            {
                std::cout << "✓ Reset algorithm parameters successfully" << std::endl;
            }
            else
            {
                std::cerr << "✗ Failed to reset algorithm parameters: " << resetAlgoEc.message() << std::endl;
            }
        }
        else
        {
            std::cerr << "✗ Failed to switch Job: " << ec.message() << std::endl;
        }

        // 10. Laser Control demonstration
        print_separator("Laser Control");
        std::cout << "Job ID: " << targetJob.id << std::endl;

        // Enable Laser
        std::cout << "\nTrying to enable the laser..." << std::endl;
        auto ec_on = algorithm->setLaserEnabled(true);
        if (!ec_on)
        {
            std::cout << "✓ Laser enabled successfully" << std::endl;
        }
        else
        {
            std::cerr << "✗ Failed to enable laser: " << ec_on.message() << std::endl;
            if (ec_on == std::errc::not_supported)
            {
                std::cout << "Note: the current sensor platform may not support laser control" << std::endl;
            }
        }

        // Wait for 2 seconds
        std::cout << "\nKeeping the laser enabled for 2 seconds..." << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(2));

        // Disable Laser
        std::cout << "Trying to disable the laser..." << std::endl;
        auto ec_off = algorithm->setLaserEnabled(false);
        if (!ec_off)
        {
            std::cout << "✓ Laser disabled successfully" << std::endl;
        }
        else
        {
            std::cerr << "✗ Failed to disable laser: " << ec_off.message() << std::endl;
        }

        // 11. Parameter configuration query demonstration
        print_separator("Parameter Configuration Range Query");

        // Iterate through all SeamType to get parameter range
        std::vector<SeamType> seam_types = {
            SeamType::None,
            SeamType::Lap,
            SeamType::Joint,
            SeamType::V,
            SeamType::Edge,
            SeamType::Angle,
            SeamType::Micro,
            SeamType::ComplexV,
            SeamType::LineCombine,
            SeamType::Narrow2D,
            SeamType::LineTemplate,
            SeamType::LineCircle,
            SeamType::LineLeftLap,
            SeamType::LineRightLap,
            SeamType::LineInternalCorner,
            SeamType::LineExternalCorner,
            SeamType::LineButt,
            SeamType::LineLeftEdge,
            SeamType::LineRightEdge,
            SeamType::LineVGroove,
            SeamType::LineMCorner
            // Note: Count is not included as it is just the total number of enums
        };

        for (const auto& seam_type : seam_types)
        {
            std::cout << "\nQuerying parameter range for seam type (" << static_cast<int>(seam_type) << ") ..." << std::endl;
            {
                ParamConfigDict config;
                auto ec_range = algorithm->getParamConfigRange(seam_type, config);
                if (!ec_range)
                {
                    std::cout << "✓ Got parameter range successfully, parameter count: " << config.params.size() << std::endl;
                    std::cout << "Table name: " << config.table_name << std::endl;

                    if (!config.params.empty())
                    {
                        std::cout << "Parameter list:" << std::endl;
                        for (const auto& param : config.params)
                        {
                            std::cout << "  - " << param.param_name << " (type: " << param.param_type << ")"
                                      << ", range: [" << param.param_min << ", " << param.param_max << "]"
                                      << ", Step: " << param.param_step << ", Default value: " << param.param_default << std::endl;
                        }
                    }
                }
                else
                {
                    std::cerr << "✗ Failed to get parameter range: " << ec_range.message() << std::endl;
                }
            }
        }
    }

    auto curJobInfo = algorithm->getCurrentJobInfo(ec);
    if (!ec)
    {
        std::cout << "Current active Job ID: " << currentJobId << " " << serialize_for_display(curJobInfo) << "\n"
                  << serialize_for_display(*curJobInfo.algo_info) << std::endl;
    }
    else
    {
        std::cerr << "✗ Failed to get current Job information: " << ec.message() << std::endl;
    }
    // 12. Complete
    print_separator("Demo completed");
    std::cout << "All feature demos completed!" << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(5000)); // Wait for callback registration to complete
    return 0;
}

// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file sensor_config_example.cpp
 * @brief Sensor IP address modification and restart function demonstration
 *
 * This example demonstrates how to configure sensor network parameters, including:
 * 1. Search for sensors on the network
 * 2. Check sensor Platform (IP configuration not supported on WINDOWS_X64 Platform)
 * 3. Changing sensor IP address
 * 4. Restart sensor and wait for recovery
 *
 * @note IP configuration notes:
 *       - Only supports modifying IP address, does not support modifying subnet mask and gateway
 *       - To change the subnet mask or gateway, use the sensor Web management UI
 *       - After modifying IP, use the New IP to rediscover sensors
 *
 * @note Restart notes:
 *       - Restart command is sent via UDP broadcast (Port 15556)
 *       - The sensor will restart immediately after receiving the command
 *       - Approximately 30-60 seconds are required for the sensor to fully boot up after restart
 *       - The sensor cannot be connected during reboot
 */

#include <at_vision/vision_core.h>
#include <iostream>
#include <thread>
#include <chrono>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;
int main()
{
#ifdef _WIN32
    // [Key] Set console output to UTF-8
    SetConsoleOutputCP(CP_UTF8); // 65001
    SetConsoleCP(CP_UTF8);       // Input also set to UTF-8 (optional)
#endif
    std::cout << "=== Sensor IP address configuration demo ===" << std::endl;

    // 1. Discover Sensors
    std::cout << "\n[1] Searching for sensors on the LAN..." << std::endl;
    std::error_code discover_ec;
    auto sensors = at_vision::discoverSensors(discover_ec, 3000);

    if (sensors.empty())
    {
        std::cerr << "No sensors found";
        if (discover_ec)
        {
            std::cerr << " (" << discover_ec.message() << ")";
        }
        std::cerr << std::endl;
        return 1;
    }

    std::cout << "Found " << sensors.size() << " sensor(s):" << std::endl;
    for (size_t i = 0; i < sensors.size(); ++i)
    {
        const auto& sensor = sensors[i];
        std::cout << "[" << i << "] "
                  << "ID: " << sensor.sensorId << ", IP: " << sensor.sensorIp << ", Platform: " << sensor.platform << ", Type: " << sensor.sensorType
                  << std::endl;
    }

    // 2. Select first sensor for operation
    auto& target_sensor = sensors[0];
    std::cout << "\nSelected sensor: " << target_sensor.sensorId << " (" << target_sensor.sensorIp << ", " << target_sensor.platform << ")" << std::endl;

    // 3. Change sensor IP address (only supported on non-WINDOWS_X64 platforms)
    if (target_sensor.platform == "WINDOWS_X64")
    {
        std::cout << "\n[2] Skipping IP configuration because WINDOWS_X64 does not support IP changes" << std::endl;
    }
    else
    {
        std::cout << "\n[2] Changing sensor IP address..." << std::endl;

        // Set new IP address
        std::string new_ip = "192.168.1.100";

        std::cout << "Current IP: " << target_sensor.sensorIp << std::endl;
        std::cout << "New IP: " << new_ip << std::endl;
        std::cout << "\nNote: only IP address changes are supported; subnet mask and gateway remain unchanged" << std::endl;
        std::cout << "To change the subnet mask or gateway, use the sensor Web management UI" << std::endl;

        // Prompt user to confirm (to avoid accidental changes)
        std::cout << "\nWarning: after changing the IP, rediscover sensors using the new IP." << std::endl;
        std::cout << "Continue? (y/n): ";

        char confirm;
        std::cin >> confirm;

        if (confirm != 'y' && confirm != 'Y')
        {
            std::cout << "Operation cancelled" << std::endl;
        }
        else
        {
            // Send configuration command
            auto config_error = at_vision::configureSensorNetwork(target_sensor, new_ip);

            if (!config_error)
            {
                std::cout << "IP address change command sent!" << std::endl;
                std::cout << "  New IP: " << new_ip << std::endl;

                // Update local record (for subsequent operations)
                target_sensor.sensorIp = new_ip;

                // Wait for sensor to apply new configuration
                std::cout << "\nWaiting for the sensor to apply the new IP..." << std::endl;
                std::this_thread::sleep_for(std::chrono::seconds(2));

                std::cout << "\nTips: Confirm that the new IP is available on the router or switch" << std::endl;
            }
            else
            {
                std::cerr << "Failed to change IP address: " << config_error.message() << std::endl;
            }
        }
    }

    // 4. Restart sensor (supported on all platforms)
    std::cout << "\n[3] Reboot the sensor? (supported on all platforms) (y/n): ";
    char confirm;
    std::cin >> confirm;

    if (confirm == 'y' || confirm == 'Y')
    {
        std::cout << "Sending reboot command..." << std::endl;
        std::cout << "Note: the sensor will reboot immediately after receiving the command" << std::endl;

        auto reboot_error = at_vision::rebootSensor(target_sensor);

        if (!reboot_error)
        {
            std::cout << "Sensor reboot command sent!" << std::endl;
            std::cout << "  Estimated reboot time: 30-60 seconds" << std::endl;
            std::cout << "  The sensor cannot be connected during reboot" << std::endl;

            // Wait for restart to complete
            std::cout << "\nWaiting for the sensor to reboot..." << std::endl;
            for (int i = 60; i > 0; --i)
            {
                std::cout << "\rRemaining " << i << " seconds...   " << std::flush;
                std::this_thread::sleep_for(std::chrono::seconds(1));
            }
            std::cout << std::endl;

            // 5. Rediscover sensors (verify restart success)
            std::cout << "\n[4] Rediscovering sensors..." << std::endl;
            std::error_code rediscover_ec;
            auto new_sensors = at_vision::discoverSensors(rediscover_ec, 3000);

            bool found = false;
            for (const auto& sensor : new_sensors)
            {
                if (sensor.sensorIp == target_sensor.sensorIp)
                {
                    std::cout << "Sensor is back online: " << sensor.sensorId << " (" << sensor.sensorIp << ")" << std::endl;
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                std::cerr << "Warning: the rebooted sensor was not found; it may need more time to start" << std::endl;
            }
        }
        else
        {
            std::cerr << "Sensor reboot failed: " << reboot_error.message() << std::endl;
            return 1;
        }
    }

    std::cout << "\n=== Demo completed ===" << std::endl;
    return 0;
}

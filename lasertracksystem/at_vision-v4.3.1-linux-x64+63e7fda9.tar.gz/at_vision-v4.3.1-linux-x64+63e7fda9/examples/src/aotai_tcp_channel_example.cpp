// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file aotai_tcp_channel_example.cpp
 * @brief AoTai TCP 常驻通道回调与缓存读取示例
 */

#include "at_vision/vision_core.h"
#include <chrono>
#include <iostream>
#include <mutex>
#include <thread>

namespace {

std::mutex outputMutex;

/// @brief 串行输出帧摘要，避免回调线程与主线程交叉写终端。
void PrintFrame(const char* source, const at_vision::AoTaiTcpStreamFrame& frame)
{
    std::lock_guard<std::mutex> lock(outputMutex);
    std::cout << source << ": sequence=" << frame.sequence_id << ", timestamp_ms=" << frame.timestamp_ms << ", job=" << static_cast<int>(frame.job_id)
              << ", point_valid=" << frame.point_valid << ", point=(" << frame.point.x << ", " << frame.point.y << ", " << frame.point.z
              << "), contour_valid=" << frame.contour_valid << ", contour_points=" << frame.contour.size() << '\n';
}

} // namespace

int main()
{
    std::error_code discoverError;
    const auto sensors = at_vision::discoverSensors(discoverError);
    if (discoverError || sensors.empty())
    {
        std::cerr << "No sensor discovered: " << discoverError.message() << '\n';
        return 1;
    }

    auto client = at_vision::createVision();
    const auto connectError = client->connect(sensors.front());
    if (connectError)
    {
        std::cerr << "Connect failed: " << connectError.message() << '\n';
        return 1;
    }
    std::cout << "Connected to sensor " << sensors.front().sensorIp << '\n';

    auto channel = client->getAoTaiTcpChannel();
    channel->setStreamCallback([](const at_vision::AoTaiTcpStreamFrame& frame) { PrintFrame("stream", frame); });

    const auto startError = channel->startStream();
    if (startError)
    {
        std::cerr << "Start stream failed: " << startError.message() << '\n';
        return 1;
    }
    std::cout << "Stream started, waiting 30 seconds...\n";

    std::this_thread::sleep_for(std::chrono::seconds(30));
    at_vision::AoTaiTcpStreamFrame latest;
    const auto latestError = channel->getLatestStreamFrame(latest);
    if (!latestError)
    {
        PrintFrame("latest", latest);
    }
    else
    {
        std::cout << "No stream frame received: " << latestError.message() << '\n';
    }

    const auto stopError = channel->stopStream();
    if (stopError)
    {
        std::cerr << "Stop stream warning: " << stopError.message() << '\n';
        return 1;
    }
    std::cout << "Stream stopped\n";
    return 0;
}

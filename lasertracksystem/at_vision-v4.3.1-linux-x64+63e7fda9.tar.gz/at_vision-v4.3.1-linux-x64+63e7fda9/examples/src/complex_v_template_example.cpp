// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file complex_v_template_example.cpp
 * @brief ComplexV weld template configuration example
 *
 * This example demonstrates the full workflow for configuring a ComplexV
 * weld template on a sensor:
 * - Discover sensors and connect
 * - Create a Process and a ComplexV Job
 * - Enable laser and receive laser profile data
 * - Build a template from feature points and 3D laser coordinates
 * - Update algorithm parameters with the template via updateAlgoParams
 * - Read back Job info to verify the template was stored
 *
 * @note The template is configured through JointComplexVAlgoInfoUpdate,
 *       which automatically serializes the template and sends it to the
 *       sensor via the TcpSetDbThinning RPC.
 */

#include <at_vision/vision_core.h>
#include <at_vision/algorithm_interface.h>
#include <at_vision/algorithm_type_def.h>
#include <at_vision/type_def.h>
#include <at_vision/logging.h>
#include <iostream>
#include <sstream>
#include <thread>
#include <chrono>
#include <algorithm>
#include <mutex>
#include <condition_variable>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

using namespace at_vision;

// ========== Helper functions ==========

void printSeparator(const std::string& title)
{
    std::cout << "\n========== " << title << " ==========\n" << std::endl;
}

std::vector<int> parseIntList(const std::string& text)
{
    std::vector<int> values;
    std::stringstream stream(text);
    std::string item;
    while (std::getline(stream, item, ','))
    {
        std::string trimmed;
        trimmed.reserve(item.size());
        for (unsigned char ch : item)
        {
            if (!std::isspace(ch))
            {
                trimmed.push_back(static_cast<char>(ch));
            }
        }
        if (!trimmed.empty())
        {
            values.push_back(std::stoi(trimmed));
        }
    }
    return values;
}

// ========== Main ==========

int main(int argc, char* argv[])
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    at_vision::logging::set_level(at_vision::logging::Level::Debug);

    std::cout << "ComplexV Template Configuration Demo" << std::endl;

    // ---------- 1. Discover sensors ----------
    printSeparator("Step 1: Discover Sensors");
    std::error_code discoverEc;
    auto sensors = at_vision::discoverSensors(discoverEc, 5000);
    if (sensors.empty())
    {
        std::cerr << "Error: no sensors found" << std::endl;
        if (discoverEc)
            std::cerr << "  " << discoverEc.message() << std::endl;
        return 1;
    }
    std::cout << "Found " << sensors.size() << " sensor(s)" << std::endl;
    for (size_t i = 0; i < sensors.size(); ++i)
    {
        std::cout << "  [" << i << "] " << sensors[i].sensorId << " (" << sensors[i].sensorIp << ") - " << sensors[i].sensorType << std::endl;
    }

    // ---------- 2. Connect to first sensor ----------
    printSeparator("Step 2: Connect Sensor");
    auto client = at_vision::createVision();
    auto connectEc = client->connect(sensors[0]);

    if (connectEc)
    {
        std::cerr << "Error: failed to connect: " << connectEc.message() << " (0x" << std::hex << connectEc.value() << std::dec << ")" << std::endl;
        return 1;
    }
    std::cout << "Connected to: " << sensors[0].sensorId << std::endl;

    // ---------- 3. Get algorithm interface ----------
    printSeparator("Step 3: Get Algorithm Interface");
    auto algo = client->getAlgorithmInterface();
    if (!algo)
    {
        std::cerr << "Error: failed to get algorithm interface" << std::endl;
        return 1;
    }
    std::cout << "Algorithm interface acquired" << std::endl;

    // ---------- 4. Ensure laser is off before modifying process/job ----------
    printSeparator("Step 4: Ensure Laser Off");
    algo->setLaserEnabled(false);

    // ---------- 5. Create Process ----------
    printSeparator("Step 5: Create Process");
    std::error_code ec;
    const std::string processName = "ComplexV Demo";

    // Clean up any existing process with the same name
    auto processes = algo->getProcessList(ec);
    if (ec)
    {
        std::cerr << "Failed to get Process list: " << ec.message() << std::endl;
        return 1;
    }
    auto it = std::find_if(processes.begin(), processes.end(), [&](const ProcessInfo& p) { return p.name == processName; });
    if (it != processes.end())
    {
        std::cout << "Deleting existing process: " << it->name << " (ID: " << it->id << ")" << std::endl;
        ec = algo->deleteProcess(it->id);
        if (ec)
        {
            std::cerr << "Error: failed to delete existing process: " << ec.message() << std::endl;
            return 1;
        }
    }

    auto process = algo->addProcess(processName, "demo", "ComplexV template configuration demo", ec);
    if (ec)
    {
        std::cerr << "Error: failed to create process: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "Created process: " << process.name << " (ID: " << process.id << ")" << std::endl;

    // ---------- 6. Create ComplexV Job ----------
    printSeparator("Step 6: Create ComplexV Job");
    auto job = algo->addJob(process.id, SeamType::ComplexV, 100, "demo_complex_v", ec);
    if (ec)
    {
        std::cerr << "Error: failed to create ComplexV job: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "Created job: " << job.name << " (ID: " << job.id << ")" << std::endl;

    // ---------- 7. Switch to the Job ----------
    printSeparator("Step 7: Switch to Job");
    job = algo->switchJob(job, ec);
    if (ec)
    {
        std::cerr << "Error: failed to switch job: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "Switched to job: " << job.name << " (ID: " << job.id << ")" << std::endl;

    // Verify algo_info is populated
    auto complexVInfo = std::dynamic_pointer_cast<JointComplexVAlgoInfo>(job.algo_info);
    if (!complexVInfo)
    {
        std::cerr << "Error: algo_info is not JointComplexVAlgoInfo" << std::endl;
        return 1;
    }
    std::cout << "Algo info loaded, template_threshold=" << complexVInfo->template_threshold << std::endl;

    // ---------- 8. Enable laser and collect profile data ----------
    printSeparator("Step 8: Enable Laser and Collect Data");

    std::mutex resultMutex;
    std::condition_variable resultCv;
    LaserSeamResult laserResult;
    bool laserReceived = false;

    client->setLaserSeamResultCallback([&](const LaserSeamResult& result) {
        if (result.laser_state == LaserSeamResult::MANUAL_OPEN || result.laser_state == LaserSeamResult::MACHINE_OPEN)
        {
            std::lock_guard<std::mutex> lock(resultMutex);
            laserResult = result;
            laserReceived = true;
            resultCv.notify_all();
        }
    });

    auto laserEc = algo->setLaserEnabled(true);
    if (laserEc)
    {
        std::cerr << "Error: failed to enable laser: " << laserEc.message() << std::endl;
        return 1;
    }
    std::cout << "Laser enabled, waiting for profile data..." << std::endl;

    // Wait for laser data (up to 10 seconds)
    {
        auto lk = std::unique_lock<std::mutex>(resultMutex);
        if (!resultCv.wait_for(lk, std::chrono::seconds(10), [&] { return laserReceived; }))
        {
            std::cerr << "Error: timeout waiting for laser data" << std::endl;
            algo->setLaserEnabled(false);
            return 1;
        }
    }

    std::cout << "Received laser profile:" << std::endl;
    std::cout << "  Job Number: " << laserResult.current_job_no << std::endl;
    std::cout << "  Laser 2D size: " << laserResult.laser.size() << std::endl;
    std::cout << "  Laser 3D rows: " << laserResult.laser_3D.size() << std::endl;

    // Disable laser
    algo->setLaserEnabled(false);
    std::cout << "Laser disabled" << std::endl;

    // ---------- 9. Build template from laser data ----------
    printSeparator("Step 9: Build Template");

    // Example feature points selected from the laser profile.
    // In a real application, these would be chosen based on the weld geometry.
    std::vector<int> featurePoints = {587, 702, 801, 881, 973, 1145, 1290, 1387};

    JointComplexVAlgoTemplate tmpl;
    tmpl.laser = laserResult.laser;
    tmpl.laser_3D = laserResult.laser_3D;
    tmpl.feature_points = featurePoints;
    tmpl.template_weld_index = 3; // weld point is featurePoints[3], the fourth feature point

    // Validate template by serializing it (triggers all validation checks)
    std::string tmplJson;
    auto serializeEc = tmpl.serialize(tmplJson);
    if (serializeEc)
    {
        std::cerr << "Error: template validation failed: " << serializeEc.message() << std::endl;
        return 1;
    }
    std::cout << "Template validated successfully" << std::endl;
    std::cout << "  Feature points: " << featurePoints.size() << std::endl;

    // ---------- 10. Update algorithm parameters ----------
    printSeparator("Step 10: Update Algorithm Parameters");

    JointComplexVAlgoInfoUpdate update;
    update.complex_v_algo_template = tmpl;
    update.template_threshold = 3.5;

    ec = algo->updateAlgoParams(job, update);
    if (ec)
    {
        std::cerr << "Error: failed to update algo params: " << ec.message() << std::endl;
        return 1;
    }
    std::cout << "Algorithm parameters updated successfully" << std::endl;

    // ---------- 11. Verify by reading back ----------
    printSeparator("Step 11: Verify Template (Read Back)");

    auto verifyJob = algo->getJobInfo(job.id, ec);
    if (ec)
    {
        std::cerr << "Error: failed to get job info: " << ec.message() << std::endl;
        return 1;
    }

    auto verifyInfo = std::dynamic_pointer_cast<JointComplexVAlgoInfo>(verifyJob.algo_info);
    if (verifyInfo)
    {
        std::cout << "Read-back verification:" << std::endl;
        std::cout << "  laser size: " << verifyInfo->laser.size() << std::endl;
        std::cout << "  feature_points size: " << verifyInfo->feature_points.size() << std::endl;
        std::cout << "  distance_points size: " << verifyInfo->distance_points.size() << std::endl;
        std::cout << "  template_threshold: " << verifyInfo->template_threshold << std::endl;
        std::cout << "  template_weld_index: " << verifyInfo->template_weld_index << std::endl;

        if (verifyInfo->laser == tmpl.laser && verifyInfo->feature_points == tmpl.feature_points)
        {
            std::cout << "  [OK] Template data matches!" << std::endl;
        }
        else
        {
            std::cout << "  [WARN] Template data differs from what was sent" << std::endl;
        }
    }

    // ---------- Done ----------
    printSeparator("Complete");
    std::cout << "ComplexV template demo finished successfully." << std::endl;
    return 0;
}

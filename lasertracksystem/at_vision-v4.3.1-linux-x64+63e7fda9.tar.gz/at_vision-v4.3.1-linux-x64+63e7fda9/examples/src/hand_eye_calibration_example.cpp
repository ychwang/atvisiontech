// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file hand_eye_calibration_example.cpp
 * @brief Hand-eye calibration interface demonstration program
 *
 * This example demonstrates how to use getHandEyeCalibration() to obtain the hand-eye calibration interface,
 * and through calibrate() submit structured input data, read structured calibration results.
 */

#include <at_vision/vision_core.h>
#include <iostream>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;

int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    std::cout << "at_vision hand-eye calibration example" << std::endl;

    std::error_code discover_ec;
    auto sensors = discoverSensors(discover_ec, 5000);
    if (sensors.empty())
    {
        std::cerr << "No sensors found";
        if (discover_ec)
        {
            std::cerr << ": " << discover_ec.message();
        }
        std::cerr << std::endl;
        return 1;
    }

    auto client = createVision();
    if (!client)
    {
        std::cerr << "Failed to create client" << std::endl;
        return 1;
    }

    const auto connect_ec = client->connect(sensors.front());
    if (connect_ec)
    {
        std::cerr << "Failed to connect to sensor: " << connect_ec.message() << std::endl;
        return 1;
    }

    auto hand_eye = client->getHandEyeCalibration();
    if (!hand_eye)
    {
        std::cerr << "Failed to get hand-eye calibration interface" << std::endl;
        return 1;
    }

    // ====== Valid input ======
    HandEyeCalibrationInput input;
    input.tcp_position = {0.0, 0.0, 200.0, 0.0, 0.0, 0.0};
    input.base_position = {500.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    input.robot_points = {
        {100.0, 100.0, 100.0, 0.0, 0.0, 0.0},
        {200.0, 100.0, 100.0, 0.0, 0.0, 0.0},
        {150.0, 150.0, 100.0, 0.0, 0.0, 0.0}
    };
    input.sensor_points = {
        {1.0, 2.0, 3.0},
        {2.0, 2.0, 3.0},
        {1.5, 2.5, 3.0}
    };

    std::cout << "\n====== [Valid input] ======" << std::endl;
    std::error_code ec;
    HandEyeCalibrationOutput output = hand_eye->calibrate(input, ec);
    if (ec)
    {
        std::cerr << "Hand-eye calibration call failed: " << ec.message() << std::endl;
    }
    std::cout << "success: " << (output.success ? "true" : "false") << std::endl;
    std::cout << "error_message: " << output.error_message << std::endl;
    std::cout << "result(xyzwpr): " << output.result.x << ", " << output.result.y << ", " << output.result.z << ", " << output.result.w << ", "
              << output.result.p << ", " << output.result.r << std::endl;
    std::cout << "error_matrix:" << std::endl;
    std::cout << "[" << output.error_matrix[0][0] << ", " << output.error_matrix[0][1] << ", " << output.error_matrix[0][2] << "]" << std::endl;
    std::cout << "[" << output.error_matrix[1][0] << ", " << output.error_matrix[1][1] << ", " << output.error_matrix[1][2] << "]" << std::endl;
    std::cout << "[" << output.error_matrix[2][0] << ", " << output.error_matrix[2][1] << ", " << output.error_matrix[2][2] << "]" << std::endl;

    // ====== Error case 1: insufficient robot points ======
    HandEyeCalibrationInput input_few_robot;
    input_few_robot.tcp_position = input.tcp_position;
    input_few_robot.base_position = input.base_position;
    input_few_robot.robot_points = { {100.0, 100.0, 100.0, 0.0, 0.0, 0.0} };
    input_few_robot.sensor_points = input.sensor_points;
    std::cout << "\n====== [Insufficient robot points] ======" << std::endl;
    output = hand_eye->calibrate(input_few_robot, ec);
    std::cout << "success: " << (output.success ? "true" : "false") << std::endl;
    std::cout << "error_message: " << output.error_message << std::endl;

    // ====== Error case 2: insufficient sensor points ======
    HandEyeCalibrationInput input_few_sensor = input;
    input_few_sensor.sensor_points = { {1.0, 2.0, 3.0} };
    std::cout << "\n====== [Insufficient sensor points] ======" << std::endl;
    output = hand_eye->calibrate(input_few_sensor, ec);
    std::cout << "success: " << (output.success ? "true" : "false") << std::endl;
    std::cout << "error_message: " << output.error_message << std::endl;

    // ====== Error case 3: point count mismatch ======
    HandEyeCalibrationInput input_mismatch = input;
    input_mismatch.robot_points.push_back({300.0, 100.0, 100.0, 0.0, 0.0, 0.0});
    std::cout << "\n====== [Point count mismatch] ======" << std::endl;
    output = hand_eye->calibrate(input_mismatch, ec);
    std::cout << "success: " << (output.success ? "true" : "false") << std::endl;
    std::cout << "error_message: " << output.error_message << std::endl;



    return output.success ? 0 : 2;
}

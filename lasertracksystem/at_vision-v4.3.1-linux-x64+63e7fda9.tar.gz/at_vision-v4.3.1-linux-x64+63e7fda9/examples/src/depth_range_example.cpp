// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file depth_range_example.cpp
 * @brief Demonstrates reading and setting the sensor depth-of-field range.
 *
 * This example connects to the first discovered sensor, reads supported depth
 * limits and the current depth range, and optionally sets a new range.
 *
 * Usage:
 *   depth_range_example
 *   depth_range_example --set 80 650
 */

#include <at_vision/setting_interface.h>
#include <at_vision/vision_core.h>
#include <cstdlib>
#include <iostream>
#include <string>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;

namespace {

struct Options {
    bool setRange = false;
    DepthRange range;
};

void printUsage(const char* programName)
{
    std::cout << "Usage:\n"
              << "  " << programName << "\n"
              << "  " << programName << " --set <min_mm> <max_mm>\n";
}

bool parseInteger(const char* text, int& value)
{
    char* end = nullptr;
    const long parsed = std::strtol(text, &end, 10);
    value = static_cast<int>(parsed);
    return end != text && *end == '\0';
}

bool parseOptions(int argc, char* argv[], Options& options)
{
    if (argc == 1)
    {
        return true;
    }
    if (argc == 4 && std::string(argv[1]) == "--set")
    {
        options.setRange = true;
        return parseInteger(argv[2], options.range.min) && parseInteger(argv[3], options.range.max);
    }
    return false;
}

bool confirmWrite(const DepthRange& range)
{
    std::cout << "\nAbout to set depth range to " << range.min << " - " << range.max << " mm." << std::endl;
    std::cout << "This updates camera ROI settings and may require service restart to fully take effect." << std::endl;
    std::cout << "Continue? (y/n): ";

    char answer = 'n';
    std::cin >> answer;
    return answer == 'y' || answer == 'Y';
}

} // namespace

int main(int argc, char* argv[])
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    Options options;
    if (!parseOptions(argc, argv, options))
    {
        printUsage(argv[0]);
        return 1;
    }

    std::error_code discoverEc;
    auto sensors = discoverSensors(discoverEc, 3000);
    if (sensors.empty())
    {
        std::cerr << "No sensors found";
        if (discoverEc)
        {
            std::cerr << ": " << discoverEc.message();
        }
        std::cerr << std::endl;
        return 1;
    }

    const auto& sensor = sensors.front();
    std::cout << "Selected sensor: " << sensor.sensorId << " (" << sensor.sensorIp << "), type=" << sensor.sensorType << std::endl;

    auto client = createVision();
    const auto connectEc = client->connect(sensor);
    if (connectEc)
    {
        std::cerr << "Failed to connect: " << connectEc.message() << std::endl;
        return 1;
    }

    auto settings = client->getSettings();
    if (!settings)
    {
        std::cerr << "Failed to get settings interface" << std::endl;
        return 1;
    }

    DepthRange limits;
    auto ec = settings->getDepthLimits(limits);
    if (ec)
    {
        std::cerr << "Failed to get depth limits: " << ec.message() << std::endl;
        return 1;
    }

    DepthRange current;
    ec = settings->getDepthRange(current);
    if (ec)
    {
        std::cerr << "Failed to get current depth range: " << ec.message() << std::endl;
        return 1;
    }

    std::cout << "Maximum depth limits: " << limits.min << " - " << limits.max << " mm" << std::endl;
    std::cout << "Current depth range: " << current.min << " - " << current.max << " mm" << std::endl;

    if (!options.setRange)
    {
        std::cout << "\nPass --set <min_mm> <max_mm> to set a new depth range." << std::endl;
        return 0;
    }

    // Reading is available even when the model does not allow depth settings.
    if (!settings->isDepthRangeSupported())
    {
        std::cerr << "The selected sensor supports reading depth ranges only." << std::endl;
        return 1;
    }

    ec = settings->validateDepthRange(options.range);
    if (ec)
    {
        std::cerr << "Depth range validation failed: " << ec.message() << std::endl;
        return 1;
    }

    if (!confirmWrite(options.range))
    {
        std::cout << "Operation cancelled" << std::endl;
        return 0;
    }

    ec = settings->setDepthRange(options.range);
    if (ec)
    {
        std::cerr << "Failed to set depth range: " << ec.message() << std::endl;
        return 1;
    }

    std::cout << "Depth range update command sent successfully." << std::endl;
    return 0;
}

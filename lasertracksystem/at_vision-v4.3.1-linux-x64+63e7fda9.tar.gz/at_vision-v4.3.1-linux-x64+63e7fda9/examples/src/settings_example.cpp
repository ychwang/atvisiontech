// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file settings_example.cpp
 * @brief Complete settings interface demonstration program
 *
 * This example demonstrates how to use the ISettings interface to configure sensor runtime parameters, including:
 * - Image transmission quality settings (Compressed/Original)
 * - Image Transfer Mode Setting
 * - Serial Port Configuration (only WINDOWS_X64 Platform support)
 * - Camera IP address configuration
 * - Depth-of-field range query and setting
 *
 * - Robot configuration management (full and partial updates)
 * Each function demonstration includes three steps: read, set, and verify, to help
 * users understand how to use the settings interface.
 */

#include <at_vision/vision_core.h>
#include <at_vision/type_def.h>
#include <iostream>
#include <iomanip>
#include <thread>
#include <chrono>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;

/**
 * @brief Print separator line (for beautifying output)
 */
void print_separator(const std::string& title)
{
    std::cout << "\n========== " << title << " ==========\n" << std::endl;
}

/**
 * @brief Print image quality enum values
 */
std::string imageQualityToString(ImageQuality quality)
{
    switch (quality)
    {
    case ImageQuality::Compressed:
        return "Compressed";
    case ImageQuality::Original:
        return "Original";
    default:
        return "Unknown";
    }
}

/**
 * @brief Print transmission mode enum values
 */
std::string transferModeToString(ImageTransferMode mode)
{
    switch (mode)
    {
    case ImageTransferMode::ImageOnly:
        return "ImageOnly";
    case ImageTransferMode::LaserOnly:
        return "LaserOnly";
    case ImageTransferMode::Both:
        return "Both";
    default:
        return "Unknown";
    }
}

/**
 * @brief Print robot type enum values
 */
std::string robotTypeToString(RobotType type)
{
    switch (type)
    {
    case RobotType::None:
        return "None";
    case RobotType::Fanuc:
        return "Fanuc";
    case RobotType::ABB:
        return "ABB";
    case RobotType::KUKA:
        return "KUKA";
    case RobotType::Kawasaki:
        return "Kawasaki";
    case RobotType::Yaskawa:
        return "Yaskawa";
    case RobotType::Estun:
        return "Estun";
    case RobotType::EFORT:
        return "EFORT";
    case RobotType::GSK:
        return "GSK";
    case RobotType::Xinsida:
        return "Xinsida";
    case RobotType::Qianjiang:
        return "Qianjiang";
    case RobotType::AotaiTcpIp:
        return "AotaiTcpIp";
    case RobotType::AotaiModbus:
        return "AotaiModbus";
    case RobotType::Other:
        return "Other";
    case RobotType::Nabot:
        return "Nabot";
    case RobotType::Zhiliuxing:
        return "Zhiliuxing";
    case RobotType::AotaiLibModbus:
        return "AotaiLibModbus";
    case RobotType::Daniu:
        return "Daniu";
    case RobotType::Siasun:
        return "Siasun";
    case RobotType::Kaindi:
        return "Kaindi";
    case RobotType::Mufei:
        return "Mufei";
    case RobotType::Canopus:
        return "Canopus";
    case RobotType::Chaifu:
        return "Chaifu";
    case RobotType::Chuanxi:
        return "Chuanxi";
    case RobotType::AUBO:
        return "AUBO";
    case RobotType::Xinkong:
        return "Xinkong";
    case RobotType::Yunhua:
        return "Yunhua";
    case RobotType::CanopusB:
        return "CanopusB";
    case RobotType::YaskawaAT:
        return "YaskawaAT";
    case RobotType::KUKAB:
        return "KUKAB";
    case RobotType::Brant:
        return "Brant";
    case RobotType::PipelineSpecial:
        return "PipelineSpecial";
    case RobotType::ATXD:
        return "ATXD";
    case RobotType::HRG:
        return "HRG";
    case RobotType::Luoshi:
        return "Luoshi";
    case RobotType::Canopus25:
        return "Canopus25";
    case RobotType::PipelineTrolley:
        return "PipelineTrolley";
    default:
        return "Unknown";
    }
}

/**
 * @brief Demo Image Quality Setting
 */
void example_image_quality(ISettings* settings)
{
    print_separator("Image Quality Setting");

    // 1. Read current settings
    std::error_code ec;
    auto currentQuality = settings->getImageQuality(ec);
    if (ec)
    {
        std::cerr << "Failed to get image quality: " << ec.message() << std::endl;
        return;
    }
    std::cout << "Current image quality: " << imageQualityToString(currentQuality) << std::endl;
    std::cout << "\nDescription:\n";
    std::cout << "  Compressed - compressed transfer, lower quality, faster speed\n";
    std::cout << "  Original  - original transfer, higher quality, slower speed\n";

    // 2. Switch to another mode
    ImageQuality newQuality = (currentQuality == ImageQuality::Compressed) ? ImageQuality::Original : ImageQuality::Compressed;
    std::cout << "\nTrying to switch to: " << imageQualityToString(newQuality) << std::endl;

    ec = settings->setImageQuality(newQuality);
    if (!ec)
    {
        std::cout << "✓ Image quality set successfully" << std::endl;
    }
    else
    {
        std::cerr << "✗ Failed to set image quality: " << ec.message() << std::endl;
        return;
    }

    // 3. Verify settings
    auto verifyQuality = settings->getImageQuality(ec);
    if (ec)
    {
        std::cerr << "Failed to get image quality: " << ec.message() << std::endl;
        settings->setImageQuality(currentQuality);
        return;
    }
    std::cout << "Verification result: " << imageQualityToString(verifyQuality) << std::endl;

    if (verifyQuality == newQuality)
    {
        std::cout << "Setting verification succeeded" << std::endl;
    }
    else
    {
        std::cerr << "Setting verification failed" << std::endl;
    }

    // 4. Restore original setting
    std::cout << "\nRestoring original setting..." << std::endl;
    settings->setImageQuality(currentQuality);
}

/**
 * @brief Demo Image Transfer Mode Setting
 */
void example_transfer_mode(ISettings* settings)
{
    print_separator("Transfer Mode Setting");

    // 1. Read current settings
    auto currentMode = settings->getImageTransferMode();
    std::cout << "Current transfer mode: " << transferModeToString(currentMode) << std::endl;
    std::cout << "\nDescription:\n";
    std::cout << "  ImageOnly  - image only\n";
    std::cout << "  LaserOnly  - laser only\n";
    std::cout << "  Both       - image and laser line\n";

    // 2. Switch through all modes
    std::cout << "\nSwitching through all modes:" << std::endl;
    ImageTransferMode modes[] = {ImageTransferMode::ImageOnly, ImageTransferMode::LaserOnly, ImageTransferMode::Both};

    for (auto mode : modes)
    {
        if (mode == currentMode)
        {
            continue; // Skip current mode
        }

        std::cout << "\nSwitching to: " << transferModeToString(mode) << std::endl;
        auto ec = settings->setImageTransferMode(mode);
        if (!ec)
        {
            std::cout << "Set successfully" << std::endl;
            std::this_thread::sleep_for(std::chrono::milliseconds(500)); // Short delay
        }
        else
        {
            std::cerr << "Set failed: " << ec.message() << std::endl;
            break;
        }
    }

    // 3. Restore original setting
    std::cout << "\nRestoring original setting: " << transferModeToString(currentMode) << std::endl;
    settings->setImageTransferMode(currentMode);
}

/**
 * @brief Demo Serial Port Configuration (WINDOWS_X64 Platform only)
 */
void example_serial_port(ISettings* settings, const std::string& platform)
{
    print_separator("Serial Port Configuration");

    if (platform != "WINDOWS_X64")
    {
        std::cout << "Current sensor platform: " << platform << std::endl;
        std::cout << "Serial port configuration is only supported on WINDOWS_X64" << std::endl;
        std::cout << "Skipping this demo" << std::endl;
        return;
    }

    // 1. Read current serial port
    SerialPort currentPort;
    auto ec = settings->getSerialPort(currentPort);
    if (ec)
    {
        std::cerr << "Failed to read serial port: " << ec.message() << std::endl;
        return;
    }

    std::cout << "Current serial port: COM" << static_cast<int>(currentPort) << std::endl;

    // 2. Switch to next available serial port
    SerialPort newPort = static_cast<SerialPort>((static_cast<int>(currentPort) % 20) + 1);
    std::cout << "Trying to switch to: COM" << static_cast<int>(newPort) << std::endl;

    ec = settings->setSerialPort(newPort);
    if (!ec)
    {
        std::cout << "Serial port set successfully" << std::endl;
    }
    else
    {
        std::cerr << "Failed to set serial port: " << ec.message() << std::endl;
        return;
    }

    // 3. Verify settings
    SerialPort verifyPort;
    ec = settings->getSerialPort(verifyPort);
    if (!ec && verifyPort == newPort)
    {
        std::cout << "Verification result: COM" << static_cast<int>(verifyPort) << std::endl;
        std::cout << "Setting verification succeeded" << std::endl;
    }
    else
    {
        std::cerr << "Setting verification failed" << std::endl;
    }

    // 4. Restore original setting
    std::cout << "\nRestoring original setting: COM" << static_cast<int>(currentPort) << std::endl;
    settings->setSerialPort(currentPort);
}

/**
 * @brief Demo Camera IP Configuration
 */
void example_camera_ip(ISettings* settings)
{
    print_separator("Camera IP Configuration");

    // 1. Read current camera IP
    std::string currentIp;
    auto ec = settings->getCameraIp(currentIp);
    if (ec)
    {
        std::cerr << "Failed to read camera IP: " << ec.message() << std::endl;
        return;
    }

    std::cout << "Current camera IP: " << (currentIp.empty() ? "(not set)" : currentIp) << std::endl;

    // 2. Try to set new IP
    // Note: This is for demo only, not actually modifying IP
    std::string newIp = "192.168.1.100";
    std::cout << "\nIP format requirements demo:\n";
    std::cout << "  - Must be a class C address (192.0.0.0 - 223.255.255.255)\n";
    std::cout << "  - Must not start with 127\n";
    std::cout << "  - Last octet must not be 0, 1, or 255\n";
    std::cout << "  - Must not be an APIPA address (169.254.x.x)\n";

    std::cout << "\nTo change the camera IP, use the following code; this demo does not modify it:\n";
    std::cout << "  settings->setCameraIp(\"" << newIp << "\");" << std::endl;

    // 3. Actually verify IP format
    std::cout << "\nIP address format validation: " << newIp << std::endl;
    bool valid = true;
    // Simple format check
    if (newIp.find("192.168.1.") != 0)
    {
        valid = false;
    }
    std::cout << (valid ? "OK:" : "FAIL:") << " IP format " << (valid ? "valid" : "invalid") << std::endl;

    std::cout << "\nTips: Uncomment the following code for real testing in actual use\n";
}

/**
 * @brief Demo Depth-of-field Range Configuration
 */
void example_depth_range(ISettings* settings)
{
    print_separator("Depth Range Configuration");

    DepthRange limits;
    auto ec = settings->getDepthLimits(limits);
    if (ec)
    {
        std::cerr << "Failed to read depth limits: " << ec.message() << std::endl;
        return;
    }

    DepthRange current;
    ec = settings->getDepthRange(current);
    if (ec)
    {
        std::cerr << "Failed to read current depth range: " << ec.message() << std::endl;
        return;
    }

    std::cout << "Depth limits: " << limits.min << " - " << limits.max << " mm\n";
    std::cout << "Current depth range: " << current.min << " - " << current.max << " mm\n";
    // Setting support only controls write guidance; known models can still read ranges.
    if (!settings->isDepthRangeSupported())
    {
        std::cout << "Depth range settings are not supported by the current sensor." << std::endl;
        return;
    }

    std::cout << "\nTo change the depth range, use code like this; this demo does not modify it:\n";
    std::cout << "  DepthRange range{" << current.min << ", " << current.max << "};\n";
    std::cout << "  auto ec = settings->setDepthRange(range);" << std::endl;
}

/**
 * @brief Demo Robot Full Configuration
 */
void example_robot_config_full(ISettings* settings)
{
    print_separator("Robot Configuration - Full Setting");

    // 1. Read current configuration
    RobotConf currentConfig;
    auto ec = settings->getRobotConfig(currentConfig);
    if (ec)
    {
        std::cerr << "Failed to read robot configuration: " << ec.message() << std::endl;
        return;
    }

    std::cout << "Current robot configuration:\n";
    std::cout << "  Type: " << robotTypeToString(currentConfig.robot_type) << "\n";
    std::cout << "  IP:   " << currentConfig.robot_ip << "\n";
    std::cout << "  Port: " << currentConfig.robot_port << std::endl;

    // 2. Set full new configuration
    RobotConfUpdate newConfig;
    newConfig.robot_type = RobotType::AUBO;
    newConfig.robot_ip = "192.168.1.200";
    newConfig.robot_port = 5020;

    std::cout << "\nSetting new configuration:\n";
    std::cout << "  Type: " << robotTypeToString(newConfig.robot_type.value()) << "\n";
    std::cout << "  IP:   " << newConfig.robot_ip.value() << "\n";
    std::cout << "  Port: " << (newConfig.robot_port ? std::to_string(*newConfig.robot_port) : "not set") << std::endl;

    ec = settings->setRobotConfig(newConfig);
    if (!ec)
    {
        std::cout << "Robot configuration set successfully" << std::endl;
    }
    else
    {
        std::cerr << "Failed to set robot configuration: " << ec.message() << std::endl;
        return;
    }

    // 3. Verify settings
    RobotConf verifyConfig;
    ec = settings->getRobotConfig(verifyConfig);
    if (!ec && verifyConfig.robot_ip == newConfig.robot_ip)
    {
        std::cout << "Setting verification succeeded" << std::endl;
    }
    else
    {
        std::cerr << "Setting verification failed" << std::endl;
    }
}

/**
 * @brief Demo Robot Partial Configuration (incremental update)
 */
void example_robot_config_partial(ISettings* settings)
{
    print_separator("Robot Configuration - Partial Update");

    // 1. Read current configuration
    RobotConf currentConfig;
    auto ec = settings->getRobotConfig(currentConfig);
    if (ec)
    {
        std::cerr << "Failed to read robot configuration: " << ec.message() << std::endl;
        return;
    }

    std::cout << "Current configuration:\n";
    std::cout << "  Type: " << robotTypeToString(currentConfig.robot_type) << "\n";
    std::cout << "  IP:   " << currentConfig.robot_ip << "\n";
    std::cout << "  Port: " << currentConfig.robot_port << std::endl;

    // 2. Only update IP address (other fields remain unchanged)
    std::string newIp = "192.168.1.201";
    std::cout << "\nUpdating only IP address to: " << newIp << std::endl;
    std::cout << "(Other configuration remains unchanged)" << std::endl;

    RobotConfUpdate update;
    update.robot_ip = newIp; // Only set IP, other fields keep default (not updated)

    ec = settings->setRobotConfig(update);
    if (!ec)
    {
        std::cout << "Partial update succeeded" << std::endl;
    }
    else
    {
        std::cerr << "Partial update failed: " << ec.message() << std::endl;
        return;
    }

    // 3. Verify settings
    RobotConf verifyConfig;
    ec = settings->getRobotConfig(verifyConfig);
    if (!ec)
    {
        std::cout << "\nVerification result:\n";
        std::cout << "  Type: " << robotTypeToString(verifyConfig.robot_type) << "\n";
        std::cout << "  IP:   " << verifyConfig.robot_ip << "\n";
        std::cout << "  Port: " << verifyConfig.robot_port << std::endl;
        std::cout << "Verification completed" << std::endl;
    }
    else
    {
        std::cerr << "Verification failed" << std::endl;
    }
}

int main()
{
#ifdef _WIN32
    // [Key] Set console output to UTF-8
    SetConsoleOutputCP(CP_UTF8); // 65001
    SetConsoleCP(CP_UTF8);       // Input also set to UTF-8 (optional)
#endif

    std::cout << "========================================\n";
    std::cout << "   at_vision settings interface demo\n";
    std::cout << "========================================\n\n";

    // 1. Discover Sensors
    std::cout << "[1/2] Searching for sensors..." << std::endl;
    std::error_code discover_ec;
    auto sensors = discoverSensors(discover_ec, 3000);

    if (sensors.empty())
    {
        std::cerr << "No sensors found. Please check the network connection";
        if (discover_ec)
        {
            std::cerr << " (" << discover_ec.message() << ")";
        }
        std::cerr << std::endl;
        return 1;
    }

    std::cout << "Discovered " << sensors.size() << " sensor(s):\n";
    for (size_t i = 0; i < sensors.size(); ++i)
    {
        std::cout << "  [" << i << "] " << sensors[i].sensorId << " (" << sensors[i].sensorIp << ")" << std::endl;
    }

    // 2. Connect to sensor
    const auto& sensor = sensors[0];
    std::cout << "\n[2/2] Connecting to sensor: " << sensor.sensorId << std::endl;

    auto client = createVision();
    auto connectEc = client->connect(sensor);

    if (connectEc)
    {
        std::cerr << "Connection failed: " << connectEc.message() << std::endl;
        return 1;
    }

    std::cout << "Connected successfully, SDK version: " << client->getVersion() << std::endl;

    // 3. Get settings interface
    auto settings = client->getSettings();
    if (!settings)
    {
        std::cerr << "Failed to get settings interface" << std::endl;
        return 1;
    }

    std::cout << "\n========================================\n";
    std::cout << "   Starting settings interface demo\n";
    std::cout << "========================================\n";

    // 4. Execute demos
    example_image_quality(settings.get());
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    example_transfer_mode(settings.get());
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    example_serial_port(settings.get(), sensor.platform);
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    example_camera_ip(settings.get());
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    example_depth_range(settings.get());
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    example_robot_config_full(settings.get());
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    example_robot_config_partial(settings.get());

    // 5. Complete
    std::cout << "\n========================================\n";
    std::cout << "   Demo completed\n";
    std::cout << "========================================\n";
    std::cout << "\nAll settings interface demos completed!" << std::endl;

    return 0;
}

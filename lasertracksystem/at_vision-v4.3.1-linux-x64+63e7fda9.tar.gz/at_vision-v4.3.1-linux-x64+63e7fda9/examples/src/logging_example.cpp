// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file logging_example.cpp
 * @brief Demonstrate log level and console output switch
 */

#include <at_vision/logging.h>
#include <at_vision/vision_core.h>
#include <iostream>
#include <thread>
#include <chrono>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;

int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    std::cout << "at_vision logging example" << std::endl;

    std::cout << "\n1. Set log level to Debug" << std::endl;
    logging::set_level(logging::Level::Debug);

    std::cout << "2. Enable console output" << std::endl;
    logging::enable_console();

    std::cout << "3. Trigger one SDK call to generate logs" << std::endl;
    std::error_code discover_ec;
    const auto sensors = discoverSensors(discover_ec, 1000);
    std::cout << "Discovered sensor count: " << sensors.size() << std::endl;

    std::cout << "\n4. Switch log level to Warn" << std::endl;
    logging::set_level(logging::Level::Warn);
    discoverSensors(discover_ec, 500);

    std::cout << "5. Disable console output" << std::endl;
    logging::disable_console();

    std::cout << "6. Restore log level to Info" << std::endl;
    logging::set_level(logging::Level::Info);

    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    return 0;
}

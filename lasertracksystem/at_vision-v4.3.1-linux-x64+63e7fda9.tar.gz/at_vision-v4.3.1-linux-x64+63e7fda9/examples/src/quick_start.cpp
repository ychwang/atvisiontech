// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file quick_start.cpp
 * @brief The simplest sensor discovery example - suitable for quick testing
 *
 * This example demonstrates how to use the discoverSensors() function to quickly search for sensor devices on the network.
 * It is suitable for verifying that the SDK and network environment are functioning normally.
 *
 * Use cases:
 * - First time using the SDK, verify network connectivity
 * - Quick check if sensors are online
 * - Integrate into automated test scripts
 */

#include <at_vision/vision_core.h>
#include <iostream>
#include <iomanip>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;

int main()
{
#ifdef _WIN32
    // [Key] Set console output to UTF-8 encoding for proper display
    SetConsoleOutputCP(CP_UTF8); // 65001
    SetConsoleCP(CP_UTF8);       // Input also set to UTF-8 (optional)
#endif

    std::cout << "========================================\n";
    std::cout << "   at_vision quick start example\n";
    std::cout << "========================================\n\n";

    std::cout << "Searching for sensors...\n";

    std::error_code discover_ec;
    // Discover Sensors (3 second timeout)
    // Parameter Description:
    //   - Timeout: 3000 ms (3 seconds)
    //   - Discovery method: UDP broadcast (Port 8000 and 15555)
    auto sensors = discoverSensors(discover_ec, 3000);

    // Display results
    if (sensors.empty())
    {
        std::cout << "No sensors found\n\n";
        if (discover_ec)
        {
            std::cout << "Error message: " << discover_ec.message() << "\n";
        }
        std::cout << "Tips:\n";
        std::cout << "  1. Make sure the sensor is powered on and connected to the same network\n";
        std::cout << "  2. Check whether the firewall allows UDP ports 8000 and 15555\n";
        std::cout << "  3. Make sure the network adapter is enabled\n";
        return 1;
    }

    std::cout << "Discovered " << sensors.size() << " sensor(s)\n\n";
    std::cout << std::string(60, '-') << "\n";
    std::cout << std::left << std::setw(5) << "No." << std::setw(25) << "Sensor ID" << std::setw(20) << "IP address"
              << "Status\n";
    std::cout << std::string(60, '-') << "\n";

    for (size_t i = 0; i < sensors.size(); ++i)
    {
        const auto& s = sensors[i];
        std::cout << std::left << std::setw(5) << "[" + std::to_string(i + 1) + "]" << std::setw(25) << s.sensorId << std::setw(20) << s.sensorIp
                  << static_cast<int>(s.sensorStatus) << "\n";
    }

    std::cout << std::string(60, '-') << "\n";
    std::cout << "\n========================================\n";
    std::cout << "Program finished\n";
    std::cout << "========================================\n";

    return 0;
}

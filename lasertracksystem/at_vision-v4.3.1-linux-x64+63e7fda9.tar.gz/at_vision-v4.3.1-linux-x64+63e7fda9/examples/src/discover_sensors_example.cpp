// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file discover_sensors_example.cpp
 * @brief Demonstrate how to use the discover_sensors function to search for sensor devices on the network
 */

#include <at_vision/type_def.h>
#include <at_vision/vision_core.h>
#include <iomanip>
#include <iostream>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#endif

const char* sensor_status_to_string(at_vision::SensorStatus status)
{
    switch (status)
    {
    case at_vision::SensorStatus::NotInSameNetwork:
        return "not in same network";
    case at_vision::SensorStatus::SensorNormal:
        return "normal";
    case at_vision::SensorStatus::SensorOccupied:
        return "occupied";
    case at_vision::SensorStatus::CameraModuleDisconnected:
        return "camera module disconnected";
    case at_vision::SensorStatus::Unknown:
    default:
        return "unknown";
    }
}

const char* sensor_model_type_to_string(at_vision::SensorModelType type)
{
    switch (type)
    {
    case at_vision::SensorModelType::ATrac150:
        return "aTrac-150";
    case at_vision::SensorModelType::ATrac250:
        return "aTrac-250";
    case at_vision::SensorModelType::ATrac400:
        return "aTrac-400";
    case at_vision::SensorModelType::ATrac2D:
        return "aTrac-2D";
    case at_vision::SensorModelType::ATrac250H:
        return "aTrac-250H";
    case at_vision::SensorModelType::ATrac250W:
        return "aTrac-250W";
    case at_vision::SensorModelType::ATrac400G:
        return "aTrac-400G";
    case at_vision::SensorModelType::ATrac250C:
        return "aTrac-250C";
    case at_vision::SensorModelType::ATrac400GH:
        return "aTrac-400GH";
    case at_vision::SensorModelType::ATrac250WEO:
        return "aTrac-250WEO";
    case at_vision::SensorModelType::ATrac250WE:
        return "aTrac-250WE";
    case at_vision::SensorModelType::None:
    default:
        return "none";
    }
}

const char* bool_to_string(bool value)
{
    return value ? "true" : "false";
}

// Helper function to print sensor information
void print_sensor_info(const at_vision::SensorInfo& sensor, int index)
{
    std::cout << "\n========== Sensor #" << (index + 1) << " ==========\n";
    std::cout << std::left;
    std::cout << std::setw(25) << "Sensor ID:" << sensor.sensorId << "\n";
    std::cout << std::setw(25) << "Sensor IP:" << sensor.sensorIp << "\n";
    std::cout << std::setw(25) << "MAC address:" << sensor.macAddress << "\n";
    std::cout << std::setw(25) << "Platform:" << sensor.platform << "\n";
    std::cout << std::setw(25) << "Sensor type:" << sensor.sensorType << "\n";
    std::cout << std::setw(25) << "Sensor model type:" << sensor_model_type_to_string(sensor.sensorModelType) << " ("
              << static_cast<int>(sensor.sensorModelType) << ")\n";
    std::cout << std::setw(25) << "Sensor status:" << sensor_status_to_string(sensor.sensorStatus) << " (" << static_cast<int>(sensor.sensorStatus)
              << ")\n";
    std::cout << std::setw(25) << "Subnet mask:" << sensor.subnetMask << "\n";
    std::cout << std::setw(25) << "Gateway:" << sensor.gateway << "\n";
    std::cout << std::setw(25) << "Software version:" << sensor.softwareVersionNumber << "\n";
    std::cout << std::setw(25) << "Firmware version:" << sensor.firmwareVersionNumber << "\n";
    std::cout << std::setw(25) << "Camera width:" << sensor.cameraWidth << "\n";
    std::cout << std::setw(25) << "Camera height:" << sensor.cameraHeight << "\n";
    std::cout << std::setw(25) << "Resolution width:" << sensor.resWidth << "\n";
    std::cout << std::setw(25) << "Resolution height:" << sensor.resHeight << "\n";
    std::cout << std::setw(25) << "Image quality mode:" << sensor.imageQuality << "\n";
    std::cout << std::setw(25) << "Local IP:" << sensor.localIp << "\n";
    std::cout << std::setw(25) << "Peer IP:" << sensor.peerIp << "\n";
    std::cout << std::setw(25) << "Standalone broadcast:" << bool_to_string(sensor.standaloneBroadcast) << "\n";
    std::cout << std::setw(25) << "eMMC serial:" << sensor.emmcSerial << "\n";
    std::cout << std::setw(25) << "DB connected:" << bool_to_string(sensor.dbConnected) << "\n";
    std::cout << std::setw(25) << "Laser service running:" << bool_to_string(sensor.laserServiceRunning) << "\n";
    std::cout << "================================\n";
}

// Filter sensors based on conditions
void filter_sensors_example(const std::vector<at_vision::SensorInfo>& sensors)
{
    std::cout << "\n===== Filter examples =====\n";

    // Example 1: Find sensors of a specific type
    std::cout << "\n1. Find sensors of a specific type:\n";
    for (const auto& sensor : sensors)
    {
        if (sensor.sensorType == "WeldingSensor")
        {
            std::cout << "   Found welding sensor: " << sensor.sensorId << " (" << sensor.sensorIp << ")\n";
        }
    }

    // Example 2: Find sensors in specific IP subnet
    std::cout << "\n2. Find sensors on the 192.168.1.x subnet:\n";
    for (const auto& sensor : sensors)
    {
        if (sensor.sensorIp.find("192.168.1.") == 0)
        {
            std::cout << "   Found: " << sensor.sensorId << " (" << sensor.sensorIp << ")\n";
        }
    }

    // Example 3: Find connectable sensors
    std::cout << "\n3. Find connectable sensors:\n";
    for (const auto& sensor : sensors)
    {
        if (sensor.sensorStatus == at_vision::SensorStatus::SensorNormal)
        {
            std::cout << "   Connectable: " << sensor.sensorId << " (" << sensor.sensorIp << ")\n";
        }
    }
}

int main(int argc, char* argv[])
{
#ifdef _WIN32
    // [Key] Set console output to UTF-8
    SetConsoleOutputCP(CP_UTF8); // 65001
    SetConsoleCP(CP_UTF8);       // Input also set to UTF-8 (optional)
#endif

    std::cout << "========================================\n";
    std::cout << "   at_vision sensor discovery example\n";
    std::cout << "========================================\n\n";

    // Parse command line arguments (optional timeout)
    int timeout_ms = 5000; // Default 5 seconds
    if (argc > 1)
    {
        try
        {
            timeout_ms = std::stoi(argv[1]);
            if (timeout_ms < 100 || timeout_ms > 30000)
            {
                std::cerr << "Timeout should be between 100 and 30000 ms; using default value 3000\n";
                timeout_ms = 3000;
            }
        } catch (...)
        {
            std::cerr << "Invalid timeout argument; using default value 3000 ms\n";
            timeout_ms = 3000;
        }
    }

    std::cout << "Discovery timeout: " << timeout_ms << " ms\n";
    std::cout << "Starting network sensor discovery...\n\n";

    std::error_code discover_ec;
    std::vector<at_vision::SensorInfo> sensors = at_vision::discoverSensors(discover_ec, timeout_ms);

    // Display search results
    if (sensors.empty())
    {
        std::cout << "No sensor devices found\n";
        if (discover_ec)
        {
            std::cout << "Error message: " << discover_ec.message() << "\n";
        }
        std::cout << "\nTips:\n";
        std::cout << "  1. Make sure the sensor is powered on and connected to the same network\n";
        std::cout << "  2. Check whether the firewall allows UDP ports 8000 and 15555\n";
        std::cout << "  3. Make sure the network adapter is enabled\n";
        std::cout << "  4. Try increasing the timeout: " << argv[0] << " 5000\n";
        return 1;
    }

    std::cout << "Discovered " << sensors.size() << " sensor device(s)\n";

    // Print detailed information of all sensors
    for (size_t i = 0; i < sensors.size(); ++i)
    {
        print_sensor_info(sensors[i], i);
    }

    // Demonstrate filtering functionality
    if (sensors.size() > 1)
    {
        filter_sensors_example(sensors);
    }

    // Generate connection suggestions
    std::cout << "\n===== Connection suggestions =====\n";
    for (size_t i = 0; i < sensors.size(); ++i)
    {
        std::cout << "\nSensor #" << (i + 1) << " - " << sensors[i].sensorId << ":\n";
        std::cout << "  Connection command example:\n";
        std::cout << "    IP:   " << sensors[i].sensorIp << "\n";
        std::cout << "    Resolution: " << sensors[i].resWidth << "x" << sensors[i].resHeight << "\n";

        // Give suggestions based on Image quality mode
        if (sensors[i].imageQuality == 0)
        {
            std::cout << "  Mode: compressed transfer (fast, low quality)\n";
        }
        else if (sensors[i].imageQuality == 1)
        {
            std::cout << "  Mode: original transfer (slow, high quality)\n";
        }
    }

    std::cout << "\n========================================\n";

    return 0;
}

// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file hand_eye_calibration_example2.cpp
 * @brief Standalone hand-eye calibration example
 *
 * This example only demonstrates the hand-eye calibration call chain:
 * 1. Search for and connect to Sensor
 * 2. Get IHandEyeCalibration interface
 * 3. Construct HandEyeCalibrationInput
 * 4. Call calibrate()
 * 5. Print structured results
 */

#include <at_vision/vision_core.h>
#include <iostream>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace at_vision;

namespace {

void PrintPose(const char* name, const Pose6D& pose)
{
    std::cout << name << ": "
              << pose.x << ", " << pose.y << ", " << pose.z << ", "
              << pose.w << ", " << pose.p << ", " << pose.r << std::endl;
}

void PrintCalibrationInput(const HandEyeCalibrationInput& input)
{
    PrintPose("TCP pose", input.tcp_position);
    PrintPose("Base pose", input.base_position);

    std::cout << "Robot points: " << input.robot_points.size() << std::endl;
    for (size_t i = 0; i < input.robot_points.size(); ++i)
    {
        std::cout << "  [" << i << "] ";
        PrintPose("", input.robot_points[i]);
    }

    std::cout << "Sensor points: " << input.sensor_points.size() << std::endl;
    for (size_t i = 0; i < input.sensor_points.size(); ++i)
    {
        const auto& point = input.sensor_points[i];
        std::cout << "  [" << i << "] "
                  << point.x << ", " << point.y << ", " << point.z << std::endl;
    }
}

void PrintCalibrationOutput(const HandEyeCalibrationOutput& output)
{
    std::cout << "success: " << (output.success ? "true" : "false") << std::endl;
    std::cout << "error_message: " << output.error_message << std::endl;
    PrintPose("result", output.result);

    std::cout << "error_matrix:" << std::endl;
    for (const auto& row : output.error_matrix)
    {
        std::cout << "  [" << row[0] << ", " << row[1] << ", " << row[2] << "]" << std::endl;
    }
}

HandEyeCalibrationInput BuildSampleInput()
{
    HandEyeCalibrationInput input;
    input.tcp_position = {0.0, 0.0, 200.0, 0.0, 0.0, 0.0};
    input.base_position = {500.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    input.robot_points = {
        {100.0, 100.0, 100.0, 0.0, 0.0, 0.0},
        {200.0, 100.0, 100.0, 0.0, 0.0, 0.0},
        {150.0, 150.0, 100.0, 0.0, 0.0, 0.0}
    };
    input.sensor_points = {
        {1.0, 2.0, 3.0},
        {2.0, 2.0, 3.0},
        {1.5, 2.5, 3.0}
    };
    return input;
}

} // namespace

int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    std::cout << "at_vision standalone hand-eye calibration example" << std::endl;

    std::error_code discover_ec;
    const auto sensors = discoverSensors(discover_ec, 5000);
    if (sensors.empty())
    {
        std::cerr << "No sensors found";
        if (discover_ec)
        {
            std::cerr << ": " << discover_ec.message();
        }
        std::cerr << std::endl;
        return 1;
    }

    std::cout << "Using sensor: " << sensors.front().sensorId
              << " (" << sensors.front().sensorIp << ")" << std::endl;

    auto client = createVision();
    if (!client)
    {
        std::cerr << "Failed to create client" << std::endl;
        return 1;
    }

    const auto connect_ec = client->connect(sensors.front());
    if (connect_ec)
    {
        std::cerr << "Failed to connect to sensor: " << connect_ec.message() << std::endl;
        return 1;
    }

    auto hand_eye = client->getHandEyeCalibration();
    if (!hand_eye)
    {
        std::cerr << "Failed to get hand-eye calibration interface" << std::endl;
        return 1;
    }

    const auto input = BuildSampleInput();
    std::cout << "\nInput data:" << std::endl;
    PrintCalibrationInput(input);

    std::error_code ec;
    const auto output = hand_eye->calibrate(input, ec);
    if (ec)
    {
        std::cerr << "\nHand-eye calibration call failed: " << ec.message() << std::endl;
        return 2;
    }

    std::cout << "\nCalibration result:" << std::endl;
    PrintCalibrationOutput(output);

    return output.success ? 0 : 3;
}

// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file image_laser_callback_example.cpp
 * @brief Image callback, seam result callback and Laser Control demonstration program
 *
 * This example demonstrates how to:
 * - Search for and Connect to Sensor
 * - Register setImageCallback callback
 * - Register setLaserSeamResultCallback callback
 * - Enable Laser and wait for a period of time to receive callback data
 * - Disable Laser and exit
 */

#include <at_vision/algorithm_interface.h>
#include <at_vision/logging.h>
#include <at_vision/setting_interface.h>
#include <at_vision/vision_core.h>
#include <atomic>
#include <chrono>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <thread>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

using namespace at_vision;

namespace {

struct ProgramOptions {
    ImageQuality quality = ImageQuality::Compressed;
    int durationSeconds = 5;
    bool saveImages = false;
    std::filesystem::path saveDirectory;
    bool showHelp = false;
};

void print_separator(const std::string& title)
{
    std::cout << "\n========== " << title << " ==========" << std::endl;
}

std::string to_lower(std::string value)
{
    for (auto& ch : value)
    {
        ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    }
    return value;
}

std::string image_quality_to_string(ImageQuality quality)
{
    return quality == ImageQuality::Original ? "original" : "compressed";
}

bool parse_image_quality(const std::string& value, ImageQuality& quality)
{
    const auto normalized = to_lower(value);
    if (normalized == "original" || normalized == "raw")
    {
        quality = ImageQuality::Original;
        return true;
    }
    if (normalized == "compressed" || normalized == "jpg" || normalized == "jpeg")
    {
        quality = ImageQuality::Compressed;
        return true;
    }
    return false;
}

void print_usage(const char* programName)
{
    std::cout << "Usage: " << programName << " [options] [original|compressed]\n"
              << "\nOptions:\n"
              << "  -q, --quality <value>   Image quality: original/raw or compressed/jpg, default compressed\n"
              << "  -o, --original          Use original RAW image transfer\n"
              << "  -c, --compressed        Use compressed JPG image transfer\n"
              << "  -d, --duration <sec>    Callback wait duration in seconds, default 5\n"
              << "  -s, --save              Save received images, disabled by default\n"
              << "  -p, --save-dir <dir>    Image save directory, implies --save, default <exe-dir>/output\n"
              << "  -h, --help              Show this help message\n";
}

bool parse_positive_seconds(const std::string& value, int& seconds)
{
    try
    {
        size_t parsedChars = 0;
        const int parsed = std::stoi(value, &parsedChars);
        if (parsedChars != value.size() || parsed <= 0)
        {
            return false;
        }
        seconds = parsed;
        return true;
    } catch (const std::exception&)
    {
        return false;
    }
}

bool parse_arguments(int argc, char* argv[], ProgramOptions& options)
{
    for (int i = 1; i < argc; ++i)
    {
        const std::string arg = argv[i];
        if (arg == "-h" || arg == "--help")
        {
            options.showHelp = true;
            return true;
        }
        if (arg == "-o" || arg == "--original")
        {
            options.quality = ImageQuality::Original;
            continue;
        }
        if (arg == "-c" || arg == "--compressed")
        {
            options.quality = ImageQuality::Compressed;
            continue;
        }
        if (arg == "-s" || arg == "--save")
        {
            options.saveImages = true;
            continue;
        }
        if (arg == "-q" || arg == "--quality")
        {
            if (i + 1 >= argc || !parse_image_quality(argv[++i], options.quality))
            {
                std::cerr << "Invalid image quality value" << std::endl;
                return false;
            }
            continue;
        }
        if (arg.rfind("--quality=", 0) == 0)
        {
            if (!parse_image_quality(arg.substr(std::string("--quality=").size()), options.quality))
            {
                std::cerr << "Invalid image quality value: " << arg << std::endl;
                return false;
            }
            continue;
        }
        if (arg == "-p" || arg == "--save-dir")
        {
            if (i + 1 >= argc)
            {
                std::cerr << "Missing image save directory" << std::endl;
                return false;
            }
            options.saveImages = true;
            options.saveDirectory = argv[++i];
            continue;
        }
        if (arg.rfind("--save-dir=", 0) == 0)
        {
            options.saveImages = true;
            options.saveDirectory = arg.substr(std::string("--save-dir=").size());
            continue;
        }
        if (arg == "-d" || arg == "--duration")
        {
            if (i + 1 >= argc || !parse_positive_seconds(argv[++i], options.durationSeconds))
            {
                std::cerr << "Invalid duration value" << std::endl;
                return false;
            }
            continue;
        }
        if (arg.rfind("--duration=", 0) == 0)
        {
            if (!parse_positive_seconds(arg.substr(std::string("--duration=").size()), options.durationSeconds))
            {
                std::cerr << "Invalid duration value: " << arg << std::endl;
                return false;
            }
            continue;
        }
        if (parse_image_quality(arg, options.quality))
        {
            continue;
        }

        std::cerr << "Unknown argument: " << arg << std::endl;
        return false;
    }
    return true;
}

void fill_default_save_directory(const char* programName, ProgramOptions& options)
{
    if (!options.saveImages || !options.saveDirectory.empty())
    {
        return;
    }

    const auto executablePath = std::filesystem::absolute(programName);
    options.saveDirectory = executablePath.parent_path() / "output";
}

bool prepare_save_directory(const ProgramOptions& options)
{
    if (!options.saveImages)
    {
        return true;
    }

    std::error_code ec;
    std::filesystem::create_directories(options.saveDirectory, ec);
    if (ec)
    {
        std::cerr << "Failed to create image save directory: " << options.saveDirectory.string() << ", error: " << ec.message() << std::endl;
        return false;
    }
    return true;
}

void save_image(const Image& image, int count, const std::filesystem::path& directory)
{
    std::filesystem::path filename;
    if (image.type == ImageType::RAW)
    {
        filename = "received_image_" + std::to_string(count) + "_" + std::to_string(image.width) + "x" + std::to_string(image.height) + ".raw";
    }
    else if (image.type == ImageType::JPG)
    {
        filename = "received_image_" + std::to_string(count) + ".jpg";
    }
    else
    {
        std::cerr << "Skip unsupported image type: " << static_cast<int>(image.type) << std::endl;
        return;
    }

    const auto filePath = directory / filename;
    std::ofstream outFile(filePath, std::ios::binary);
    if (!outFile)
    {
        std::cerr << "Failed to open image file: " << filePath.string() << std::endl;
        return;
    }
    outFile.write(reinterpret_cast<const char*>(image.data.data()), static_cast<std::streamsize>(image.data.size()));
}

} // namespace

int main(int argc, char* argv[])
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    logging::set_level(logging::Level::Info);

    ProgramOptions options;
    if (!parse_arguments(argc, argv, options))
    {
        print_usage(argv[0]);
        return 1;
    }
    if (options.showHelp)
    {
        print_usage(argv[0]);
        return 0;
    }
    fill_default_save_directory(argv[0], options);
    if (!prepare_save_directory(options))
    {
        return 1;
    }

    std::cout << "at_vision image/seam-result callback and laser control example" << std::endl;
    std::cout << "Image quality: " << image_quality_to_string(options.quality) << ", duration: " << options.durationSeconds << " seconds";
    if (options.saveImages)
    {
        std::cout << ", save directory: " << options.saveDirectory.string();
    }
    std::cout << std::endl;

    std::error_code discoverEc;
    print_separator("Discover Sensors");
    auto sensors = discoverSensors(discoverEc, 3000);
    if (sensors.empty())
    {
        std::cerr << "No sensors found";
        if (discoverEc)
        {
            std::cerr << ", error: " << discoverEc.message();
        }
        std::cerr << std::endl;
        return 1;
    }

    for (size_t i = 0; i < sensors.size(); ++i)
    {
        std::cout << "[" << i << "] " << sensors[i].sensorId << " (" << sensors[i].sensorIp << ") - " << sensors[i].sensorType << std::endl;
    }

    const auto& sensor = sensors.front();
    std::cout << "\nSelected sensor: " << sensor.sensorId << std::endl;

    auto client = createVision();
    auto imageCount = std::make_shared<std::atomic<int>>(0);
    auto resultCount = std::make_shared<std::atomic<int>>(0);

    print_separator("Connect Sensor");
    auto connectEc = client->connect(sensor);
    if (connectEc)
    {
        std::cerr << "Failed to connect to sensor: " << connectEc.message() << std::endl;
        return 1;
    }
    std::cout << "Connected successfully" << std::endl;

    auto settings = client->getSettings();
    auto qualityEc = settings->setImageQuality(options.quality);
    if (qualityEc)
    {
        std::cerr << "Failed to set image quality: " << qualityEc.message() << std::endl;
        return 1;
    }
    auto algorithm = client->getAlgorithmInterface();

    client->setImageCallback([imageCount, saveImages = options.saveImages, saveDirectory = options.saveDirectory](const Image& image) {
        const int count = ++(*imageCount);
        std::cout << "[ImageCallback] #" << count << ", size=" << image.width << "x" << image.height << ", type=" << static_cast<int>(image.type)
                  << ", bytes=" << image.data.size() << std::endl;
        if (saveImages)
        {
            save_image(image, count, saveDirectory);
        }
    });

    client->setLaserSeamResultCallback([resultCount](const LaserSeamResult& result) {
        const int count = ++(*resultCount);
        std::cout << "[LaserSeamResultCallback] #" << count << ", current_job_no=" << result.current_job_no << ", laser_state=" << result.laser_state
                  << ", robot_connected=" << (result.robot_connected ? "true" : "false") << ", seam_point=(" << result.seam_point.y_3d << ", "
                  << result.seam_point.z_3d << ")" << std::endl;
    });

    print_separator("Enable Laser");
    auto laserOnEc = algorithm->setLaserEnabled(true);
    if (laserOnEc)
    {
        std::cerr << "Failed to enable laser: " << laserOnEc.message() << std::endl;
        return 1;
    }
    std::cout << "Laser is enabled; waiting " << options.durationSeconds << " seconds for image and seam-result callbacks..." << std::endl;

    std::this_thread::sleep_for(std::chrono::seconds(options.durationSeconds));

    print_separator("Disable Laser");
    auto laserOffEc = algorithm->setLaserEnabled(false);
    if (laserOffEc)
    {
        std::cerr << "Failed to disable laser: " << laserOffEc.message() << std::endl;
        return 1;
    }

    std::cout << "Laser is disabled" << std::endl;
    std::cout << "Total image callbacks received: " << imageCount->load() << std::endl;
    std::cout << "Total seam-result callbacks received: " << resultCount->load() << std::endl;
    return 0;
}

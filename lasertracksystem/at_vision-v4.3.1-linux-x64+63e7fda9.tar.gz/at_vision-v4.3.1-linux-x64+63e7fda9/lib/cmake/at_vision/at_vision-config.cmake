# at_vision CMake 配置文件
# 支持多平台共存，自动检测并加载对应平台的目标文件


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was at_vision-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# ====== 平台和架构检测 ======
# 检测操作系统
if(WIN32)
    set(_at_vision_platform "windows")
elseif(UNIX AND NOT APPLE)
    set(_at_vision_platform "linux")
elseif(APPLE)
    set(_at_vision_platform "macos")
else()
    set(_at_vision_platform "unknown")
endif()

# 检测架构
if(CMAKE_SIZEOF_VOID_P EQUAL 8)
    set(_at_vision_arch "x64")
else()
    set(_at_vision_arch "x86")
endif()

# 如果是 ARM 架构，覆盖架构名称
if(CMAKE_SYSTEM_PROCESSOR MATCHES "^(aarch64|arm64)")
    set(_at_vision_arch "arm64")
elseif(CMAKE_SYSTEM_PROCESSOR MATCHES "^(arm)")
    set(_at_vision_arch "arm")
endif()

# 组合平台架构子目录
set(_at_vision_platform_arch "${_at_vision_platform}-${_at_vision_arch}")

# ====== 加载平台特定的目标文件 ======
set(_at_vision_targets_file "${CMAKE_CURRENT_LIST_DIR}/${_at_vision_platform_arch}/at_vision-targets.cmake")

if(NOT EXISTS "${_at_vision_targets_file}")
    set(at_vision_FOUND FALSE)
    set(at_vision_NOT_FOUND_MESSAGE 
        "at_vision 库不支持当前平台架构: ${_at_vision_platform_arch}\n"
        "期望的目标文件: ${_at_vision_targets_file}")
    if(at_vision_FIND_REQUIRED)
        message(FATAL_ERROR "${at_vision_NOT_FOUND_MESSAGE}")
    elseif(NOT at_vision_FIND_QUIETLY)
        message(WARNING "${at_vision_NOT_FOUND_MESSAGE}")
    endif()
    return()
endif()

# 加载目标定义
include("${_at_vision_targets_file}")

# 清理临时变量
unset(_at_vision_platform)
unset(_at_vision_arch)
unset(_at_vision_platform_arch)
unset(_at_vision_targets_file)

check_required_components(at_vision)

#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "at_vision::at_vision" for configuration "Release"
set_property(TARGET at_vision::at_vision APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(at_vision::at_vision PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/linux-x64/libat_vision.so.4.3.1"
  IMPORTED_SONAME_RELEASE "libat_vision.so.4"
  )

list(APPEND _IMPORT_CHECK_TARGETS at_vision::at_vision )
list(APPEND _IMPORT_CHECK_FILES_FOR_at_vision::at_vision "${_IMPORT_PREFIX}/lib/linux-x64/libat_vision.so.4.3.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

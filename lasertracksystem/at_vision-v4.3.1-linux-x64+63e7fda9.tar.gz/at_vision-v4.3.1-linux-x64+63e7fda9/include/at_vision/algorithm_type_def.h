// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/** @file  algorithm_type_def.h
 *  \~chinese @brief 数据类型的定义 \~english @brief enum type definitions
 **/

#pragma once

#include "at_vision/export.h"
#include "at_vision/type_def.h"
#include <array>
#include <cstdint>
#include <string>
#include <vector>
#include <optional>
#include <memory>
#include <system_error>

namespace at_vision {

/**
 * \~chinese @brief 序列化/反序列化接口 \~english @brief Serialization/deserialization interface
 *
 * \~chinese 提供 JSON 序列化和反序列化能力 \~english Provides JSON serialization and deserialization support
 *
 * \~chinese @warning 该接口主要供 SDK 内部 RPC 和配置同步使用，JSON 字段与格式不作为稳定公共协议保证。
 *                    外部业务不应依赖其输出格式进行持久化或跨版本通信。
 * \~english @warning This interface is primarily intended for SDK-internal RPC and configuration synchronization.
 *                    JSON fields and formatting are not guaranteed as a stable public protocol. External applications
 *                    should not depend on this output format for persistence or cross-version communication.
 */
class AT_VISION_API ISerializable {
public:
    virtual ~ISerializable() = default;

    /**
     * \~chinese @brief 序列化为 JSON 字符串 \~english @brief Serializes to a JSON string
     * \~chinese @warning 仅供 SDK 内部 RPC 和配置同步流程使用；JSON 格式可能随版本变化。
     * \~english @warning Intended only for SDK-internal RPC and configuration synchronization; the JSON format may
     *                   change between versions.
     * \~chinese @param out 输出 JSON 字符串 \~english @param out Output JSON string
     * \~chinese @return 成功返回空 error_code，失败返回错误信息 \~english @return Returns empty error_code on success, error message on failure
     */
    virtual std::error_code serialize(std::string& out) const = 0;

    /**
     * \~chinese @brief 从 JSON 字符串反序列化 \~english @brief Deserializes from a JSON string
     * \~chinese @warning 仅供 SDK 内部 RPC 和配置同步流程使用；不要将外部自定义 JSON 作为稳定输入协议。
     * \~english @warning Intended only for SDK-internal RPC and configuration synchronization; external custom JSON
     *                   should not be treated as a stable input protocol.
     * \~chinese @param jsonStr JSON 字符串 \~english @param jsonStr JSON string
     * \~chinese @return 成功返回空 error_code，失败返回错误信息 \~english @return Returns empty error_code on success, error message on failure
     */
    virtual std::error_code deserialize(const std::string& jsonStr) = 0;
};

/**
 * \~chinese @brief 参数配置字典项 \~english @brief Parameter configuration dictionary item
 * \~chinese 用于存储算法参数的配置信息，包括参数类型、范围、步长和默认值 \~english Stores algorithm parameter configuration, including type, range,
 * step, and default value
 */
class AT_VISION_API ParamConfigItem : public ISerializable {
public:
    /** \~chinese @brief 参数名称 \~english @brief Parameter name */
    std::string param_name;
    /** \~chinese @brief 参数类型 \~english @brief Parameter type */
    std::string param_type;
    /** \~chinese @brief 参数最小值 \~english @brief Parameter minimum value */
    std::string param_min;
    /** \~chinese @brief 参数最大值 \~english @brief Parameter maximum value */
    std::string param_max;
    /** \~chinese @brief 参数调整步长 \~english @brief Parameter adjustment step */
    std::string param_step;
    /** \~chinese @brief 参数默认值 \~english @brief Parameter default value */
    std::string param_default;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 参数配置字典 \~english @brief Parameter configuration dictionary
 * \~chinese 用于存储特定表名的所有参数配置项 \~english Stores all parameter configuration items for a specific table name
 */
class AT_VISION_API ParamConfigDict : public ISerializable {
public:
    /** \~chinese @brief 表名 \~english @brief Table name */
    std::string table_name;
    /** \~chinese @brief 参数配置项列表 \~english @brief Parameter configuration item list */
    std::vector<ParamConfigItem> params;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 焊缝类型 \~english @brief Seam type
 * \~chinese 焊缝类型枚举
 * \~english Seam type enumeration
 */
enum class SeamType : int
{
    None = -1,               ///< \~chinese 无 \~english None
    Lap = 0,                 ///< \~chinese 薄板搭接 \~english Thin plate lap
    Joint = 1,               ///< \~chinese 对接 \~english Butt joint
    V = 2,                   ///< \~chinese V型坡口 \~english V-groove
    Edge = 3,                ///< \~chinese 边缘 \~english Edge
    Angle = 4,               ///< \~chinese 角焊缝 \~english Angle weld
    Micro = 5,               ///< \~chinese 微小焊缝 \~english Micro weld
    ComplexV = 10,           ///< \~chinese 复杂焊缝 \~english Complex weld
    LineCombine = 14,        ///< \~chinese 直线组合 \~english Line combination
    Narrow2D = 15,           ///< \~chinese 细对接焊缝 \~english Narrow butt weld
    LineTemplate = 16,       ///< \~chinese 直线模板 \~english Line template
    LineCircle = 18,         ///< \~chinese 直线圆弧 \~english Line circle
    LineLeftLap = 20,        ///< \~chinese 直线左搭接 \~english Line left lap
    LineRightLap = 21,       ///< \~chinese 直线右搭接 \~english Line right lap
    LineInternalCorner = 22, ///< \~chinese 直线内角 \~english Line internal corner
    LineExternalCorner = 23, ///< \~chinese 直线外角 \~english Line external corner
    LineButt = 24,           ///< \~chinese 直线对接 \~english Line butt
    LineLeftEdge = 25,       ///< \~chinese 直线左边缘 \~english Line left edge
    LineRightEdge = 26,      ///< \~chinese 直线右边缘 \~english Line right edge
    LineVGroove = 27,        ///< \~chinese 直线V型坡口 \~english Line V-groove
    LineMCorner = 28,        ///< \~chinese 直线M型角接 \~english Line M-corner
    Count                    ///< \~chinese 计数 \~english Count
};

/**
 * \~chinese @brief Process（工艺库）信息 \~english @brief Process library information
 */
class AT_VISION_API ProcessInfo : public ISerializable {
public:
    int id = -1;
    std::string name;
    std::string operator_name;
    std::string description;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 算法基础信息（抽象类） \~english @brief Base algorithm information abstract class
 */
class AT_VISION_API AlgoBaseInfo : public ISerializable {
public:
    virtual ~AlgoBaseInfo() = default;
    virtual SeamType getSeamType() const { return SeamType::None; }
    /** @brief ID */
    int id = -1;
    /** \~chinese @brief 任务ID \~english @brief Job ID */
    int job_id = -1;
    /** \~chinese @brief 工艺库ID \~english @brief Process library ID */
    int process_id = -1;
    /** \~chinese @brief 采用动态阈值 \~english @brief Uses dynamic thresholding */
    bool thinning_adaptive = false;
    /** \~chinese @brief 固定阈值 \~english @brief Fixed threshold */
    int thinning_threshold = -1;

    std::error_code serialize(std::string& out) const override = 0;
    std::error_code deserialize(const std::string& jsonStr) override = 0;
};

/**
 * \~chinese @brief 算法基础信息更新 \~english @brief Base algorithm information update
 */
class AT_VISION_API AlgoBaseInfoUpdate : public ISerializable {
public:
    virtual SeamType getSeamType() const { return SeamType::None; }
    /** @brief ID */
    int id = -1;
    /** \~chinese @brief 任务ID \~english @brief Job ID */
    int job_id = -1;
    /** \~chinese @brief 工艺库ID \~english @brief Process library ID */
    int process_id = -1;
    /** \~chinese @brief 采用动态阈值 \~english @brief Uses dynamic thresholding */
    std::optional<bool> thinning_adaptive;
    /** \~chinese @brief 固定阈值 \~english @brief Fixed threshold */
    std::optional<int> thinning_threshold;

    std::error_code serialize(std::string& out) const override = 0;
    std::error_code deserialize(const std::string& jsonStr) override = 0;
};

template <typename T>
struct RangeValue {
    T min{};
    T max{};
};

using IntRange = RangeValue<int>;
using DoubleRange = RangeValue<double>;

/**
 * \~chinese @brief 激光线模式 1 参数 \~english @brief Laser line mode 1 parameters
 */
struct ThinningType1Params {
    /** \~chinese @brief 固定阈值 \~english @brief Fixed threshold */
    int thinning_fixed_threshold = -1;
    /** \~chinese @brief 比例阈值 \~english @brief Ratio threshold */
    double thinning_ratio_threshold = 0;
};

/**
 * \~chinese @brief 激光线模式 2 参数 \~english @brief Laser line mode 2 parameters
 */
struct ThinningType2Params {
    /** \~chinese @brief 最低亮度 \~english @brief Minimum brightness */
    int thinning_reflective_fixed_threshold = -1;
    /** \~chinese @brief 亮度灵敏度 \~english @brief Brightness sensitivity */
    double thinning_reflective_ratio_threshold = 0;
    /** \~chinese @brief 荧光程度 \~english @brief Fluorescence level */
    int thinning_reflective_thinning_adjust = -1;
    /** \~chinese @brief 激光线对比度 \~english @brief Laser line contrast */
    int thinning_reflective_loss_weight = -1;
    /** \~chinese @brief 激光线最大宽度 \~english @brief Laser line maximum width */
    int thinning_reflective_max_width = -1;
};

/**
 * \~chinese @brief 激光线模式 \~english @brief Laser line mode
 * \~chinese 激光线模式枚举
 * \~english Laser line mode enumeration
 */
enum class ThinningType
{
    Normal = 0,      ///< \~chinese 普通模式 \~english Normal mode
    Reflective1 = 1, ///< \~chinese 高反光1 \~english High reflective 1
    Reflective2 = 2  ///< \~chinese 高反光2 \~english High reflective 2
};

/**
 * \~chinese @brief ROI 参数 \~english @brief ROI parameter
 */
struct RoiParams {
    /** \~chinese @brief ROI 区域起点 X \~english @brief ROI start X coordinate */
    int start_x = -1;
    /** \~chinese @brief ROI 区域起点 Y \~english @brief ROI start Y coordinate */
    int start_y = -1;
    /** \~chinese @brief ROI 区域高度 \~english @brief ROI height */
    int image_h = -1;
    /** \~chinese @brief ROI 区域宽度 \~english @brief ROI width */
    int image_w = -1;
};

/**
 * \~chinese @brief 图像参数 \~english @brief Image parameter
 */
struct ImageParams {
    /** \~chinese @brief 定位稳定性 \~english @brief Positioning stability */
    int median_filter_len = -1;
    /** \~chinese @brief 激光强度 \~english @brief Laser intensity */
    int laser_extension = -1;
    /** \~chinese @brief 曝光时间 \~english @brief Exposure time */
    int cam_expose = -1;
    /** \~chinese @brief 激光线模式 \~english @brief Laser line mode */
    ThinningType thinning_type = ThinningType::Normal;
    /** \~chinese @brief 高反光1模式参数快照 \~english @brief High reflective 1 mode parameter snapshot */
    ThinningType1Params thinning_type1_params;
    /** \~chinese @brief 高反光2模式参数快照 \~english @brief High reflective 2 mode parameter snapshot */
    ThinningType2Params thinning_type2_params;
    /** \~chinese @brief ROI 参数 \~english @brief ROI parameter */
    std::optional<RoiParams> roi;
    /** \~chinese @brief 横向偏移 X \~english @brief Horizontal offset X */
    std::string seampoint_offset_x;
    /** \~chinese @brief 纵向偏移 Y \~english @brief Vertical offset Y */
    std::string seampoint_offset_y;
    /** \~chinese @brief 面光源强度 \~english @brief Area light intensity */
    int surface_light_extension = 50;
    /** \~chinese @brief 角光源强度 \~english @brief Angle light intensity */
    int angle_light = 3;
    /** \~chinese @brief 自适应状态，仅对微小焊缝类型生效 \~english @brief Adaptive state; only effective for micro weld seam type */
    bool adaptive_switch = false;
    /** \~chinese @brief 角度范围θ最小值 \~english @brief Minimum angle range θ value */
    double slope_anomaly_threshold_min = 0.0;
    /** \~chinese @brief 角度范围θ最大值 \~english @brief Maximum angle range θ value */
    double slope_anomaly_threshold_max = 360.0;
};

/**
 * \~chinese @brief 图像参数更新 \~english @brief Image parameter update
 */
struct AT_VISION_API ImageParamsUpdate : public ISerializable {
    /** \~chinese @brief 定位稳定性 \~english @brief Positioning stability */
    std::optional<int> median_filter_len;
    /** \~chinese @brief 激光强度 \~english @brief Laser intensity */
    std::optional<int> laser_extension;
    /** \~chinese @brief 曝光时间 \~english @brief Exposure time */
    std::optional<int> cam_expose;
    /** \~chinese @brief 激光线模式 \~english @brief Laser line mode */
    std::optional<ThinningType> thinning_type;
    /** \~chinese @brief thinning_type==Reflective1时的参数 \~english @brief Parameters used when thinning_type == Reflective1 */
    std::optional<ThinningType1Params> thinning_type1_params;
    /** \~chinese @brief thinning_type==Reflective2时的参数 \~english @brief Parameters used when thinning_type == Reflective2 */
    std::optional<ThinningType2Params> thinning_type2_params;
    /** \~chinese @brief ROI 参数 \~english @brief ROI parameter */
    std::optional<RoiParams> roi;
    /** \~chinese @brief 横向偏移 X \~english @brief Horizontal offset X */
    std::optional<std::string> seampoint_offset_x;
    /** \~chinese @brief 纵向偏移 Y \~english @brief Vertical offset Y */
    std::optional<std::string> seampoint_offset_y;
    /** \~chinese @brief 面光源强度,仅对2D相机和算法生效 \~english @brief Area light intensity; only effective for 2D cameras and algorithms */
    std::optional<int> surface_light_extension;
    /** \~chinese @brief 角光源强度, 仅对2D相机和算法生效 \~english @brief Angle light intensity; only effective for 2D cameras and algorithms */
    std::optional<int> angle_light;
    /** \~chinese @brief 自适应状态，仅对微小焊缝类型生效 \~english @brief Adaptive state; only effective for micro weld seam type */
    std::optional<bool> adaptive_switch;
    /** \~chinese @brief 角度范围θ \~english @brief Angle range θ */
    std::optional<DoubleRange> slope_anomaly_threshold;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief Job（任务）信息 \~english @brief Job (job) information
 */
class AT_VISION_API JobInfo : public ISerializable {
public:
    /** @brief ID */
    int id = -1;
    /** \~chinese @brief 任务编号 \~english @brief Job number */
    int job_no = -1;
    /** \~chinese @brief 工艺库ID \~english @brief Process library ID */
    int process_id = -1;
    /** \~chinese @brief 任务名称 \~english @brief Job name */
    std::string name;
    /** \~chinese @brief 焊缝类型 \~english @brief Seam type */
    SeamType weld_type = SeamType::None;
    /** \~chinese @brief 图像参数 \~english @brief Image parameter */
    std::optional<ImageParams> image_params;
    /** \~chinese @brief 算法参数 \~english @brief Algorithm parameter */
    std::shared_ptr<AlgoBaseInfo> algo_info;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 薄板搭接算法参数 \~english @brief Thin plate lap algorithm parameters
 */
class AT_VISION_API JointLapAlgoInfo : public AlgoBaseInfo {
public:
    /**
     * \~chinese @brief 搭接模式 \~english @brief Lap mode
     */
    enum LapRemarkMode
    {
        MaxHeightDiff = 0, // 最大高度差 / Maximum height difference
        LeftLap = 1,       // 左搭接 / Left lap
        RightLap = 2       // 右搭接 / Right lap
    };

    SeamType getSeamType() const override;

    /** \~chinese @brief 斜坡宽度L \~english @brief Slope width L */
    std::string lap_fitting_gap;
    /** \~chinese @brief 计算窗口N \~english @brief Calculation window N */
    int lap_match_window = -1;
    /** \~chinese @brief 选择上边缘 \~english @brief Select upper edge */
    bool lap_at_high_side = false;
    /** \~chinese @brief 搭接模式，取值参考 LapRemarkMode \~english @brief Lap mode, see LapRemarkMode */
    int remark1 = MaxHeightDiff;
    /** \~chinese @brief 板厚 \~english @brief Plate thickness */
    double lap_thickness_min = 0.1;
    /** \~chinese @brief 板厚 \~english @brief Plate thickness */
    double lap_thickness_max = 100;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 薄板搭接算法参数更新 \~english @brief Thin plate lap algorithm parameter update
 */
class AT_VISION_API JointLapAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** \~chinese @brief 斜坡宽度L \~english @brief Slope width L */
    std::optional<std::string> lap_fitting_gap;
    /** \~chinese @brief 计算窗口N \~english @brief Calculation window N */
    std::optional<int> lap_match_window;
    /** \~chinese @brief 选择上边缘 \~english @brief Select upper edge */
    std::optional<bool> lap_at_high_side;
    /** \~chinese @brief 搭接模式，取值参考 JointLapAlgoInfo::LapRemarkMode \~english @brief Lap mode, see JointLapAlgoInfo::LapRemarkMode */
    std::optional<int> remark1;
    /** \~chinese @brief 板厚 \~english @brief Plate thickness */
    std::optional<DoubleRange> lap_thickness;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 对接算法参数 \~english @brief Butt joint algorithm parameters
 * \~chinese 对接焊缝算法参数
 * \~english Butt joint algorithm parameters
 */
class AT_VISION_API JointButtAlgoInfo : public AlgoBaseInfo {
public:
    SeamType getSeamType() const override;

    /** @brief 选择上边缘 \~chinese 选择上边缘 \~english Select upper edge */
    bool butt_at_high_side = false;
    /** @brief 计算窗口N \~chinese 计算窗口N \~english Calculation window N */
    int butt_match_window = -1;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 对接算法参数更新 \~english @brief Butt joint algorithm parameter update
 * \~chinese 对接焊缝算法参数更新
 * \~english Butt joint algorithm parameter update
 */
class AT_VISION_API JointButtAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 选择上边缘 \~chinese 选择上边缘 \~english Select upper edge */
    std::optional<bool> butt_at_high_side;
    /** @brief 计算窗口N \~chinese 计算窗口N \~english Matching window N */
    std::optional<int> butt_match_window;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief V 型坡口算法参数 \~english @brief V-groove algorithm parameters
 * \~chinese V 型坡口焊缝算法参数
 * \~english V-groove weld algorithm parameters
 */
class AT_VISION_API JointVAlgoInfo : public AlgoBaseInfo {
public:
    /**
     * \~chinese @brief 激光补全模式枚举。
     * \~english @brief Laser completion mode enumeration.
     * \~chinese 0:不补全，1:左向右，2:右向左。
     * \~english 0:no completion, 1:left to right, 2:right to left.
     */
    enum FilterType
    {
        /** \~chinese 不补全。 \~english No completion. */
        NoCompletion = 0,
        /** \~chinese 左向右。 \~english Left to right. */
        LeftToRight = 1,
        /** \~chinese 右向左。 \~english Right to left. */
        RightToLeft = 2
    };

    SeamType getSeamType() const override;

    /** @brief 激光补全模式 \~chinese 激光补全模式 \~english Laser completion mode */
    int v_filter_type = 0;
    /** @brief 补全位置（0：上，1：下） \~chinese 补全位置（0：上，1：下） \~english Completion position (0: upper, 1: lower) */
    int v_laser_down = 0;
    /** @brief 选点位置 \~chinese 选点位置 \~english Seam point position */
    int v_seampoint_type = 0;
    /** @brief 计算窗口b \~chinese 计算窗口b \~english Calculation window b */
    int v_add_window = 15;
    /** @brief 宽度范围W最小值 \~chinese 宽度范围W最小值 \~english Minimum width range W value */
    double v_width_min = 0.0;
    /** @brief 宽度范围W最大值 \~chinese 宽度范围W最大值 \~english Maximum width range W value */
    double v_width_max = 300.0;
    /** @brief 错边范围H最小值 \~chinese 错边范围H最小值 \~english Minimum height misalignment range H value */
    double v_height_min = 0.0;
    /** @brief 错边范围H最大值 \~chinese 错边范围H最大值 \~english Maximum height misalignment range H value */
    double v_height_max = 300.0;
    /** @brief 拐点窗口a \~chinese 拐点窗口a \~english Inflection point window a */
    int v_window_size = 10;
    /** @brief 左横向距离l-w \~chinese 左横向距离l-w \~english Left horizontal distance l-w */
    int v_window_distance_left = 20;
    /** @brief 左纵向距离l-h最小值 \~chinese 左纵向距离l-h最小值 \~english Minimum left vertical distance l-h value */
    double v_window_lap_min_left = 8.0;
    /** @brief 左纵向距离l-h最大值 \~chinese 左纵向距离l-h最大值 \~english Maximum left vertical distance l-h value */
    double v_window_lap_max_left = 1000.0;
    /** @brief 右横向距离r-w \~chinese 右横向距离r-w \~english Right horizontal distance r-w */
    int v_window_distance_right = 20;
    /** @brief 右纵向距离r-h最小值 \~chinese 右纵向距离r-h最小值 \~english Minimum right vertical distance r-h value */
    double v_window_lap_min_right = 8.0;
    /** @brief 右纵向距离r-h最大值 \~chinese 右纵向距离r-h最大值 \~english Maximum right vertical distance r-h value */
    double v_window_lap_max_right = 1000.0;
    /** @brief 兼容焊点 \~chinese 兼容焊点 \~english Compatible solder joint */
    int v_compatible_solder_joint = 0;
    /** @brief 激光完整检测 \~chinese 激光完整检测 \~english Laser integrality check */
    int v_laser_integrality = 80;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief V 型坡口算法参数更新 \~english @brief V-groove algorithm parameter update
 * \~chinese V 型坡口焊缝算法参数更新
 * \~english V-groove weld algorithm parameter update
 */
class AT_VISION_API JointVAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 激光补全模式 \~chinese 激光补全模式 \~english Laser completion mode */
    std::optional<int> v_filter_type;
    /** @brief 补全位置（0：上，1：下） \~chinese 补全位置（0：上，1：下） \~english Completion position (0: upper, 1: lower) */
    std::optional<int> v_laser_down;
    /** @brief 选点位置 \~chinese 选点位置 \~english Seam point position */
    std::optional<int> v_seampoint_type;
    /** @brief 计算窗口b \~chinese 计算窗口b \~english Calculation window b */
    std::optional<int> v_add_window;
    /** @brief 宽度范围W \~chinese 宽度范围W \~english width range W */
    std::optional<DoubleRange> v_width;
    /** @brief 错边范围H \~chinese 错边范围H \~english height misalignment range H */
    std::optional<DoubleRange> v_height;
    /** @brief 拐点窗口a \~chinese 拐点窗口a \~english Corner window a */
    std::optional<int> v_window_size;
    /** @brief 左横向距离l-w \~chinese 左横向距离l-w \~english Left horizontal distance l-w */
    std::optional<int> v_window_distance_left;
    /** @brief 左纵向距离l-h \~chinese 左纵向距离l-h \~english Left vertical distance l-h */
    std::optional<DoubleRange> v_window_lap_left;
    /** @brief 右横向距离r-w \~chinese 右横向距离r-w \~english Right horizontal distance r-w */
    std::optional<int> v_window_distance_right;
    /** @brief 右纵向距离r-h \~chinese 右纵向距离r-h \~english Right vertical distance r-h */
    std::optional<DoubleRange> v_window_lap_right;
    /** @brief 兼容焊点 \~chinese 兼容焊点 \~english Compatible solder joint */
    std::optional<int> v_compatible_solder_joint;
    /** @brief 激光完整检测 \~chinese 激光完整检测 \~english Laser integrality check */
    std::optional<int> v_laser_integrality;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 边缘算法参数 \~english @brief Edge algorithm parameters
 * \~chinese 边缘焊缝算法参数
 * \~english Edge weld algorithm parameters
 */
class AT_VISION_API JointEdgeAlgoInfo : public AlgoBaseInfo {
public:
    SeamType getSeamType() const override;

    /** @brief 连续长度L \~chinese 连续长度L \~english Continuous length L */
    double edge_match_window = 0.0;
    /** @brief 边缘落差H \~chinese 边缘落差H \~english Edge height difference H */
    double edge_max_diff_col = 0.0;
    /** @brief 是否是左边缘 \~chinese 是否是左边缘 \~english Is left edge */
    bool l_r_edge = false;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 边缘算法参数更新 \~english @brief Edge algorithm parameter update
 * \~chinese 边缘焊缝算法参数更新
 * \~english Edge weld algorithm parameter update
 */
class AT_VISION_API JointEdgeAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 连续长度L \~chinese 连续长度L \~english Continuous length L */
    std::optional<double> edge_match_window;
    /** @brief 边缘落差H \~chinese 边缘落差H \~english Edge height difference H */
    std::optional<double> edge_max_diff_col;
    /** @brief 是否是左边缘 \~chinese 是否是左边缘 \~english Is left edge */
    std::optional<bool> l_r_edge;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 角焊缝算法参数 \~english @brief Fillet weld algorithm parameters
 * \~chinese 角焊缝算法参数
 * \~english Corner weld algorithm parameters
 */
class AT_VISION_API JointCornerAlgoInfo : public AlgoBaseInfo {
public:
    JointCornerAlgoInfo();
    SeamType getSeamType() const override;

    /** @brief 激光倾斜偏差 \~chinese 激光倾斜偏差 \~english Laser tilt deviation */
    double corner_max_dis = 7.0;
    /** @brief 最短激光线长度 \~chinese 最短激光线长度 \~english Minimum laser line length */
    int corner_min_length = 40;
    /** @brief 滤波窗口大小 \~chinese 滤波窗口大小 \~english Filter window size */
    int corner_erode_size = 5;
    /** @brief 激光线最小倾角 \~chinese 激光线最小倾角 \~english Minimum laser line angle */
    int corner_angle = 5;
    /** @brief 计算类型，1:内角接，2:外角接，3:通用，4:新松标定 \~english CPT type, 1:inner, 2:outer, 3:general, 4:Xinsong calibration */
    int cpt_type = 1;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 角焊缝算法参数更新 \~english @brief Fillet weld algorithm parameter update
 * \~chinese 角焊缝算法参数更新
 * \~english Corner weld algorithm parameter update
 */
class AT_VISION_API JointCornerAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 激光倾斜偏差 \~chinese 激光倾斜偏差 \~english Laser tilt deviation */
    std::optional<double> corner_max_dis;
    /** @brief 最短激光线长度 \~chinese 最短激光线长度 \~english Minimum laser line length */
    std::optional<int> corner_min_length;
    /** @brief 滤波窗口大小 \~chinese 滤波窗口大小 \~english Filter window size */
    std::optional<int> corner_erode_size;
    /** @brief 激光线最小倾角 \~chinese 激光线最小倾角 \~english Minimum laser line angle */
    std::optional<int> corner_angle;
    /** @brief 计算类型，1:内角接，2:外角接，3:通用，4:新松标定 \~english CPT type, 1:inner, 2:outer, 3:general, 4:Xinsong calibration */
    std::optional<int> cpt_type;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 微小焊缝算法参数 \~english @brief Micro weld algorithm parameters
 * \~chinese 微小焊缝算法参数
 * \~english Micro weld algorithm parameters
 */
class AT_VISION_API JointMicroAlgoInfo : public AlgoBaseInfo {
public:
    SeamType getSeamType() const override;

    /** @brief 激光线灰度阈值 \~chinese 激光线灰度阈值 \~english Laser line gray threshold */
    int threshold_laser_gray = -1;
    /** @brief 焊缝线灰度阈值 \~chinese 焊缝线灰度阈值 \~english Seam line gray threshold */
    int threshold_seam_gray = -1;
    /** @brief 激光宽度阈值 \~chinese 激光宽度阈值 \~english Laser width threshold */
    int threshold_laser_width = -1;
    /** @brief 焊缝宽度阈值 \~chinese 焊缝宽度阈值 \~english Seam width threshold */
    int threshold_seam_width = -1;
    /** @brief 左激光初始化角度θ1最小值 \~chinese 左激光初始化角度θ1最小值 \~english Minimum left laser initial angle θ1 value */
    int micro_laser_angle_left_min = -1;
    /** @brief 左激光初始化角度θ1最大值 \~chinese 左激光初始化角度θ1最大值 \~english Maximum left laser initial angle θ1 value */
    int micro_laser_angle_left_max = -1;
    /** @brief 右激光初始化角度θ2最小值 \~chinese 右激光初始化角度θ2最小值 \~english Minimum right laser initial angle θ2 value */
    int micro_laser_angle_right_min = -1;
    /** @brief 右激光初始化角度θ2最大值 \~chinese 右激光初始化角度θ2最大值 \~english Maximum right laser initial angle θ2 value */
    int micro_laser_angle_right_max = -1;
    /** @brief 焊缝线角度θ3最小值 \~chinese 焊缝线角度θ3最小值 \~english Minimum seam line angle θ3 value */
    int micro_seam_angle_min = -1;
    /** @brief 焊缝线角度θ3最大值 \~chinese 焊缝线角度θ3最大值 \~english Maximum seam line angle θ3 value */
    int micro_seam_angle_max = -1;
    /** @brief 零点异常阈值 \~chinese 零点异常阈值 \~english Zero anomaly threshold */
    double micro_zero_anomaly_ratio = 0.0;
    /** @brief 检测异常阈值 \~chinese 检测异常阈值 \~english Detection anomaly threshold */
    double micro_valid_max_ratio = 0.0;
    /** @brief 是否有白边 \~chinese 是否有白边 \~english Has white border */
    bool white_border = false;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 微小焊缝算法参数更新 \~english @brief Micro weld algorithm parameter update
 * \~chinese 微小焊缝算法参数更新
 * \~english Micro weld algorithm parameter update
 */
class AT_VISION_API JointMicroAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 激光线灰度阈值 \~chinese 激光线灰度阈值 \~english Laser line gray threshold */
    std::optional<int> threshold_laser_gray;
    /** @brief 焊缝线灰度阈值 \~chinese 焊缝线灰度阈值 \~english Seam line gray threshold */
    std::optional<int> threshold_seam_gray;
    /** @brief 激光宽度阈值 \~chinese 激光宽度阈值 \~english Laser width threshold */
    std::optional<int> threshold_laser_width;
    /** @brief 焊缝宽度阈值 \~chinese 焊缝宽度阈值 \~english Seam width threshold */
    std::optional<int> threshold_seam_width;
    /** @brief 左激光初始化角度θ1 \~chinese 左激光初始化角度θ1 \~english left laser initial angle θ1 */
    std::optional<IntRange> micro_laser_angle_left;
    /** @brief 右激光初始化角度θ2 \~chinese 右激光初始化角度θ2 \~english right laser initial angle θ2 */
    std::optional<IntRange> micro_laser_angle_right;
    /** @brief 焊缝线角度θ3 \~chinese 焊缝线角度θ3 \~english seam line angle θ3 */
    std::optional<IntRange> micro_seam_angle;
    /** @brief 零点异常阈值 \~chinese 零点异常阈值 \~english Zero anomaly threshold */
    std::optional<double> micro_zero_anomaly_ratio;
    /** @brief 检测异常阈值 \~chinese 检测异常阈值 \~english Detection anomaly threshold */
    std::optional<double> micro_valid_max_ratio;
    /** @brief 是否有白边 \~chinese 是否有白边 \~english Has white border */
    std::optional<bool> white_border;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 复杂焊缝模板 \~english @brief Complex weld template
 * \~chinese 复杂焊缝模板，包含激光轮廓数据、特征点位置及焊缝索引，作为模板匹配的依据。
 * 序列化时自动从 laser_3D 和 feature_points 计算相邻点间距(distance_points)以及模板图像点阵。
 * 约束：feature_points 数量范围 [4, 8]，相邻特征点间距须大于 0.9。
 * \~english Complex weld template containing laser profile data, feature point positions, and weld index.
 * Distances between adjacent points (distance_points) and template image point arrays are
 * computed automatically from laser_3D and feature_points during serialization.
 * Constraints: feature_points count in [4, 8], distance between adjacent points must be > 0.9.
 */
class AT_VISION_API JointComplexVAlgoTemplate : public ISerializable {
public:
    /** @brief 激光2D轮廓数据 \~chinese 激光2D轮廓数据 \~english Laser 2D profile data */
    std::vector<int> laser;
    /** @brief 激光3D坐标数据 \~chinese 激光3D坐标数据（2行=XY，3行=ZXY） \~english Laser 3D coordinate data (2 rows = XY, 3 rows = ZXY) */
    std::vector<std::vector<double>> laser_3D;
    /** @brief 特征点索引列表 \~chinese 特征点索引列表（4-8个），每个值是 laser/laser_3D 中的有效索引 \~english Feature point index list (4-8 items),
     * each value is a valid index in laser/laser_3D */
    std::vector<int> feature_points;
    /** @brief 模板焊缝索引 \~chinese 焊缝点在 feature_points 中的序号 \~english Index of the weld point within feature_points */
    int template_weld_index = 0;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 复杂焊缝算法参数 \~english @brief Complex weld algorithm parameters
 * \~chinese 复杂焊缝算法参数，包含当前 Job 的激光数据、特征点配置及匹配阈值。
 * \~english Complex weld algorithm parameters including laser data, feature point configuration, and matching threshold for the current job.
 */
class AT_VISION_API JointComplexVAlgoInfo : public AlgoBaseInfo {
public:
    JointComplexVAlgoInfo();
    SeamType getSeamType() const override;
    /** @brief 激光2D轮廓数据 \~chinese 激光2D轮廓数据 \~english Laser 2D profile data */
    std::vector<int> laser;
    /** @brief 特征点索引列表 \~chinese 特征点索引列表 \~english Feature point index list */
    std::vector<int> feature_points;
    /** @brief 模板点间距离 \~chinese 相邻特征点之间的欧式距离 \~english Euclidean distances between adjacent feature points */
    std::vector<double> distance_points;
    /** @brief 模板焊缝索引 \~chinese 焊缝点在 feature_points 中的序号 \~english Index of the weld point within feature_points */
    int template_weld_index = 0;
    /** @brief 匹配阈值 \~chinese 模板匹配阈值 \~english Template matching threshold */
    double template_threshold = 0.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 复杂焊缝算法参数更新 \~english @brief Complex weld algorithm parameter update
 * \~chinese 复杂焊缝算法参数增量更新，通过 complex_v_algo_template 整体替换模板数据。
 * 若 complex_v_algo_template 未设置则不更新模板。
 * \~english Incremental update for complex weld algorithm parameters. The template data is
 * replaced as a whole via complex_v_algo_template. If not set, the template remains unchanged.
 */
class AT_VISION_API JointComplexVAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;
    /** @brief 复杂焊缝模板 \~chinese 复杂焊缝模板（整体替换） \~english Complex weld template (full replacement) */
    std::optional<JointComplexVAlgoTemplate> complex_v_algo_template;
    /** @brief 匹配阈值 \~chinese 模板匹配阈值 \~english Template matching threshold */
    std::optional<double> template_threshold;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线组合算法参数 \~english @brief Line combination algorithm parameters
 * \~chinese 直线组合焊缝算法参数
 * \~english Line combination weld algorithm parameters
 */
class AT_VISION_API JointLineCombineAlgoInfo : public AlgoBaseInfo {
public:
    /**
     * \~chinese @brief 搭接/双线焊缝位置枚举。
     * \~english @brief Lap and two-line weld position enumeration.
     * \~chinese 当 line_fit_weld_type 为 LeftLap 或 RightLap 时使用：0:下边缘，1:上边缘，2:中间。
     * \~english Used when line_fit_weld_type is LeftLap or RightLap: 0:lower edge, 1:upper edge, 2:center.
     */
    enum LapWeldPosition
    {
        /** \~chinese 下边缘。 \~english Lower edge. */
        LowerEdge = 0,
        /** \~chinese 上边缘。 \~english Upper edge. */
        UpperEdge = 1,
        /** \~chinese 中间。 \~english Center. */
        Center = 2
    };

    /**
     * \~chinese @brief 多线焊缝位置枚举。
     * \~english @brief Multi-line weld position enumeration.
     * \~chinese 当 line_fit_weld_type 为 TwoLines、ThreeLinesLeft、ThreeLinesRight 或 FourLines 时使用：
     * \~english Used when line_fit_weld_type is TwoLines, ThreeLinesLeft, ThreeLinesRight, or FourLines:
     * \~chinese 0:交点，1:左端点，2:右端点，3:中点，4:交点与左端点中点，5:交点与右端点中点。
     * \~english 0:intersection, 1:left endpoint, 2:right endpoint, 3:midpoint, 4:intersection-left midpoint, 5:intersection-right midpoint.
     */
    enum MultiLineWeldPosition
    {
        /** \~chinese 交点。 \~english Intersection point. */
        Intersection = 0,
        /** \~chinese 左端点。 \~english Left endpoint. */
        LeftEnd = 1,
        /** \~chinese 右端点。 \~english Right endpoint. */
        RightEnd = 2,
        /** \~chinese 中点。 \~english Midpoint. */
        Midpoint = 3,
        /** \~chinese 交点与左端点中点。 \~english Midpoint between intersection and left endpoint. */
        IntersectionLeftMidpoint = 4,
        /** \~chinese 交点与右端点中点。 \~english Midpoint between intersection and right endpoint. */
        IntersectionRightMidpoint = 5
    };

    /**
     * \~chinese @brief 焊缝类型枚举。
     * \~english @brief Weld type enumeration.
     * \~chinese 0:左搭接，1:右搭接，2:两条直线，3:三条直线-左，4:三条直线-右，5:四条直线。
     * \~english 0:left lap, 1:right lap, 2:two lines, 3:three lines-left, 4:three lines-right, 5:four lines.
     */
    enum WeldType
    {
        /** \~chinese 左搭接。 \~english Left lap. */
        LeftLap = 0,
        /** \~chinese 右搭接。 \~english Right lap. */
        RightLap = 1,
        /** \~chinese 两条直线。 \~english Two lines. */
        TwoLines = 2,
        /** \~chinese 三条直线-左。 \~english Three lines on the left. */
        ThreeLinesLeft = 3,
        /** \~chinese 三条直线-右。 \~english Three lines on the right. */
        ThreeLinesRight = 4,
        /** \~chinese 四条直线。 \~english Four lines. */
        FourLines = 5
    };

    /**
     * \~chinese @brief 匹配类型枚举。
     * \~english @brief Expected metric type enumeration.
     * \~chinese 0:角度，1:宽度，2:高度。
     * \~english 0:angle, 1:width, 2:height.
     */
    enum ExpectedMetricType
    {
        /** \~chinese 角度。 \~english Angle. */
        Angle = 0,
        /** \~chinese 宽度。 \~english Width. */
        Width = 1,
        /** \~chinese 高度。 \~english Height. */
        Height = 2
    };

    /**
     * \~chinese @brief 焊缝方向枚举。
     * \~english @brief Seam direction enumeration.
     * \~chinese 0:无限制，1:上方，2:下方。
     * \~english 0:unlimited, 1:upper, 2:lower.
     */
    enum SeamDirection
    {
        /** \~chinese 无限制。 \~english Unlimited. */
        Unlimited = 0,
        /** \~chinese 上方。 \~english Upper side. */
        Upper = 1,
        /** \~chinese 下方。 \~english Lower side. */
        Lower = 2
    };

    /**
     * \~chinese @brief 修正至激光线模式枚举。
     * \~english @brief Fix-to-laser mode enumeration.
     * \~chinese 0:不修正，1:一次修正，2:二次修正。
     * \~english 0:no fix, 1:one pass, 2:two passes.
     */
    enum FixToLaserMode
    {
        /** \~chinese 不修正。 \~english No fix. */
        None = 0,
        /** \~chinese 一次修正。 \~english One-pass fix. */
        Once = 1,
        /** \~chinese 二次修正。 \~english Two-pass fix. */
        Twice = 2
    };

    SeamType getSeamType() const override;

    /**
     * \~chinese @brief 焊缝类型。
     * \~english @brief Weld type.
     * \~chinese 取值参考 WeldType。
     * \~english Uses values from WeldType.
     */
    int line_fit_weld_type = -1;
    /**
     * \~chinese @brief 焊缝位置。
     * \~english @brief Weld position.
     * \~chinese 当 line_fit_weld_type 为 LeftLap 或 RightLap 时，取值参考 LapWeldPosition；
     * \~english When line_fit_weld_type is LeftLap or RightLap, use values from LapWeldPosition;
     * \~chinese 当 line_fit_weld_type 为 TwoLines、ThreeLinesLeft、ThreeLinesRight 或 FourLines 时，取值参考 MultiLineWeldPosition。
     * \~english when line_fit_weld_type is TwoLines, ThreeLinesLeft, ThreeLinesRight, or FourLines, use values from MultiLineWeldPosition.
     */
    int line_fit_weld_position = -1;
    /** @brief 二次分割 \~chinese 二次分割 \~english Secondary segmentation */
    bool line_fit_is_wavelet = false;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double line_fit_break_threshold = 0.0;
    /** @brief 端点延伸 \~chinese 端点延伸 \~english Endpoint extension */
    double line_fit_edge_threshold = 0.0;
    /** @brief 平面阈值 \~chinese 平面阈值 \~english Plane threshold */
    double line_fit_plane_threshold = 0.0;
    /** @brief 焊缝角度最小值 \~chinese 焊缝角度最小值 \~english Minimum weld angle value */
    int line_fit_weld_angle_min = 0;
    /** @brief 焊缝角度最大值 \~chinese 焊缝角度最大值 \~english Maximum weld angle value */
    int line_fit_weld_angle_max = 0;
    /** @brief 焊缝间隙最小值 \~chinese 焊缝间隙最小值 \~english Minimum value of weld gap */
    double line_fit_weld_width_min = 0.0;
    /** @brief 焊缝间隙最大值 \~chinese 焊缝间隙最大值 \~english Maximum value of weld gap */
    double line_fit_weld_width_max = 0.0;
    /** @brief 焊缝错边最小值 \~chinese 焊缝错边最小值 \~english Minimum value of weld misalignment */
    double line_fit_weld_height_min = 0.0;
    /** @brief 焊缝错边最大值 \~chinese 焊缝错边最大值 \~english Maximum value of weld misalignment */
    double line_fit_weld_height_max = 0.0;
    /**
     * \~chinese @brief 匹配类型。
     * \~english @brief Expected metric type.
     * \~chinese 取值参考 ExpectedMetricType。
     * \~english Uses values from ExpectedMetricType.
     */
    int expected_metric_type = -1;
    /** @brief 匹配数值 \~chinese 匹配数值 \~english Matching value */
    double expected_metric_value = 0.0;
    /** @brief 平行限制 \~chinese 平行限制 \~english Parallel limit */
    bool enable_parallel_constraint = false;
    /**
     * \~chinese @brief 修正至激光线模式。
     * \~english @brief Fix-to-laser mode.
     * \~chinese 取值参考 FixToLaserMode。
     * \~english Uses values from FixToLaserMode.
     */
    int enable_fix_to_laser = -1;
    /** @brief L1 角度最小值 \~chinese L1 角度最小值 \~english Minimum L1 angle value */
    int line_fit_L1_angle_min = 0;
    /** @brief L1 角度最大值 \~chinese L1 角度最大值 \~english Maximum L1 angle value */
    int line_fit_L1_angle_max = 0;
    /** @brief L1 长度最小值 \~chinese L1 长度最小值 \~english Minimum value of L1 length */
    double line_fit_L1_length_min = 0.0;
    /** @brief L1 长度最大值 \~chinese L1 长度最大值 \~english Maximum value of L1 length */
    double line_fit_L1_length_max = 0.0;
    /** @brief L2 角度最小值 \~chinese L2 角度最小值 \~english Minimum L2 angle value */
    int line_fit_L2_angle_min = 0;
    /** @brief L2 角度最大值 \~chinese L2 角度最大值 \~english Maximum L2 angle value */
    int line_fit_L2_angle_max = 0;
    /** @brief L2 长度最小值 \~chinese L2 长度最小值 \~english Minimum value of L2 length */
    double line_fit_L2_length_min = 0.0;
    /** @brief L2 长度最大值 \~chinese L2 长度最大值 \~english Maximum value of L2 length */
    double line_fit_L2_length_max = 0.0;
    /** @brief L3 角度最小值 \~chinese L3 角度最小值 \~english Minimum L3 angle value */
    int line_fit_L3_angle_min = 0;
    /** @brief L3 角度最大值 \~chinese L3 角度最大值 \~english Maximum L3 angle value */
    int line_fit_L3_angle_max = 0;
    /** @brief L3 长度最小值 \~chinese L3 长度最小值 \~english Minimum value of L3 length */
    double line_fit_L3_length_min = 0.0;
    /** @brief L3 长度最大值 \~chinese L3 长度最大值 \~english Maximum value of L3 length */
    double line_fit_L3_length_max = 0.0;
    /** @brief L4 角度最小值 \~chinese L4 角度最小值 \~english Minimum L4 angle value */
    int line_fit_L4_angle_min = 0;
    /** @brief L4 角度最大值 \~chinese L4 角度最大值 \~english Maximum L4 angle value */
    int line_fit_L4_angle_max = 0;
    /** @brief L4 长度最小值 \~chinese L4 长度最小值 \~english Minimum value of L4 length */
    double line_fit_L4_length_min = 0.0;
    /** @brief L4 长度最大值 \~chinese L4 长度最大值 \~english Maximum value of L4 length */
    double line_fit_L4_length_max = 0.0;
    /** @brief 像素分割阈值 \~chinese 像素分割阈值 \~english Pixel segmentation threshold */
    int line_fit_continuity_gap_thres = -1;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    bool line_fit_show_all_lines = false;
    /** @brief 搭接角度 \~chinese 搭接角度 \~english Lap angle */
    int line_fit_lap_angle = 0;
    /** @brief 连续性终止 \~chinese 连续性终止 \~english Continuity termination */
    bool line_fit_is_continuity_enable = false;
    /**
     * \~chinese @brief 焊缝方向。
     * \~english @brief Seam direction.
     * \~chinese 取值参考 SeamDirection。
     * \~english Uses values from SeamDirection.
     */
    int line_fit_seam_direction = -1;
    /** @brief 高度正负区分 \~chinese 高度正负区分 \~english Height sign distinction */
    bool line_fit_is_height_signed = false;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线组合算法参数更新 \~english @brief Line combination algorithm parameter update
 * \~chinese 直线组合焊缝算法参数更新
 * \~english Line combination weld algorithm parameter update
 */
class AT_VISION_API JointLineCombineAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /**
     * \~chinese @brief 焊缝类型。
     * \~english @brief Weld type.
     * \~chinese 取值参考 JointLineCombineAlgoInfo::WeldType。
     * \~english Uses values from JointLineCombineAlgoInfo::WeldType.
     */
    std::optional<int> line_fit_weld_type;
    /**
     * \~chinese @brief 焊缝位置。
     * \~english @brief Weld position.
     * \~chinese 当 line_fit_weld_type 为 JointLineCombineAlgoInfo::LeftLap 或 RightLap 时，
     * \~english When line_fit_weld_type is JointLineCombineAlgoInfo::LeftLap or RightLap,
     * \~chinese 取值参考 JointLineCombineAlgoInfo::LapWeldPosition；当 line_fit_weld_type 为
     * \~english use values from JointLineCombineAlgoInfo::LapWeldPosition; when line_fit_weld_type is
     * \~chinese JointLineCombineAlgoInfo::TwoLines、ThreeLinesLeft、ThreeLinesRight 或 FourLines 时，
     * \~english JointLineCombineAlgoInfo::TwoLines, ThreeLinesLeft, ThreeLinesRight, or FourLines,
     * \~chinese 取值参考 JointLineCombineAlgoInfo::MultiLineWeldPosition。
     * \~english use values from JointLineCombineAlgoInfo::MultiLineWeldPosition.
     */
    std::optional<int> line_fit_weld_position;
    /** @brief 二次分割 \~chinese 二次分割 \~english Secondary segmentation */
    std::optional<bool> line_fit_is_wavelet;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> line_fit_break_threshold;
    /** @brief 端点延伸 \~chinese 端点延伸 \~english Endpoint extension */
    std::optional<double> line_fit_edge_threshold;
    /** @brief 平面阈值 \~chinese 平面阈值 \~english Plane threshold */
    std::optional<double> line_fit_plane_threshold;
    /** @brief 焊缝角度 \~chinese 焊缝角度 \~english weld angle */
    std::optional<IntRange> line_fit_weld_angle;
    /** @brief 焊缝间隙 \~chinese 焊缝间隙 \~english weld gap */
    std::optional<DoubleRange> line_fit_weld_width;
    /** @brief 焊缝错边 \~chinese 焊缝错边 \~english weld misalignment */
    std::optional<DoubleRange> line_fit_weld_height;
    /**
     * \~chinese @brief 匹配类型。
     * \~english @brief Expected metric type.
     * \~chinese 取值参考 JointLineCombineAlgoInfo::ExpectedMetricType。
     * \~english Uses values from JointLineCombineAlgoInfo::ExpectedMetricType.
     */
    std::optional<int> expected_metric_type;
    /** @brief 匹配数值 \~chinese 匹配数值 \~english Matching value */
    std::optional<double> expected_metric_value;
    /** @brief 平行限制 \~chinese 平行限制 \~english Parallel limit */
    std::optional<bool> enable_parallel_constraint;
    /**
     * \~chinese @brief 修正至激光线模式。
     * \~english @brief Fix-to-laser mode.
     * \~chinese 取值参考 JointLineCombineAlgoInfo::FixToLaserMode。
     * \~english Uses values from JointLineCombineAlgoInfo::FixToLaserMode.
     */
    std::optional<int> enable_fix_to_laser;
    /** @brief L1 角度 \~chinese L1 角度 \~english L1 angle */
    std::optional<IntRange> line_fit_L1_angle;
    /** @brief L1 长度 \~chinese L1 长度 \~english L1 length */
    std::optional<DoubleRange> line_fit_L1_length;
    /** @brief L2 角度 \~chinese L2 角度 \~english L2 angle */
    std::optional<IntRange> line_fit_L2_angle;
    /** @brief L2 长度 \~chinese L2 长度 \~english L2 length */
    std::optional<DoubleRange> line_fit_L2_length;
    /** @brief L3 角度 \~chinese L3 角度 \~english L3 angle */
    std::optional<IntRange> line_fit_L3_angle;
    /** @brief L3 长度 \~chinese L3 长度 \~english L3 length */
    std::optional<DoubleRange> line_fit_L3_length;
    /** @brief L4 角度 \~chinese L4 角度 \~english L4 angle */
    std::optional<IntRange> line_fit_L4_angle;
    /** @brief L4 长度 \~chinese L4 长度 \~english L4 length */
    std::optional<DoubleRange> line_fit_L4_length;
    /** @brief 像素分割阈值 \~chinese 像素分割阈值 \~english Pixel segmentation threshold */
    std::optional<int> line_fit_continuity_gap_thres;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    std::optional<bool> line_fit_show_all_lines;
    /** @brief 搭接角度 \~chinese 搭接角度 \~english Lap angle */
    std::optional<int> line_fit_lap_angle;
    /** @brief 连续性终止 \~chinese 连续性终止 \~english Continuity termination */
    std::optional<bool> line_fit_is_continuity_enable;
    /**
     * \~chinese @brief 焊缝方向。
     * \~english @brief Seam direction.
     * \~chinese 取值参考 JointLineCombineAlgoInfo::SeamDirection。
     * \~english Uses values from JointLineCombineAlgoInfo::SeamDirection.
     */
    std::optional<int> line_fit_seam_direction;
    /** @brief 高度正负区分 \~chinese 高度正负区分 \~english Height sign distinction */
    std::optional<bool> line_fit_is_height_signed;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 细对接焊缝算法参数 \~english @brief Narrow butt weld algorithm parameters
 * \~chinese 细对接焊缝算法参数
 * \~english Narrow 2D weld algorithm parameters
 */
class AT_VISION_API JointNarrow2DAlgoInfo : public AlgoBaseInfo {
public:
    SeamType getSeamType() const override;

    /** @brief 增强模式 \~chinese 增强模式 \~english Enhance mode */
    int enhance_mode = 1;
    /** @brief 高级设置标志 \~chinese 高级设置标志 \~english Advanced setting flag */
    bool advanced_setting_flag = false;
    /** @brief 焊缝宽度范围w最小值 \~chinese 焊缝宽度范围w最小值 \~english Minimum weld width range w value */
    double gap_thre_min = 0.0;
    /** @brief 焊缝宽度范围w最大值 \~chinese 焊缝宽度范围w最大值 \~english Maximum weld width range w value */
    double gap_thre_max = 100.0;
    /** @brief 焊缝角度最小值 \~chinese 焊缝角度最小值 \~english Minimum weld angle value */
    int angle_weld_min = 75;
    /** @brief 焊缝角度最大值 \~chinese 焊缝角度最大值 \~english Maximum weld angle value */
    int angle_weld_max = 105;
    /** @brief 左激光线角度范围α1最小值 \~chinese 左激光线角度范围α1最小值 \~english Minimum left laser line angle range α1 value */
    int angle_laser_min = -5;
    /** @brief 左激光线角度范围α1最大值 \~chinese 左激光线角度范围α1最大值 \~english Maximum left laser line angle range α1 value */
    int angle_laser_max = 5;
    /** @brief 右激光线角度范围α2最小值 \~chinese 右激光线角度范围α2最小值 \~english Minimum right laser line angle range α2 value */
    int angle_laser_right_min = -5;
    /** @brief 右激光线角度范围α2最大值 \~chinese 右激光线角度范围α2最大值 \~english Maximum right laser line angle range α2 value */
    int angle_laser_right_max = 5;
    /** @brief 焊缝检测阈值 \~chinese 焊缝检测阈值 \~english Weld detection threshold */
    double vote_weld = 10.0;
    /** @brief 激光检测阈值 \~chinese 激光检测阈值 \~english Laser detection threshold */
    double vote_laser = 10.0;
    /** @brief 对比度增强系数 \~chinese 对比度增强系数 \~english Contrast enhancement factor */
    double edge_gain = 0.0;
    /** @brief 噪点模糊系数 \~chinese 噪点模糊系数 \~english Noise blur coefficient */
    int gs_kernel = 5;
    /** @brief 霍夫拟合离散步长 \~chinese 霍夫拟合离散步长 \~english Hough fitting discrete step */
    int ex_kernel = 1;
    /** @brief 拟合焊缝行采样点数 \~chinese 拟合焊缝行采样点数 \~english Weld row sampling points for fitting */
    int fit_gain = 10;
    /** @brief 拟合显示 \~chinese 拟合显示 \~english Fit display */
    bool check_gain = false;
    /** @brief 跟踪半径 \~chinese 跟踪半径 \~english Track radius */
    int track_radius = 0;
    /** @brief 焊缝线类型 \~chinese 焊缝线类型 \~english Weld line type */
    int weld_line_type = 0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 细对接焊缝算法参数更新 \~english @brief Narrow butt weld algorithm parameter update
 * \~chinese 细对接焊缝算法参数更新
 * \~english Narrow 2D weld algorithm parameter update
 */
class AT_VISION_API JointNarrow2DAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 增强模式 \~chinese 增强模式 \~english Enhance mode */
    std::optional<int> enhance_mode;
    /** @brief 高级设置标志 \~chinese 高级设置标志 \~english Advanced setting flag */
    std::optional<bool> advanced_setting_flag;
    /** @brief 焊缝宽度范围w \~chinese 焊缝宽度范围w \~english weld width range w */
    std::optional<DoubleRange> gap_thre;
    /** @brief 焊缝角度 \~chinese 焊缝角度 \~english weld angle */
    std::optional<IntRange> angle_weld;
    /** @brief 左激光线角度范围α1 \~chinese 左激光线角度范围α1 \~english left laser line angle range α1 */
    std::optional<IntRange> angle_laser;
    /** @brief 右激光线角度范围α2 \~chinese 右激光线角度范围α2 \~english right laser line angle range α2 */
    std::optional<IntRange> angle_laser_right;
    /** @brief 焊缝检测阈值 \~chinese 焊缝检测阈值 \~english Weld detection threshold */
    std::optional<double> vote_weld;
    /** @brief 激光检测阈值 \~chinese 激光检测阈值 \~english Laser detection threshold */
    std::optional<double> vote_laser;
    /** @brief 对比度增强系数 \~chinese 对比度增强系数 \~english Contrast enhancement factor */
    std::optional<double> edge_gain;
    /** @brief 噪点模糊系数 \~chinese 噪点模糊系数 \~english Noise blur coefficient */
    std::optional<int> gs_kernel;
    /** @brief 霍夫拟合离散步长 \~chinese 霍夫拟合离散步长 \~english Hough fitting discrete step */
    std::optional<int> ex_kernel;
    /** @brief 拟合焊缝行采样点数 \~chinese 拟合焊缝行采样点数 \~english Weld row sampling points for fitting */
    std::optional<int> fit_gain;
    /** @brief 拟合显示 \~chinese 拟合显示 \~english Fit display */
    std::optional<bool> check_gain;
    /** @brief 跟踪半径 \~chinese 跟踪半径 \~english Track radius */
    std::optional<int> track_radius;
    /** @brief 焊缝线类型 \~chinese 焊缝线类型 \~english Weld line type */
    std::optional<int> weld_line_type;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线模板单条直线参数 \~english @brief Parameters for one line-template line slot
 */
struct AT_VISION_API LineTemplateLineParam {
    /** @brief 直线角度范围 \~chinese 直线角度范围 \~english Line angle range */
    DoubleRange angle{-90.0, 90.0};
    /** @brief 直线最小长度 \~chinese 直线最小长度 \~english Minimum line length */
    double length_min = 0.0;
};

/**
 * \~chinese @brief 直线模板组合参数 \~english @brief Parameters for one line-template combine slot
 */
struct AT_VISION_API LineTemplateCombineParam {
    /** @brief 组合角度范围 \~chinese 组合角度范围 \~english Combine angle range */
    DoubleRange angle{0.0, 180.0};
    /** @brief 水平距离范围 \~chinese 水平距离范围 \~english Horizontal distance range */
    DoubleRange x{0.0, 100.0};
    /** @brief 垂直距离范围 \~chinese 垂直距离范围 \~english Vertical distance range */
    DoubleRange y{-100.0, 100.0};
    /** @brief 组合权重 \~chinese 组合权重 \~english Combine weight */
    double weight = 0.0;
};

/**
 * \~chinese @brief 直线模板单条直线更新参数 \~english @brief Update parameters for one line-template line slot
 */
struct AT_VISION_API LineTemplateLineParamUpdate {
    /** @brief 直线角度范围 \~chinese 直线角度范围 \~english Line angle range */
    std::optional<DoubleRange> angle;
    /** @brief 直线最小长度 \~chinese 直线最小长度 \~english Minimum line length */
    std::optional<double> length_min;
};

/**
 * \~chinese @brief 直线模板组合更新参数 \~english @brief Update parameters for one line-template combine slot
 */
struct AT_VISION_API LineTemplateCombineParamUpdate {
    /** @brief 组合角度范围 \~chinese 组合角度范围 \~english Combine angle range */
    std::optional<DoubleRange> angle;
    /** @brief 水平距离范围 \~chinese 水平距离范围 \~english Horizontal distance range */
    std::optional<DoubleRange> x;
    /** @brief 垂直距离范围 \~chinese 垂直距离范围 \~english Vertical distance range */
    std::optional<DoubleRange> y;
    /** @brief 组合权重 \~chinese 组合权重 \~english Combine weight */
    std::optional<double> weight;
};

/**
 * \~chinese @brief 直线模板算法参数 \~english @brief Line template algorithm parameters
 * \~chinese 直线模板焊缝算法参数
 * \~english Line
 * template weld algorithm parameters
 */
class AT_VISION_API JointLineTemplateAlgoInfo : public AlgoBaseInfo {
public:
    /**
     * \~chinese @brief 焊缝点类型枚举 \~english @brief Weld point type enumeration
     */
    enum WeldPointType
    {
        /** \~chinese @brief 交点 \~english @brief Intersection */
        Intersection = 0,
        /** \~chinese @brief 中点 \~english @brief Middle point */
        MiddlePoint = 1,
        /** \~chinese @brief 线1左端点 \~english @brief Line 1 left endpoint */
        Line1LeftEndpoint = 2,
        /** \~chinese @brief 线1右端点 \~english @brief Line 1 right endpoint */
        Line1RightEndpoint = 3,
        /** \~chinese @brief 线2左端点 \~english @brief Line 2 left endpoint */
        Line2LeftEndpoint = 4,
        /** \~chinese @brief 线2右端点 \~english @brief Line 2 right endpoint */
        Line2RightEndpoint = 5,
        /** \~chinese @brief 线1到线2的线1角 \~english @brief Line 1 corner from line 1 to line 2 */
        Line1ToLine2Line1Corner = 6,
        /** \~chinese @brief 线1到线2的线2角 \~english @brief Line 2 corner from line 1 to line 2 */
        Line1ToLine2Line2Corner = 7,
        /** \~chinese @brief 线2到线1的线1角 \~english @brief Line 1 corner from line 2 to line 1 */
        Line2ToLine1Line1Corner = 8,
        /** \~chinese @brief 线2到线1的线2角 \~english @brief Line 2 corner from line 2 to line 1 */
        Line2ToLine1Line2Corner = 9,
    };

    /**
     * \~chinese @brief 当前直线枚举 \~english @brief Current line enumeration
     */
    enum LineSlot
    {
        /** \~chinese @brief L1 \~english @brief L1 */
        L1 = 0,
        /** \~chinese @brief L2 \~english @brief L2 */
        L2 = 1,
        /** \~chinese @brief L3 \~english @brief L3 */
        L3 = 2,
        /** \~chinese @brief L4 \~english @brief L4 */
        L4 = 3,
    };

    /**
     * \~chinese @brief 当前组合枚举 \~english @brief Current combine enumeration
     */
    enum CombineSlot
    {
        /** \~chinese @brief C1 \~english @brief C1 */
        C1 = 0,
        /** \~chinese @brief C2 \~english @brief C2 */
        C2 = 1,
        /** \~chinese @brief C3 \~english @brief C3 */
        C3 = 2,
    };

    SeamType getSeamType() const override;

    /** @brief L1 标识 \~chinese L1 标识 \~english L1 flag */
    int line_combine_L1 = -1;
    /** @brief L2 标识 \~chinese L2 标识 \~english L2 flag */
    int line_combine_L2 = -1;
    /** @brief 焊缝点类型，取值对应 WeldPointType \~chinese 焊缝点类型，取值对应 WeldPointType \~english Weld point type; value corresponds to
     * WeldPointType */
    int line_combine_weld_type = -1;
    /** @brief 图像 S \~chinese 图像 S \~english Image S */
    std::string image_s;
    /** @brief 图像 B \~chinese 图像 B \~english Image B */
    std::string image_b;
    /** @brief 模板字符串 \~chinese 模板字符串 \~english Template string */
    std::string line_combine_template_string;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double line_combine_merge_threshold = 1.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    double line_combine_fit_threshold = 0.5;
    /** @brief L1-L4 直线参数 \~chinese L1-L4 直线参数 \~english L1-L4 line parameters */
    std::array<LineTemplateLineParam, 4> line_combine_lines;
    /** @brief 当前直线，取值对应 LineSlot \~chinese 当前直线，取值对应 LineSlot \~english Current line; value corresponds to LineSlot */
    int line_combine_line_cur_line = L1;
    /** @brief 当前组合模式 \~chinese 当前组合模式 \~english Current combine mode */
    int line_combine_line_cur_combine = C1;
    /** @brief C1-C3 组合参数 \~chinese C1-C3 组合参数 \~english C1-C3 combine parameters */
    std::array<LineTemplateCombineParam, 3> line_combine_combines;
    /** @brief 搭接角度 \~chinese 搭接角度 \~english Lap angle */
    double line_combine_lap_angle = 90.0;
    /** @brief 修正至激光线 \~chinese 修正至激光线 \~english Fix to laser line */
    bool line_combine_fix_to_laser = false;
    /** @brief 偏移距离 \~chinese 偏移距离 \~english Offset distance */
    double line_combine_offset_distance = 0.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线模板高层输入 \~english @brief High-level line template input
 *
 * \~chinese
 * 该结构体用于按 UI
 * 的“直线模板编辑器”流程创建模板。调用方从 LaserSeamResult 填入
 * laser、laser_3D、line_points
 * 和用户选中的端点索引
 * selected_points；序列化时会自动:
 * - 按 selected_points 的索引从小到大排序，每两个点组成一条直线模板线段。
 * - 从
 * laser_3D 生成 line_combine_templete_string。
 * - 生成 line_combine_templete_line_num。
 * - 按 UI
 * BaseLineCombineGraphicsView::setDefaultLineTemplateParams()
 * 规则生成 L/C 默认约束。
 *
 * 校验规则与 UI 保存前的数据规则保持一致: selected_points 数量必须为 4-8 个且为偶数；
 * 相邻线段可共享同一个 feature point，此时同一索引最多出现
 * 2
 * 次；
 * 索引必须在 laser_3D 内有效；每条模板线段的端点 3D 距离必须大于 0.9；每条线段至少有一个端点来自 feature_points；非
 * feature_points 的选点只能位于排序后的最左侧或最右侧。
 *
 * image_b/image_s 需要调用方自行生成并通过
 * JointLineTemplateAlgoInfoUpdate::image_b/image_s
 * 显式传入；该结构体不编码图像。
 *
 * \~english
 * High-level input for creating
 * a line template using the same data flow as the UI editor.
 * Fill laser, laser_3D, feature_points, and selected_points from LaserSeamResult and
 * the user's
 * selected endpoint indexes. Serialization sorts selected_points by index, allows
 * one shared feature point between adjacent segments, builds
 *
 * line_combine_templete_string, line_combine_templete_line_num, and UI-compatible L/C defaults. image_b/image_s are not encoded here; set them
 * explicitly on JointLineTemplateAlgoInfoUpdate when needed.
 */
class AT_VISION_API JointLineTemplateAlgoTemplate : public ISerializable {
public:
    /** @brief 激光2D轮廓数据 \~chinese LaserSeamResult::laser，当前仅用于索引一致性校验 \~english LaserSeamResult::laser, used for index consistency
     * validation */
    std::vector<int> laser;
    /** @brief 激光3D坐标数据 \~chinese LaserSeamResult::laser_3D（2行=XY，3行=ZXY） \~english LaserSeamResult::laser_3D (2 rows = XY, 3 rows = ZXY)
     */
    std::vector<std::vector<double>> laser_3D;
    /** @brief 特征点索引列表 \~chinese LaserSeamResult::line_points \~english LaserSeamResult::line_points */
    std::vector<int> feature_points;
    /** @brief 用户选中的模板端点索引 \~chinese 用户选中的模板端点索引，保存时按索引升序配对成线；相邻线段共享端点时同一索引最多出现 2 次

     * *
     * \~english Selected endpoint indexes, sorted before pairing; adjacent segments may share one endpoint, so an index may appear at most twice */
    std::vector<int> selected_points;
    /** @brief 焊缝点类型 \~chinese 默认中点，取值对应 JointLineTemplateAlgoInfo::WeldPointType \~english Weld point type, defaults to middle point */
    int weld_type = JointLineTemplateAlgoInfo::MiddlePoint;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线模板算法参数更新 \~english @brief Line template algorithm parameter update
 * \~chinese
 * 直线模板焊缝算法参数更新

 * *
 * \~english Line template weld algorithm parameter update
 */
class AT_VISION_API JointLineTemplateAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 直线模板高层输入 \~chinese 直线模板高层输入（自动生成模板字符串、线段数和 L/C 默认约束） \~english High-level line template input */
    std::optional<JointLineTemplateAlgoTemplate> line_template_algo_template;
    /** @brief L1 标识 \~chinese L1 标识 \~english L1 flag */
    std::optional<int> line_combine_L1;
    /** @brief L2 标识 \~chinese L2 标识 \~english L2 flag */
    std::optional<int> line_combine_L2;
    /**
     * @brief 焊缝点类型，取值对应 JointLineTemplateAlgoInfo::WeldPointType
     * \~chinese 焊缝点类型，取值对应 JointLineTemplateAlgoInfo::WeldPointType
     * \~english Weld point type; value corresponds to JointLineTemplateAlgoInfo::WeldPointType
     */
    std::optional<int> line_combine_weld_type;
    /** @brief 图像 S \~chinese 图像 S \~english Image S */
    std::optional<std::string> image_s;
    /** @brief 图像 B \~chinese 图像 B \~english Image B */
    std::optional<std::string> image_b;
    /** @brief 模板字符串 \~chinese 模板字符串 \~english Template string */
    std::optional<std::string> line_combine_template_string;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> line_combine_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    std::optional<double> line_combine_fit_threshold;
    /**
     * @brief 当前编辑的直线，取值对应 JointLineTemplateAlgoInfo::LineSlot
     * \~chinese 当前编辑的直线，保存字段名为
     * line_combine_line_cur_line
     * \~english Current edited line, saved as line_combine_line_cur_line
     */
    std::optional<int> line_combine_line_cur_line;
    /** @brief L1-L4 直线更新参数 \~chinese L1-L4 直线更新参数 \~english L1-L4 line update parameters */
    std::array<LineTemplateLineParamUpdate, 4> line_combine_lines;
    /** @brief 当前组合模式 \~chinese 当前组合模式，取值对应 JointLineTemplateAlgoInfo::CombineSlot \~english Current combine mode */
    std::optional<int> line_combine_line_cur_combine;
    /** @brief C1-C3 组合更新参数 \~chinese C1-C3 组合更新参数 \~english C1-C3 combine update parameters */
    std::array<LineTemplateCombineParamUpdate, 3> line_combine_combines;
    /** @brief 搭接角度 \~chinese 搭接角度 \~english Lap angle */
    std::optional<double> line_combine_lap_angle;
    /** @brief 修正至激光线 \~chinese 修正至激光线 \~english Fix to laser line */
    std::optional<bool> line_combine_fix_to_laser;
    /** @brief 焊点偏移 \~chinese 焊点偏移 \~english Weld point offset */
    std::optional<double> line_combine_offset_distance;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线圆弧算法参数 \~english @brief Line circle algorithm parameters
 * \~chinese 直线圆弧焊缝算法参数
 * \~english Line circle weld algorithm parameters
 */
class AT_VISION_API JointLineCircleAlgoInfo : public AlgoBaseInfo {
public:
    /**
     * \~chinese @brief 圆弧使用直线数量枚举 \~english @brief Line count for arc fitting enumeration
     */
    enum CircleLineNumForCircle
    {
        OneLine = 0, ///< \~chinese 1条直线 \~english 1 line
        TwoLines = 1 ///< \~chinese 2条直线 \~english 2 lines
    };

    JointLineCircleAlgoInfo();
    SeamType getSeamType() const override;

    /** @brief 显示所有直线 \~chinese 显示所有直线 \~english Show all lines */
    bool circle_line_show_all_lines = false;
    /**
     * @brief 焊缝点类型 \~chinese 焊缝点类型 \~english Weld point type
     * \~chinese 0:圆弧在左，1:圆弧在右
     * \~english 0:arc on the left, 1:arc on the right
     */
    int circle_line_weld_type = 0;
    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 0:交点，1:圆管最外侧，2:圆管垂线交点，3:圆管垂线中心
     * \~english 0:intersection, 1:outermost point of the tube, 2:vertical line intersection on the tube, 3:vertical line center on the tube
     */
    int circle_line_weld_position = 0;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double circle_line_merge_threshold = 1.5;
    /** @brief 分割阈值 \~chinese 分割阈值 \~english Segmentation threshold */
    double circle_line_fit_threshold = 1.0;
    /** @brief 直线角度最小值 \~chinese 直线角度最小值 \~english Minimum line angle value */
    int circle_line_line_angle_min = -20;
    /** @brief 直线角度最大值 \~chinese 直线角度最大值 \~english Maximum line angle value */
    int circle_line_line_angle_max = 20;
    /** @brief 直线最小长度 \~chinese 直线最小长度 \~english Minimum line length */
    double circle_line_line_length_min = 8.0;
    /** @brief 圆弧半径最小值 \~chinese 圆弧半径最小值 \~english Minimum arc radius value */
    double circle_line_radius_min = 8.0;
    /** @brief 圆弧半径最大值 \~chinese 圆弧半径最大值 \~english Maximum arc radius value */
    double circle_line_radius_max = 30.0;
    /**
     * @brief 圆弧使用直线数量 \~chinese 圆弧使用直线数量 \~english Line count for arc fitting
     * \~chinese 参考 CircleLineNumForCircle: 0=1条直线, 1=2条直线
     * \~english See CircleLineNumForCircle: 0=1 line, 1=2 lines
     */
    int circle_line_line_num_for_circle = 1;
    /** @brief 圆弧L1角度最小值 \~chinese 圆弧L1角度最小值 \~english Minimum arc L1 angle value */
    int circle_line_circle_L1_angle_min = -1;
    /** @brief 圆弧L1角度最大值 \~chinese 圆弧L1角度最大值 \~english Maximum arc L1 angle value */
    int circle_line_circle_L1_angle_max = 1;
    /** @brief 圆弧L1最小长度 \~chinese 圆弧L1最小长度 \~english Minimum arc L1 length */
    double circle_line_circle_L1_length_min = 4.0;
    /** @brief 圆弧L2角度最小值 \~chinese 圆弧L2角度最小值 \~english Minimum arc L2 angle value */
    int circle_line_circle_L2_angle_min = -1;
    /** @brief 圆弧L2角度最大值 \~chinese 圆弧L2角度最大值 \~english Maximum arc L2 angle value */
    int circle_line_circle_L2_angle_max = 1;
    /** @brief 圆弧L2最小长度 \~chinese 圆弧L2最小长度 \~english Minimum arc L2 length */
    double circle_line_circle_L2_length_min = 4.0;
    /** @brief 直线丢弃比例 \~chinese 直线丢弃比例 \~english Line discard ratio */
    int circle_line_line_discard_ratio = 0;
    /** @brief 圆弧丢弃比例 \~chinese 圆弧丢弃比例 \~english Circle discard ratio */
    int circle_line_circle_discard_ratio = 0;
    /** @brief 焊缝间隙最小值 \~chinese 焊缝间隙最小值 \~english Minimum value of weld gap */
    double circle_line_weld_width_min = 0.0;
    /** @brief 焊缝间隙最大值 \~chinese 焊缝间隙最大值 \~english Maximum value of weld gap */
    double circle_line_weld_width_max = 4.0;
    /** @brief 焊缝错边最小值 \~chinese 焊缝错边最小值 \~english Minimum value of weld misalignment */
    double circle_line_weld_height_min = 0.0;
    /** @brief 焊缝错边最大值 \~chinese 焊缝错边最大值 \~english Maximum value of weld misalignment */
    double circle_line_weld_height_max = 4.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线圆弧算法参数更新 \~english @brief Line circle algorithm parameter update
 * \~chinese 直线圆弧焊缝算法参数更新
 * \~english Line circle weld algorithm parameter update
 */
class AT_VISION_API JointLineCircleAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 显示所有直线 \~chinese 显示所有直线 \~english Show all lines */
    std::optional<bool> circle_line_show_all_lines;
    /**
     * @brief 焊缝点类型 \~chinese 焊缝点类型 \~english Weld point type
     * \~chinese 0:圆弧在左，1:圆弧在右
     * \~english 0:arc on the left, 1:arc on the right
     */
    std::optional<int> circle_line_weld_type;
    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 0:交点，1:圆管最外侧，2:圆管垂线交点，3:圆管垂线中心
     * \~english 0:intersection, 1:outermost point of the tube, 2:vertical line intersection on the tube, 3:vertical line center on the tube
     */
    std::optional<int> circle_line_weld_position;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> circle_line_merge_threshold;
    /** @brief 分割阈值 \~chinese 分割阈值 \~english Segmentation threshold */
    std::optional<double> circle_line_fit_threshold;
    /** @brief 直线角度 \~chinese 直线角度 \~english line angle */
    std::optional<IntRange> circle_line_line_angle;
    /** @brief 直线最小长度 \~chinese 直线最小长度 \~english Minimum line length */
    std::optional<double> circle_line_line_length_min;
    /** @brief 圆弧半径 \~chinese 圆弧半径 \~english arc radius */
    std::optional<DoubleRange> circle_line_radius;
    /**
     * @brief 圆弧使用直线数量 \~chinese 圆弧使用直线数量 \~english Line count for arc fitting
     * \~chinese 参考 CircleLineNumForCircle: 0=1条直线, 1=2条直线
     * \~english See CircleLineNumForCircle: 0=1 line, 1=2 lines
     */
    std::optional<int> circle_line_line_num_for_circle;
    /** @brief 圆弧L1角度 \~chinese 圆弧L1角度 \~english arc L1 angle */
    std::optional<IntRange> circle_line_circle_L1_angle;
    /** @brief 圆弧L1最小长度 \~chinese 圆弧L1最小长度 \~english Minimum arc L1 length */
    std::optional<double> circle_line_circle_L1_length_min;
    /** @brief 圆弧L2角度 \~chinese 圆弧L2角度 \~english arc L2 angle */
    std::optional<IntRange> circle_line_circle_L2_angle;
    /** @brief 圆弧L2最小长度 \~chinese 圆弧L2最小长度 \~english Minimum arc L2 length */
    std::optional<double> circle_line_circle_L2_length_min;
    /** @brief 直线丢弃比例 \~chinese 直线丢弃比例 \~english Line discard ratio */
    std::optional<int> circle_line_line_discard_ratio;
    /** @brief 圆弧丢弃比例 \~chinese 圆弧丢弃比例 \~english Circle discard ratio */
    std::optional<int> circle_line_circle_discard_ratio;
    /** @brief 焊缝间隙 \~chinese 焊缝间隙 \~english weld gap */
    std::optional<DoubleRange> circle_line_weld_width;
    /** @brief 焊缝错边 \~chinese 焊缝错边 \~english weld misalignment */
    std::optional<DoubleRange> circle_line_weld_height;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线右搭接算法参数 \~english @brief Line right lap algorithm parameters
 * \~chinese 直线右搭接焊缝算法参数
 * \~english Line right lap weld algorithm parameters
 */
class AT_VISION_API LineRightLapAlgoInfo : public AlgoBaseInfo {
public:
    LineRightLapAlgoInfo();
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置枚举 \~chinese 焊缝位置枚举 \~english Weld position enumeration
     * \~chinese 0:上边缘，1:下边缘
     * \~english 0:upper edge, 1:lower edge
     */
    enum WeldPosition
    {
        /** \~chinese 上边缘。 \~english Upper edge. */
        UpperEdge = 0,
        /** \~chinese 下边缘。 \~english Lower edge. */
        LowerEdge = 1
    };

    /** @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position */
    int line_right_lap_weld_position = 0;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    bool line_right_lap_show_all_lines = false;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double line_right_lap_merge_threshold = 1.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    double line_right_lap_fit_threshold = 1.0;
    /** @brief L1 角度最小值 \~chinese L1 角度最小值 \~english Minimum L1 angle value */
    int line_right_lap_L1_angle_min = -30;
    /** @brief L1 角度最大值 \~chinese L1 角度最大值 \~english Maximum L1 angle value */
    int line_right_lap_L1_angle_max = 30;
    /** @brief L1 长度最小值 \~chinese L1 长度最小值 \~english Minimum value of L1 length */
    double line_right_lap_L1_length_min = 5.0;
    /** @brief L2 角度最小值 \~chinese L2 角度最小值 \~english Minimum L2 angle value */
    int line_right_lap_L2_angle_min = -30;
    /** @brief L2 角度最大值 \~chinese L2 角度最大值 \~english Maximum L2 angle value */
    int line_right_lap_L2_angle_max = 30;
    /** @brief L2 长度最小值 \~chinese L2 长度最小值 \~english Minimum value of L2 length */
    double line_right_lap_L2_length_min = 5.0;
    /** @brief 焊缝间隙最小值 \~chinese 焊缝间隙最小值 \~english Minimum value of weld gap */
    double line_right_lap_weld_width_min = 0.0;
    /** @brief 焊缝间隙最大值 \~chinese 焊缝间隙最大值 \~english Maximum value of weld gap */
    double line_right_lap_weld_width_max = 30.0;
    /** @brief 焊缝错边最小值 \~chinese 焊缝错边最小值 \~english Minimum value of weld misalignment */
    double line_right_lap_weld_height_min = 1.0;
    /** @brief 焊缝错边最大值 \~chinese 焊缝错边最大值 \~english Maximum value of weld misalignment */
    double line_right_lap_weld_height_max = 80.0;
    /** @brief 搭接角度 \~chinese 搭接角度 \~english Lap angle */
    int line_right_lap_angle = 90;
    /** @brief L1 长度最大值 \~chinese L1 长度最大值 \~english Maximum value of L1 length */
    double line_right_lap_L1_length_max = 200.0;
    /** @brief L2 长度最大值 \~chinese L2 长度最大值 \~english Maximum value of L2 length */
    double line_right_lap_L2_length_max = 200.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线右搭接算法参数更新 \~english @brief Line right lap algorithm parameter update
 * \~chinese 直线右搭接焊缝算法参数更新
 * \~english Line right lap weld algorithm parameter update
 */
class AT_VISION_API LineRightLapAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position */
    std::optional<int> line_right_lap_weld_position;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    std::optional<bool> line_right_lap_show_all_lines;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> line_right_lap_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    std::optional<double> line_right_lap_fit_threshold;
    /** @brief L1 角度 \~chinese L1 角度 \~english L1 angle */
    std::optional<IntRange> line_right_lap_L1_angle;
    /** @brief L1 长度 \~chinese L1 长度 \~english L1 length */
    std::optional<DoubleRange> line_right_lap_L1_length;
    /** @brief L2 角度 \~chinese L2 角度 \~english L2 angle */
    std::optional<IntRange> line_right_lap_L2_angle;
    /** @brief L2 长度 \~chinese L2 长度 \~english L2 length */
    std::optional<DoubleRange> line_right_lap_L2_length;
    /** @brief 焊缝间隙 \~chinese 焊缝间隙 \~english weld gap */
    std::optional<DoubleRange> line_right_lap_weld_width;
    /** @brief 焊缝错边 \~chinese 焊缝错边 \~english weld misalignment */
    std::optional<DoubleRange> line_right_lap_weld_height;
    /** @brief 搭接角度 \~chinese 搭接角度 \~english Lap angle */
    std::optional<int> line_right_lap_angle;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线内角算法参数 \~english @brief Line internal corner algorithm parameters
 * \~chinese 直线内角焊缝算法参数
 * \~english Line internal corner weld algorithm parameters
 */
class AT_VISION_API LineInternalCornerAlgoInfo : public AlgoBaseInfo {
public:
    LineInternalCornerAlgoInfo();
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置枚举 \~chinese 焊缝位置枚举 \~english Weld position enumeration
     * \~chinese 0:交点，1:左边缘，2:右边缘，3:中点
     * \~english 0:intersection, 1:left edge, 2:right edge, 3:midpoint
     */
    enum WeldPosition
    {
        /** \~chinese 交点。 \~english Intersection. */
        Intersection = 0,
        /** \~chinese 左边缘。 \~english Left edge. */
        LeftEdge = 1,
        /** \~chinese 右边缘。 \~english Right edge. */
        RightEdge = 2,
        /** \~chinese 中点。 \~english Midpoint. */
        Midpoint = 3
    };

    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 取值应使用 WeldPosition 枚举值
     * \~english Uses values from WeldPosition
     */
    int line_internal_corner_weld_position = Intersection;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    bool line_internal_corner_show_all_lines = false;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double line_internal_corner_merge_threshold = 2.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    double line_internal_corner_fit_threshold = 2.0;
    /** @brief L1 角度最小值 \~chinese L1 角度最小值 \~english Minimum L1 angle value */
    int line_internal_corner_L1_angle_min = -75;
    /** @brief L1 角度最大值 \~chinese L1 角度最大值 \~english Maximum L1 angle value */
    int line_internal_corner_L1_angle_max = -15;
    /** @brief L1 长度最小值 \~chinese L1 长度最小值 \~english Minimum value of L1 length */
    double line_internal_corner_L1_length_min = 10.0;
    /** @brief L2 角度最小值 \~chinese L2 角度最小值 \~english Minimum L2 angle value */
    int line_internal_corner_L2_angle_min = 15;
    /** @brief L2 角度最大值 \~chinese L2 角度最大值 \~english Maximum L2 angle value */
    int line_internal_corner_L2_angle_max = 75;
    /** @brief L2 长度最小值 \~chinese L2 长度最小值 \~english Minimum value of L2 length */
    double line_internal_corner_L2_length_min = 10.0;
    /** @brief 焊缝间隙最小值 \~chinese 焊缝间隙最小值 \~english Minimum value of weld gap */
    double line_internal_corner_weld_width_min = 0.0;
    /** @brief 焊缝间隙最大值 \~chinese 焊缝间隙最大值 \~english Maximum value of weld gap */
    double line_internal_corner_weld_width_max = 30.0;
    /** @brief 焊缝错边最小值 \~chinese 焊缝错边最小值 \~english Minimum value of weld misalignment */
    double line_internal_corner_weld_height_min = 0.0;
    /** @brief 焊缝错边最大值 \~chinese 焊缝错边最大值 \~english Maximum value of weld misalignment */
    double line_internal_corner_weld_height_max = 20.0;
    /** @brief 内角度最小值 \~chinese 内角度最小值 \~english Minimum internal corner angle value */
    int line_internal_corner_angle_min = 40;
    /** @brief 内角度最大值 \~chinese 内角度最大值 \~english Maximum internal corner angle value */
    int line_internal_corner_angle_max = 140;
    /** @brief L1 长度最大值 \~chinese L1 长度最大值 \~english Maximum value of L1 length */
    double line_internal_corner_L1_length_max = 200.0;
    /** @brief L2 长度最大值 \~chinese L2 长度最大值 \~english Maximum value of L2 length */
    double line_internal_corner_L2_length_max = 200.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线内角算法参数更新 \~english @brief Line internal corner algorithm parameter update
 * \~chinese 直线内角焊缝算法参数更新
 * \~english Line internal corner weld algorithm parameter update
 */
class AT_VISION_API LineInternalCornerAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 取值应使用 LineInternalCornerAlgoInfo::WeldPosition 枚举值
     * \~english Uses values from LineInternalCornerAlgoInfo::WeldPosition
     */
    std::optional<int> line_internal_corner_weld_position;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    std::optional<bool> line_internal_corner_show_all_lines;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> line_internal_corner_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    std::optional<double> line_internal_corner_fit_threshold;
    /** @brief L1 角度 \~chinese L1 角度 \~english L1 angle */
    std::optional<IntRange> line_internal_corner_L1_angle;
    /** @brief L1 长度 \~chinese L1 长度 \~english L1 length */
    std::optional<DoubleRange> line_internal_corner_L1_length;
    /** @brief L2 角度 \~chinese L2 角度 \~english L2 angle */
    std::optional<IntRange> line_internal_corner_L2_angle;
    /** @brief L2 长度 \~chinese L2 长度 \~english L2 length */
    std::optional<DoubleRange> line_internal_corner_L2_length;
    /** @brief 焊缝间隙 \~chinese 焊缝间隙 \~english weld gap */
    std::optional<DoubleRange> line_internal_corner_weld_width;
    /** @brief 焊缝错边 \~chinese 焊缝错边 \~english weld misalignment */
    std::optional<DoubleRange> line_internal_corner_weld_height;
    /** @brief 内角度 \~chinese 内角度 \~english internal corner angle */
    std::optional<IntRange> line_internal_corner_angle;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线外角算法参数 \~english @brief Line external corner algorithm parameters
 * \~chinese 直线外角焊缝算法参数
 * \~english Line external corner weld algorithm parameters
 */
class AT_VISION_API LineExternalCornerAlgoInfo : public AlgoBaseInfo {
public:
    LineExternalCornerAlgoInfo();
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置枚举 \~chinese 焊缝位置枚举 \~english Weld position enumeration
     * \~chinese 0:交点，1:左边缘，2:右边缘，3:中点
     * \~english 0:intersection, 1:left edge, 2:right edge, 3:midpoint
     */
    enum WeldPosition
    {
        /** \~chinese 交点。 \~english Intersection. */
        Intersection = 0,
        /** \~chinese 左边缘。 \~english Left edge. */
        LeftEdge = 1,
        /** \~chinese 右边缘。 \~english Right edge. */
        RightEdge = 2,
        /** \~chinese 中点。 \~english Midpoint. */
        Midpoint = 3
    };

    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 取值应使用 WeldPosition 枚举值
     * \~english Uses values from WeldPosition
     */
    int line_external_corner_weld_position = Intersection;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    bool line_external_corner_show_all_lines = false;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double line_external_corner_merge_threshold = 2.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    double line_external_corner_fit_threshold = 2.0;
    /** @brief L1 角度最小值 \~chinese L1 角度最小值 \~english Minimum L1 angle value */
    int line_external_corner_L1_angle_min = 15;
    /** @brief L1 角度最大值 \~chinese L1 角度最大值 \~english Maximum L1 angle value */
    int line_external_corner_L1_angle_max = 75;
    /** @brief L1 长度最小值 \~chinese L1 长度最小值 \~english Minimum value of L1 length */
    double line_external_corner_L1_length_min = 10.0;
    /** @brief L2 角度最小值 \~chinese L2 角度最小值 \~english Minimum L2 angle value */
    int line_external_corner_L2_angle_min = -75;
    /** @brief L2 角度最大值 \~chinese L2 角度最大值 \~english Maximum L2 angle value */
    int line_external_corner_L2_angle_max = -15;
    /** @brief L2 长度最小值 \~chinese L2 长度最小值 \~english Minimum value of L2 length */
    double line_external_corner_L2_length_min = 10.0;
    /** @brief 焊缝间隙最小值 \~chinese 焊缝间隙最小值 \~english Minimum value of weld gap */
    double line_external_corner_weld_width_min = 0.0;
    /** @brief 焊缝间隙最大值 \~chinese 焊缝间隙最大值 \~english Maximum value of weld gap */
    double line_external_corner_weld_width_max = 30.0;
    /** @brief 焊缝错边最小值 \~chinese 焊缝错边最小值 \~english Minimum value of weld misalignment */
    double line_external_corner_weld_height_min = 0.0;
    /** @brief 焊缝错边最大值 \~chinese 焊缝错边最大值 \~english Maximum value of weld misalignment */
    double line_external_corner_weld_height_max = 20.0;
    /** @brief 外角度最小值 \~chinese 外角度最小值 \~english Minimum external corner angle value */
    int line_external_corner_angle_min = 60;
    /** @brief 外角度最大值 \~chinese 外角度最大值 \~english Maximum external corner angle value */
    int line_external_corner_angle_max = 135;
    /** @brief L1 长度最大值 \~chinese L1 长度最大值 \~english Maximum value of L1 length */
    double line_external_corner_L1_length_max = 200.0;
    /** @brief L2 长度最大值 \~chinese L2 长度最大值 \~english Maximum value of L2 length */
    double line_external_corner_L2_length_max = 200.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线外角算法参数更新 \~english @brief Line external corner algorithm parameter update
 * \~chinese 直线外角焊缝算法参数更新
 * \~english Line external corner weld algorithm parameter update
 */
class AT_VISION_API LineExternalCornerAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 取值应使用 LineExternalCornerAlgoInfo::WeldPosition 枚举值
     * \~english Uses values from LineExternalCornerAlgoInfo::WeldPosition
     */
    std::optional<int> line_external_corner_weld_position;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    std::optional<bool> line_external_corner_show_all_lines;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> line_external_corner_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    std::optional<double> line_external_corner_fit_threshold;
    /** @brief L1 角度 \~chinese L1 角度 \~english L1 angle */
    std::optional<IntRange> line_external_corner_L1_angle;
    /** @brief L1 长度 \~chinese L1 长度 \~english L1 length */
    std::optional<DoubleRange> line_external_corner_L1_length;
    /** @brief L2 角度 \~chinese L2 角度 \~english L2 angle */
    std::optional<IntRange> line_external_corner_L2_angle;
    /** @brief L2 长度 \~chinese L2 长度 \~english L2 length */
    std::optional<DoubleRange> line_external_corner_L2_length;
    /** @brief 焊缝间隙 \~chinese 焊缝间隙 \~english weld gap */
    std::optional<DoubleRange> line_external_corner_weld_width;
    /** @brief 焊缝错边 \~chinese 焊缝错边 \~english weld misalignment */
    std::optional<DoubleRange> line_external_corner_weld_height;
    /** @brief 外角度 \~chinese 外角度 \~english external corner angle */
    std::optional<IntRange> line_external_corner_angle;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线对接算法参数 \~english @brief Line butt joint algorithm parameters
 * \~chinese 直线对接焊缝算法参数
 * \~english Line butt weld algorithm parameters
 */
class AT_VISION_API LineButtAlgoInfo : public AlgoBaseInfo {
public:
    LineButtAlgoInfo();
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置枚举 \~chinese 焊缝位置枚举 \~english Weld position enumeration
     * \~chinese 0:中点，1:左边缘，2:右边缘
     * \~english 0:midpoint, 1:left edge, 2:right edge
     */
    enum WeldPosition
    {
        /** \~chinese 中点。 \~english Midpoint. */
        Midpoint = 0,
        /** \~chinese 左边缘。 \~english Left edge. */
        LeftEdge = 1,
        /** \~chinese 右边缘。 \~english Right edge. */
        RightEdge = 2
    };

    /** @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position */
    int line_butt_weld_position = 0;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    bool line_butt_show_all_lines = false;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double line_butt_merge_threshold = 1.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    double line_butt_fit_threshold = 1.0;
    /** @brief L1 角度最小值 \~chinese L1 角度最小值 \~english Minimum L1 angle value */
    int line_butt_L1_angle_min = -30;
    /** @brief L1 角度最大值 \~chinese L1 角度最大值 \~english Maximum L1 angle value */
    int line_butt_L1_angle_max = 30;
    /** @brief L1 长度最小值 \~chinese L1 长度最小值 \~english Minimum value of L1 length */
    double line_butt_L1_length_min = 5.0;
    /** @brief L2 角度最小值 \~chinese L2 角度最小值 \~english Minimum L2 angle value */
    int line_butt_L2_angle_min = -30;
    /** @brief L2 角度最大值 \~chinese L2 角度最大值 \~english Maximum L2 angle value */
    int line_butt_L2_angle_max = 30;
    /** @brief L2 长度最小值 \~chinese L2 长度最小值 \~english Minimum value of L2 length */
    double line_butt_L2_length_min = 5.0;
    /** @brief 焊缝间隙最小值 \~chinese 焊缝间隙最小值 \~english Minimum value of weld gap */
    double line_butt_weld_width_min = 0.5;
    /** @brief 焊缝间隙最大值 \~chinese 焊缝间隙最大值 \~english Maximum value of weld gap */
    double line_butt_weld_width_max = 20.0;
    /** @brief 焊缝错边最小值 \~chinese 焊缝错边最小值 \~english Minimum value of weld misalignment */
    double line_butt_weld_height_min = 0.0;
    /** @brief 焊缝错边最大值 \~chinese 焊缝错边最大值 \~english Maximum value of weld misalignment */
    double line_butt_weld_height_max = 10.0;
    /** @brief 对接角度最小值 \~chinese 对接角度最小值 \~english Minimum butt angle value */
    int line_butt_angle_min = 140;
    /** @brief 对接角度最大值 \~chinese 对接角度最大值 \~english Maximum butt angle value */
    int line_butt_angle_max = 180;
    /** @brief L1 长度最大值 \~chinese L1 长度最大值 \~english Maximum value of L1 length */
    double line_butt_L1_length_max = 200.0;
    /** @brief L2 长度最大值 \~chinese L2 长度最大值 \~english Maximum value of L2 length */
    double line_butt_L2_length_max = 200.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线对接算法参数更新 \~english @brief Line butt joint algorithm parameter update
 * \~chinese 直线对接焊缝算法参数更新
 * \~english Line butt weld algorithm parameter update
 */
class AT_VISION_API LineButtAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position */
    std::optional<int> line_butt_weld_position;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    std::optional<bool> line_butt_show_all_lines;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> line_butt_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    std::optional<double> line_butt_fit_threshold;
    /** @brief L1 角度 \~chinese L1 角度 \~english L1 angle */
    std::optional<IntRange> line_butt_L1_angle;
    /** @brief L1 长度 \~chinese L1 长度 \~english L1 length */
    std::optional<DoubleRange> line_butt_L1_length;
    /** @brief L2 角度 \~chinese L2 角度 \~english L2 angle */
    std::optional<IntRange> line_butt_L2_angle;
    /** @brief L2 长度 \~chinese L2 长度 \~english L2 length */
    std::optional<DoubleRange> line_butt_L2_length;
    /** @brief 焊缝间隙 \~chinese 焊缝间隙 \~english weld gap */
    std::optional<DoubleRange> line_butt_weld_width;
    /** @brief 焊缝错边 \~chinese 焊缝错边 \~english weld misalignment */
    std::optional<DoubleRange> line_butt_weld_height;
    /** @brief 对接角度 \~chinese 对接角度 \~english butt angle */
    std::optional<IntRange> line_butt_angle;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线左边缘算法参数 \~english @brief Line left edge weld algorithm parameters
 */
class AT_VISION_API LineLeftEdgeAlgoInfo : public AlgoBaseInfo {
public:
    LineLeftEdgeAlgoInfo();
    SeamType getSeamType() const override;

    /** @brief 显示所有直线 \~chinese 显示所有直线 \~english Show all lines */
    bool line_left_edge_show_all_lines = false;
    /** @brief 合并阈值 \~chinese 合并阈值，单位 mm \~english Merge threshold in millimeters */
    double line_left_edge_merge_threshold = 0.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值，单位 mm \~english Fit threshold in millimeters */
    double line_left_edge_fit_threshold = 0.0;
    /** @brief 板材角度(L1)最小值 \~chinese 板材角度(L1)最小值，单位 ° \~english Minimum plate angle value (L1) in degrees */
    int line_left_edge_L1_angle_min = -25;
    /** @brief 板材角度(L1)最大值 \~chinese 板材角度(L1)最大值，单位 ° \~english Maximum plate angle value (L1) in degrees */
    int line_left_edge_L1_angle_max = 25;
    /** @brief 板材长度(L1)最小值 \~chinese 板材长度(L1)最小值，单位 mm \~english Minimum value of plate length (L1) in millimeters */
    double line_left_edge_L1_length_min = 10.0;
    /** @brief 板材长度(L1)最大值 \~chinese 板材长度(L1)最大值，单位 mm \~english Maximum value of plate length (L1) in millimeters */
    double line_left_edge_L1_length_max = 200.0;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线左边缘算法参数更新 \~english @brief Line left edge weld algorithm parameter update
 */
class AT_VISION_API LineLeftEdgeAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 显示所有直线 \~chinese 显示所有直线 \~english Show all lines */
    std::optional<bool> line_left_edge_show_all_lines;
    /** @brief 合并阈值 \~chinese 合并阈值，单位 mm \~english Merge threshold in millimeters */
    std::optional<double> line_left_edge_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值，单位 mm \~english Fit threshold in millimeters */
    std::optional<double> line_left_edge_fit_threshold;
    /** @brief 板材角度(L1) \~chinese 板材角度(L1)，单位 ° \~english plate angle (L1) in degrees */
    std::optional<IntRange> line_left_edge_L1_angle;
    /** @brief 板材长度(L1) \~chinese 板材长度(L1)，单位 mm \~english plate length (L1) in millimeters */
    std::optional<DoubleRange> line_left_edge_L1_length;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线右边缘算法参数 \~english @brief Line right edge weld algorithm parameters
 */
class AT_VISION_API LineRightEdgeAlgoInfo : public AlgoBaseInfo {
public:
    LineRightEdgeAlgoInfo();
    SeamType getSeamType() const override;

    /** @brief 显示所有直线 \~chinese 显示所有直线 \~english Show all lines */
    bool line_right_edge_show_all_lines = false;
    /** @brief 合并阈值 \~chinese 合并阈值，单位 mm \~english Merge threshold in millimeters */
    double line_right_edge_merge_threshold = 0.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值，单位 mm \~english Fit threshold in millimeters */
    double line_right_edge_fit_threshold = 0.0;
    /** @brief 板材角度(L1)最小值 \~chinese 板材角度(L1)最小值，单位 ° \~english Minimum plate angle value (L1) in degrees */
    int line_right_edge_L1_angle_min = -25;
    /** @brief 板材角度(L1)最大值 \~chinese 板材角度(L1)最大值，单位 ° \~english Maximum plate angle value (L1) in degrees */
    int line_right_edge_L1_angle_max = 25;
    /** @brief 板材长度(L1)最小值 \~chinese 板材长度(L1)最小值，单位 mm \~english Minimum value of plate length (L1) in millimeters */
    double line_right_edge_L1_length_min = 10.0;
    /** @brief 板材长度(L1)最大值 \~chinese 板材长度(L1)最大值，单位 mm \~english Maximum value of plate length (L1) in millimeters */
    double line_right_edge_L1_length_max = 200.0;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线右边缘算法参数更新 \~english @brief Line right edge weld algorithm parameter update
 */
class AT_VISION_API LineRightEdgeAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** @brief 显示所有直线 \~chinese 显示所有直线 \~english Show all lines */
    std::optional<bool> line_right_edge_show_all_lines;
    /** @brief 合并阈值 \~chinese 合并阈值，单位 mm \~english Merge threshold in millimeters */
    std::optional<double> line_right_edge_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值，单位 mm \~english Fit threshold in millimeters */
    std::optional<double> line_right_edge_fit_threshold;
    /** @brief 板材角度(L1) \~chinese 板材角度(L1)，单位 ° \~english plate angle (L1) in degrees */
    std::optional<IntRange> line_right_edge_L1_angle;
    /** @brief 板材长度(L1) \~chinese 板材长度(L1)，单位 mm \~english plate length (L1) in millimeters */
    std::optional<DoubleRange> line_right_edge_L1_length;
    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线M型角接算法参数 \~english @brief Line M-corner algorithm parameters
 * \~chinese 直线M型角接焊缝算法参数
 * \~english Line M-corner weld algorithm parameters
 */
class AT_VISION_API LineMCornerAlgoInfo : public AlgoBaseInfo {
public:
    LineMCornerAlgoInfo();
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置枚举 \~chinese 焊缝位置枚举 \~english Weld position enumeration
     * \~chinese 0:交点中心，1:交点左边缘，2:交点右边缘
     * \~english 0:intersection center, 1:intersection left edge, 2:intersection right edge
     */
    enum WeldPosition
    {
        /** \~chinese 交点中心。 \~english Intersection center. */
        IntersectionCenter = 0,
        /** \~chinese 交点左边缘。 \~english Intersection left edge. */
        IntersectionLeftEdge = 1,
        /** \~chinese 交点右边缘。 \~english Intersection right edge. */
        IntersectionRightEdge = 2
    };

    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 取值应使用 WeldPosition 枚举值
     * \~english Uses values from WeldPosition
     */
    int line_Mcorner_weld_position = IntersectionCenter;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    bool line_Mcorner_show_all_lines = false;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double line_Mcorner_merge_threshold = 1.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    double line_Mcorner_fit_threshold = 1.0;
    /** @brief L1 角度最小值 \~chinese L1 角度最小值 \~english Minimum L1 angle value */
    int line_Mcorner_L1_angle_min = 15;
    /** @brief L1 角度最大值 \~chinese L1 角度最大值 \~english Maximum L1 angle value */
    int line_Mcorner_L1_angle_max = 75;
    /** @brief L1 长度最小值 \~chinese L1 长度最小值 \~english Minimum value of L1 length */
    double line_Mcorner_L1_length_min = 8.0;
    /** @brief L4 角度最小值 \~chinese L4 角度最小值 \~english Minimum L4 angle value */
    int line_Mcorner_L4_angle_min = -75;
    /** @brief L4 角度最大值 \~chinese L4 角度最大值 \~english Maximum L4 angle value */
    int line_Mcorner_L4_angle_max = -15;
    /** @brief L4 长度最小值 \~chinese L4 长度最小值 \~english Minimum value of L4 length */
    double line_Mcorner_L4_length_min = 8.0;
    /** @brief L1L2 夹角 \~chinese L1L2 夹角 \~english L1L2 angle */
    int line_Mcorner_L1L2_angle = 90;
    /** @brief L3L4 夹角 \~chinese L3L4 夹角 \~english L3L4 angle */
    int line_Mcorner_L3L4_angle = 90;
    /** @brief L2 长度最小值 \~chinese L2 长度最小值 \~english Minimum value of L2 length */
    double line_Mcorner_L2_length_min = 3.0;
    /** @brief L2 长度最大值 \~chinese L2 长度最大值 \~english Maximum value of L2 length */
    double line_Mcorner_L2_length_max = 50.0;
    /** @brief L3 长度最小值 \~chinese L3 长度最小值 \~english Minimum value of L3 length */
    double line_Mcorner_L3_length_min = 3.0;
    /** @brief L3 长度最大值 \~chinese L3 长度最大值 \~english Maximum value of L3 length */
    double line_Mcorner_L3_length_max = 50.0;
    /** @brief L1 长度最大值 \~chinese L1 长度最大值 \~english Maximum value of L1 length */
    double line_Mcorner_L1_length_max = 200.0;
    /** @brief L4 长度最大值 \~chinese L4 长度最大值 \~english Maximum value of L4 length */
    double line_Mcorner_L4_length_max = 200.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线M型角接算法参数更新 \~english @brief Line M-corner algorithm parameter update
 * \~chinese 直线M型角接焊缝算法参数更新
 * \~english Line M-corner weld algorithm parameter update
 */
class AT_VISION_API LineMCornerAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 取值应使用 LineMCornerAlgoInfo::WeldPosition 枚举值
     * \~english Uses values from LineMCornerAlgoInfo::WeldPosition
     */
    std::optional<int> line_Mcorner_weld_position;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    std::optional<bool> line_Mcorner_show_all_lines;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> line_Mcorner_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    std::optional<double> line_Mcorner_fit_threshold;
    /** @brief L1 角度 \~chinese L1 角度 \~english L1 angle */
    std::optional<IntRange> line_Mcorner_L1_angle;
    /** @brief L1 长度 \~chinese L1 长度 \~english L1 length */
    std::optional<DoubleRange> line_Mcorner_L1_length;
    /** @brief L4 角度 \~chinese L4 角度 \~english L4 angle */
    std::optional<IntRange> line_Mcorner_L4_angle;
    /** @brief L4 长度 \~chinese L4 长度 \~english L4 length */
    std::optional<DoubleRange> line_Mcorner_L4_length;
    /** @brief L1L2 夹角 \~chinese L1L2 夹角 \~english L1L2 angle */
    std::optional<int> line_Mcorner_L1L2_angle;
    /** @brief L3L4 夹角 \~chinese L3L4 夹角 \~english L3L4 angle */
    std::optional<int> line_Mcorner_L3L4_angle;
    /** @brief L2 长度 \~chinese L2 长度 \~english L2 length */
    std::optional<DoubleRange> line_Mcorner_L2_length;
    /** @brief L3 长度 \~chinese L3 长度 \~english L3 length */
    std::optional<DoubleRange> line_Mcorner_L3_length;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线V型坡口算法参数 \~english @brief Line V-groove algorithm parameters
 * \~chinese 直线V型坡口焊缝算法参数
 * \~english Line V-groove weld algorithm parameters
 */
class AT_VISION_API LineVGrooveAlgoInfo : public AlgoBaseInfo {
public:
    LineVGrooveAlgoInfo();
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置枚举 \~chinese 焊缝位置枚举 \~english Weld position enumeration
     * \~chinese 0:下中点，1:下交点，2:左边缘，3:右边缘，4:中心
     * \~english 0:lower midpoint, 1:lower intersection, 2:left edge, 3:right edge, 4:center
     */
    enum WeldPosition
    {
        /** \~chinese 下中点。 \~english Lower midpoint. */
        LowerMidpoint = 0,
        /** \~chinese 下交点。 \~english Lower intersection. */
        LowerIntersection = 1,
        /** \~chinese 左边缘。 \~english Left edge. */
        LeftEdge = 2,
        /** \~chinese 右边缘。 \~english Right edge. */
        RightEdge = 3,
        /** \~chinese 中心。 \~english Center. */
        Center = 4
    };

    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 取值应使用 WeldPosition 枚举值
     * \~english Uses values from WeldPosition
     */
    int line_Vgroove_weld_position = LowerIntersection;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    bool line_Vgroove_show_all_lines = false;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    double line_Vgroove_merge_threshold = 1.0;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    double line_Vgroove_fit_threshold = 1.0;
    /** @brief 左板坡口角度(L2)最小值 \~chinese 左板坡口角度(L2)最小值 \~english Minimum left plate groove angle (L2) value */
    int line_Vgroove_L2_angle_min = -80;
    /** @brief 左板坡口角度(L2)最大值 \~chinese 左板坡口角度(L2)最大值 \~english Maximum left plate groove angle (L2) value */
    int line_Vgroove_L2_angle_max = -20;
    /** @brief 左板坡口长度(L2)最小值 \~chinese 左板坡口长度(L2)最小值 \~english Minimum left plate groove length (L2) value */
    double line_Vgroove_L2_length_min = 3.0;
    /** @brief 右板坡口角度(L3)最小值 \~chinese 右板坡口角度(L3)最小值 \~english Minimum right plate groove angle (L3) value */
    int line_Vgroove_L3_angle_min = 20;
    /** @brief 右板坡口角度(L3)最大值 \~chinese 右板坡口角度(L3)最大值 \~english Maximum right plate groove angle (L3) value */
    int line_Vgroove_L3_angle_max = 80;
    /** @brief 右板坡口长度(L3)最小值 \~chinese 右板坡口长度(L3)最小值 \~english Minimum right plate groove length (L3) value */
    double line_Vgroove_L3_length_min = 3.0;
    /** @brief 坡口宽度最小值 \~chinese 坡口宽度最小值 \~english Minimum groove width value */
    double line_Vgroove_weld_width_min = 3.0;
    /** @brief 坡口宽度最大值 \~chinese 坡口宽度最大值 \~english Maximum groove width value */
    double line_Vgroove_weld_width_max = 80.0;
    /** @brief 坡口深度最小值 \~chinese 坡口深度最小值 \~english Minimum groove depth value */
    double line_Vgroove_weld_height_min = 3.0;
    /** @brief 坡口深度最大值 \~chinese 坡口深度最大值 \~english Maximum groove depth value */
    double line_Vgroove_weld_height_max = 80.0;
    /** @brief 坡口角度最小值 \~chinese 坡口角度最小值 \~english Minimum groove angle value */
    int line_Vgroove_angle_min = 15;
    /** @brief 坡口角度最大值 \~chinese 坡口角度最大值 \~english Maximum groove angle value */
    int line_Vgroove_angle_max = 140;
    /** @brief L1 角度最小值 \~chinese L1 角度最小值 \~english Minimum L1 angle value */
    int line_Vgroove_L1_angle_min = -30;
    /** @brief L1 角度最大值 \~chinese L1 角度最大值 \~english Maximum L1 angle value */
    int line_Vgroove_L1_angle_max = 30;
    /** @brief L1 长度最小值 \~chinese L1 长度最小值 \~english Minimum value of L1 length */
    double line_Vgroove_L1_length_min = 8.0;
    /** @brief L1 长度最大值 \~chinese L1 长度最大值 \~english Maximum value of L1 length */
    double line_Vgroove_L1_length_max = 200.0;
    /** @brief L2 长度最大值 \~chinese L2 长度最大值 \~english Maximum value of L2 length */
    double line_Vgroove_L2_length_max = 200.0;
    /** @brief L3 长度最大值 \~chinese L3 长度最大值 \~english Maximum value of L3 length */
    double line_Vgroove_L3_length_max = 200.0;
    /** @brief L4 角度最小值 \~chinese L4 角度最小值 \~english Minimum L4 angle value */
    int line_Vgroove_L4_angle_min = -30;
    /** @brief L4 角度最大值 \~chinese L4 角度最大值 \~english Maximum L4 angle value */
    int line_Vgroove_L4_angle_max = 30;
    /** @brief L4 长度最小值 \~chinese L4 长度最小值 \~english Minimum value of L4 length */
    double line_Vgroove_L4_length_min = 8.0;
    /** @brief L4 长度最大值 \~chinese L4 长度最大值 \~english Maximum value of L4 length */
    double line_Vgroove_L4_length_max = 200.0;
    /** @brief 投影至激光线 \~chinese 投影至激光线 \~english Project to laser line */
    bool line_Vgroove_project_to_laser = false;
    /** @brief 按比例偏移焊缝点 \~chinese 按比例偏移焊缝点 \~english Seam point offset by percentage */
    int line_Vgroove_seam_offset = 50;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线V型坡口算法参数更新 \~english @brief Line V-groove algorithm parameter update
 * \~chinese 直线V型坡口焊缝算法参数更新
 * \~english Line V-groove weld algorithm parameter update
 */
class AT_VISION_API LineVGrooveAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /**
     * @brief 焊缝位置 \~chinese 焊缝位置 \~english Weld position
     * \~chinese 取值应使用 LineVGrooveAlgoInfo::WeldPosition 枚举值
     * \~english Uses values from LineVGrooveAlgoInfo::WeldPosition
     */
    std::optional<int> line_Vgroove_weld_position;
    /** @brief 显示所有线 \~chinese 显示所有线 \~english Show all lines */
    std::optional<bool> line_Vgroove_show_all_lines;
    /** @brief 合并阈值 \~chinese 合并阈值 \~english Merge threshold */
    std::optional<double> line_Vgroove_merge_threshold;
    /** @brief 拟合阈值 \~chinese 拟合阈值 \~english Fit threshold */
    std::optional<double> line_Vgroove_fit_threshold;
    /** @brief 左板坡口角度(L2) \~chinese 左板坡口角度(L2) \~english left plate groove angle (L2) */
    std::optional<IntRange> line_Vgroove_L2_angle;
    /** @brief 左板坡口长度(L2) \~chinese 左板坡口长度(L2) \~english left plate groove length (L2) */
    std::optional<DoubleRange> line_Vgroove_L2_length;
    /** @brief 右板坡口角度(L3) \~chinese 右板坡口角度(L3) \~english right plate groove angle (L3) */
    std::optional<IntRange> line_Vgroove_L3_angle;
    /** @brief 右板坡口长度(L3) \~chinese 右板坡口长度(L3) \~english right plate groove length (L3) */
    std::optional<DoubleRange> line_Vgroove_L3_length;
    /** @brief 坡口宽度 \~chinese 坡口宽度 \~english groove width */
    std::optional<DoubleRange> line_Vgroove_weld_width;
    /** @brief 坡口深度 \~chinese 坡口深度 \~english groove depth */
    std::optional<DoubleRange> line_Vgroove_weld_height;
    /** @brief 坡口角度 \~chinese 坡口角度 \~english groove angle */
    std::optional<IntRange> line_Vgroove_angle;
    /** @brief L1 角度 \~chinese L1 角度 \~english L1 angle */
    std::optional<IntRange> line_Vgroove_L1_angle;
    /** @brief L1 长度 \~chinese L1 长度 \~english L1 length */
    std::optional<DoubleRange> line_Vgroove_L1_length;
    /** @brief L4 角度 \~chinese L4 角度 \~english L4 angle */
    std::optional<IntRange> line_Vgroove_L4_angle;
    /** @brief L4 长度 \~chinese L4 长度 \~english L4 length */
    std::optional<DoubleRange> line_Vgroove_L4_length;
    /** @brief 投影至激光线 \~chinese 投影至激光线 \~english Project to laser line */
    std::optional<bool> line_Vgroove_project_to_laser;
    /** @brief 按比例偏移焊缝点 \~chinese 按比例偏移焊缝点 \~english Seam point offset by percentage */
    std::optional<int> line_Vgroove_seam_offset;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线左搭接算法参数 \~english @brief Line left lap algorithm parameters
 */
class AT_VISION_API LineLeftLapAlgoInfo : public AlgoBaseInfo {
public:
    SeamType getSeamType() const override;

    /** \~chinese @brief 焊缝位置 \~english @brief Weld position */
    enum WeldPosition
    {
        /** \~chinese 上边缘。 \~english Upper edge. */
        UpperEdge = 0,
        /** \~chinese 下边缘。 \~english Lower edge. */
        LowerEdge = 1
    };

    /** \~chinese @brief 焊缝位置 \~english @brief Weld position */
    int line_left_lap_weld_position = 0;
    /** \~chinese @brief 显示所有线 \~english @brief Show all lines */
    bool line_left_lap_show_all_lines = false;
    /** \~chinese @brief 合并阈值 \~english @brief Merge threshold */
    double line_left_lap_merge_threshold = 1.0;
    /** \~chinese @brief 拟合阈值 \~english @brief Fit threshold */
    double line_left_lap_fit_threshold = 1.0;
    /** \~chinese @brief L1角度最小值 \~english @brief Minimum L1 angle value */
    int line_left_lap_L1_angle_min = -30;
    /** \~chinese @brief L1角度最大值 \~english @brief Maximum L1 angle value */
    int line_left_lap_L1_angle_max = 30;
    /** \~chinese @brief L1最小值长度 \~english @brief Minimum value of L1 length */
    double line_left_lap_L1_length_min = 5.0;
    /** \~chinese @brief L2角度最小值 \~english @brief Minimum L2 angle value */
    int line_left_lap_L2_angle_min = -30;
    /** \~chinese @brief L2角度最大值 \~english @brief Maximum L2 angle value */
    int line_left_lap_L2_angle_max = 30;
    /** \~chinese @brief L2最小值长度 \~english @brief Minimum value of L2 length */
    double line_left_lap_L2_length_min = 5.0;
    /** \~chinese @brief 焊缝间隙最小值 \~english @brief Minimum value of weld gap */
    double line_left_lap_weld_width_min = 0.0;
    /** \~chinese @brief 焊缝间隙最大值 \~english @brief Maximum value of weld gap */
    double line_left_lap_weld_width_max = 30.0;
    /** \~chinese @brief 焊缝错边最小值 \~english @brief Minimum value of weld misalignment */
    double line_left_lap_weld_height_min = 2.0;
    /** \~chinese @brief 焊缝错边最大值 \~english @brief Maximum value of weld misalignment */
    double line_left_lap_weld_height_max = 20.0;
    /** \~chinese @brief 搭接角度 \~english @brief Lap angle */
    int line_left_lap_angle = 90;
    /** \~chinese @brief L1最大值长度 \~english @brief Maximum value of L1 length */
    double line_left_lap_L1_length_max = 200.0;
    /** \~chinese @brief L2最大值长度 \~english @brief Maximum value of L2 length */
    double line_left_lap_L2_length_max = 200.0;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};

/**
 * \~chinese @brief 直线左搭接算法参数更新 \~english @brief Line left lap algorithm parameter update
 */
class AT_VISION_API LineLeftLapAlgoInfoUpdate : public AlgoBaseInfoUpdate {
public:
    SeamType getSeamType() const override;

    /** \~chinese @brief 焊缝位置 \~english @brief Weld position */
    std::optional<int> line_left_lap_weld_position;
    /** \~chinese @brief 显示所有线 \~english @brief Show all lines */
    std::optional<bool> line_left_lap_show_all_lines;
    /** \~chinese @brief 合并阈值 \~english @brief Merge threshold */
    std::optional<double> line_left_lap_merge_threshold;
    /** \~chinese @brief 拟合阈值 \~english @brief Fit threshold */
    std::optional<double> line_left_lap_fit_threshold;
    /** \~chinese @brief L1角度 \~english @brief L1 angle */
    std::optional<IntRange> line_left_lap_L1_angle;
    /** \~chinese @brief L1长度 \~english @brief L1 length */
    std::optional<DoubleRange> line_left_lap_L1_length;
    /** \~chinese @brief L2角度 \~english @brief L2 angle */
    std::optional<IntRange> line_left_lap_L2_angle;
    /** \~chinese @brief L2长度 \~english @brief L2 length */
    std::optional<DoubleRange> line_left_lap_L2_length;
    /** \~chinese @brief 焊缝间隙 \~english @brief weld gap */
    std::optional<DoubleRange> line_left_lap_weld_width;
    /** \~chinese @brief 焊缝错边 \~english @brief weld misalignment */
    std::optional<DoubleRange> line_left_lap_weld_height;
    /** \~chinese @brief 搭接角度 \~english @brief Lap angle */
    std::optional<int> line_left_lap_angle;

    std::error_code serialize(std::string& out) const override;
    std::error_code deserialize(const std::string& jsonStr) override;
};
} // namespace at_vision

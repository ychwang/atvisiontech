// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

#pragma once

// SDK 版本号宏定义（编译时）
#define AT_VISION_VERSION_MAJOR 4
#define AT_VISION_VERSION_MINOR 3
#define AT_VISION_VERSION_PATCH 1
#define AT_VISION_VERSION_STR "4.3.1"
#define AT_VISION_VERSION_STRING AT_VISION_VERSION_STR

// SDK 版本号辅助宏
#define AT_VISION_VERSION_ENCODE(major, minor, patch) \
    (((major) * 10000) + ((minor) * 100) + (patch))

// 当前 SDK 版本号（编码后的整数形式）
#define AT_VISION_VERSION \
    AT_VISION_VERSION_ENCODE(AT_VISION_VERSION_MAJOR, AT_VISION_VERSION_MINOR, AT_VISION_VERSION_PATCH)

// 检查当前 SDK 版本号是否大于等于指定版本
#define AT_VISION_VERSION_CHECK(major, minor, patch) \
    (AT_VISION_VERSION >= AT_VISION_VERSION_ENCODE(major, minor, patch))

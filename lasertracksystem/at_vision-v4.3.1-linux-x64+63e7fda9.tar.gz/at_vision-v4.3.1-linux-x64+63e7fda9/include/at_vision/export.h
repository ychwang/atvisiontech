// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

#pragma once

#if defined(_WIN32) || defined(_WIN64)
#define AT_VISION_DECL_EXPORT __declspec(dllexport)
#define AT_VISION_DECL_IMPORT __declspec(dllimport)
#elif defined(__GNUC__) && __GNUC__ >= 4
#define AT_VISION_DECL_EXPORT __attribute__((visibility("default")))
#define AT_VISION_DECL_IMPORT __attribute__((visibility("default")))
#else
#define AT_VISION_DECL_EXPORT
#define AT_VISION_DECL_IMPORT
#endif

#ifndef BUILD_STATIC
#if defined(AT_VISION_LIB)
#define AT_VISION_API AT_VISION_DECL_EXPORT
#else
#define AT_VISION_API AT_VISION_DECL_IMPORT
#endif
#else
#define AT_VISION_API
#endif

// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/**
 * @file vision_core.h
 * \~chinese @brief SDK 核心接口与工厂函数 \~english @brief SDK core interfaces and factory functions
 *
 * \~chinese @mainpage AT Vision SDK 文档总览
 * \~english @mainpage AT Vision SDK Documentation Overview
 *
 * \~chinese @section sdk_entry_section 总入口说明
 * \~english @section sdk_entry_section Main Entry
 * \~chinese SDK 的总入口是 IRpcClient 接口。 \~english The main SDK entry point is the IRpcClient interface.
 * \~chinese `createVision()` 只是用于创建 IRpcClient 实例的工厂函数。 \~english `createVision()` is a factory function for creating an IRpcClient
 * instance.
 *
 * \~chinese 典型使用顺序如下： \~english Typical usage order:
 * \~chinese - 声明 std::error_code ec 并调用 discoverSensors(ec) 搜索局域网中的传感器 \~english - Declare std::error_code ec and call
 * discoverSensors(ec) to discover sensors on the LAN
 * \~chinese - 调用 createVision() 创建 IRpcClient 实例 \~english - Call createVision() to create an IRpcClient instance
 * \~chinese - 调用 connect() 连接目标传感器 \~english - Call connect() to connect to the target sensor
 * \~chinese - 通过 getSettings()、getAlgorithmInterface()、getHandEyeCalibration() 获取功能接口 \~english - Use getSettings(),
 * getAlgorithmInterface(), and getHandEyeCalibration() to get feature interfaces
 *
 * \~chinese @section sdk_example_section 示例导航
 * \~english @section sdk_example_section Example Navigation
 * \~chinese 下列示例会出现在 Doxygen 的示例页面中： \~english The following examples appear on the Doxygen examples page:
 * @example quick_start.cpp
 * @example discover_sensors_example.cpp
 * @example algorithm_interface_example.cpp
 * @example hand_eye_calibration_example.cpp
 */

#pragma once

#include "at_vision/aotai_tcp_channel.h"
#include "at_vision/export.h"
#include "at_vision/type_def.h"
#include "at_vision/setting_interface.h"
#include "at_vision/algorithm_interface.h"
#include "at_vision/hand_eye_calibration_interface.h"
#include <functional>
#include <memory>
#include <string>
#include <system_error>
#include <vector>

namespace at_vision {

/**
 * \~chinese @brief 事件回调函数类型 \~english @brief Event callback function type
 *
 * \~chinese 当 SDK 内部发生事件时（连接断开、心跳超时、传感器错误等）， \~english Called when SDK internal events occur, such as disconnection,
 * heartbeat timeout, or sensor error,
 * \~chinese 会调用此回调函数通知用户 \~english this callback is invoked to notify the user
 *
 * \~chinese @param event 事件对象，包含事件类型、消息、时间戳和附加数据 \~english @param event Event object containing type, message, timestamp, and
 * extra data
 */
using EventCallback = std::function<void(const Event& event)>;

/**
 * \~chinese @brief 图像数据回调函数类型 \~english @brief Image data callback function type
 *
 * \~chinese 当传感器通过 UDP 发送图像数据时（端口 8080），会调用此回调函数通知用户 \~english Called to notify the user when the sensor sends image
 * data over UDP port 8080
 *
 * \~chinese @param image 图像数据对象，包含图像缓冲区、宽高、格式类型等信息 \~english @param image Image data object containing the image buffer,
 * size, and format type
 */
using ImageCallback = std::function<void(const Image& image)>;

/**
 * \~chinese @brief 激光焊缝结果数据回调函数类型 \~english @brief Laser seam result callback function type
 *
 * \~chinese 当传感器通过 UDP 发送激光焊缝结果数据时（UV 数据包，端口 8080）， \~english Called when the sensor sends laser seam result data over UDP
 * port 8080 using UV packets,
 * \~chinese 会调用此回调函数通知用户 \~english this callback is invoked to notify the user
 *
 * \~chinese @param result 激光焊缝结果数据对象，包含焊缝点、激光线、错误信息等 \~english @param result Laser seam result object containing seam
 * points, laser lines, and error information
 */
using LaserSeamResultCallback = std::function<void(const LaserSeamResult& result)>;

/**
 * \~chinese @brief SDK 总入口接口 \~english @brief Main SDK entry interface
 *
 * \~chinese 提供视觉处理的核心功能接口，包括连接传感器、注册回调以及获取各功能子接口。 \~english Provides core vision-processing APIs, including
 * sensor connection, callback registration, and access to feature interfaces.
 */
class AT_VISION_API IRpcClient {
public:
    virtual ~IRpcClient() = default;

    /**
     * \~chinese @brief 连接到指定传感器 \~english @brief Connects to the specified sensor
     * \~chinese @param sensor 搜索到的传感器信息对象 \~english @param sensor Discovered sensor information object
     * \~chinese @return 错误码，成功返回 ErrorCode::Ok，失败返回具体错误类型 \~english @return Error code; ErrorCode::Ok indicates success, otherwise
     * a specific error is returned
     * \~chinese @note 可能返回的错误码： \~english @note Possible error codes:
     *       \~chinese - ExceptionVersionCheck: SDK 与传感器版本不匹配（主次版本号必须一致） \~english - ExceptionVersionCheck: SDK and sensor
     * versions are incompatible; major and minor versions must match
     *       \~chinese - NetworkError: 网络连接失败 \~english - NetworkError: network connection failed
     *       \~chinese - OperationFailed: 其他操作失败 \~english - OperationFailed: another operation failed
     */
    virtual std::error_code connect(const SensorInfo& sensor) = 0;

    /**
     * \~chinese @brief 获取 SDK 版本号 \~english @brief Gets the SDK version
     * \~chinese @return SDK 版本字符串 \~english @return SDK version string
     */
    virtual std::string getVersion() const = 0;

    /**
     * \~chinese @brief 获取连接握手阶段返回的初始化缓存（只读快照） \~english @brief Gets the initialization cache returned during connection
     * handshake as a read-only snapshot
     *
     * \~chinese 该接口返回 connect() 握手成功后缓存的初始化响应，以及后续 \~english Returns the cached initialization response after a successful
     * connect() handshake and later
     * \~chinese SDK 内部 updateInitialization() 更新后的最新数据快照。 \~english the latest data snapshot updated internally by
     * updateInitialization().
     *
     * \~chinese @param[out] json 初始化缓存的 JSON 字符串 \~english @param[out] json JSON string of the initialization cache
     * \~chinese @return 错误码，成功返回空 error_code；若尚未建立连接或无缓存返回 NotInitialized \~english @return Error code; empty error_code
     * indicates success; NotInitialized is returned if not connected or no cache exists
     */
    virtual std::error_code getInitializationCache(std::string& json) const = 0;

    /**
     * \~chinese @brief 设置 RPC 默认超时时间 \~english @brief Sets the default RPC timeout
     *
     * \~chinese 该超时时间会作为 SDK 内部同步 RPC 请求的默认等待时间， \~english This timeout is used as the default wait time for synchronous RPC
     * requests inside the SDK,
     * \~chinese 适用于设置接口、算法接口、标定接口等未显式指定超时的调用。 \~english including settings, algorithm, and calibration calls that do not
     * specify an explicit timeout.
     * \~chinese 心跳等内部保活请求仍可使用独立超时策略。 \~english Internal keepalive requests such as heartbeat may still use independent timeout
     * policies.
     *
     * \~chinese @param timeoutMs 超时时间，单位毫秒，必须大于 0 \~english @param timeoutMs Timeout in milliseconds; must be greater than 0
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     *
     * \~chinese @note 建议在 connect() 前设置，连接后修改也会影响后续 RPC 调用 \~english @note Set this before connect(); changes after connection
     * also affect later RPC calls
     */
    virtual std::error_code setRpcTimeout(int timeoutMs) = 0;

    /**
     * \~chinese @brief 获取当前 RPC 默认超时时间 \~english @brief Gets the current default RPC timeout
     * \~chinese @return 当前默认超时时间，单位毫秒 \~english @return Current default timeout in milliseconds
     */
    virtual int getRpcTimeout() const = 0;

    /**
     * \~chinese @brief 设置事件回调函数 \~english @brief Sets the event callback function
     *
     * \~chinese 用户可以通过此方法注册回调函数，订阅 SDK 内部事件（连接断开、 \~english Registers a callback to subscribe to SDK internal events such
     * as disconnection,
     * \~chinese 心跳超时、传感器错误、相机掉线等）。回调函数会在事件发生时被调用。 \~english heartbeat timeout, sensor errors, or camera offline
     * events; the callback is invoked when an event occurs.
     *
     * \~chinese @param callback 事件回调函数 \~english @param callback Event callback function
     *
     * \~chinese @note 回调函数可能在内部线程（接收线程、心跳线程）中被调用， \~english @note The callback may be invoked from internal threads such
     * as receiving or heartbeat threads,
     *       \~chinese 用户需确保回调函数线程安全 \~english so the user must ensure the callback is thread-safe
     * \~chinese @note 多次调用会覆盖之前设置的回调函数 \~english @note Calling this multiple times overwrites the previously set callback
     * \~chinese @note 使用 clearEventCallback() 可以取消订阅 \~english @note Use clearEventCallback() to unsubscribe
     *
     * @code
     * client->setEventCallback([](const Event& event) {
     *     std::cout << "Event: " << static_cast<int>(event.type)
     *               << ", Message: " << event.message << std::endl;
     * });
     * @endcode
     */
    virtual void setEventCallback(EventCallback callback) = 0;

    /**
     * \~chinese @brief 设置自动重连配置 \~english @brief Sets the auto-reconnect configuration
     *
     * \~chinese @param config 自动重连配置 \~english @param config Auto-reconnect configuration
     *
     * \~chinese @note 必须在 connect() 之前或连接断开后调用 \~english @note Must be called before connect() or after disconnection
     * \~chinese @note 重连会在连接断开（ConnectionError、HeartbeatTimeout）时自动触发 \~english @note Reconnect is triggered automatically after
     * disconnection events such as ConnectionError or HeartbeatTimeout
     *
     * @code
     * ReconnectConfig config;
     * config.enabled = true;          // Enable auto reconnect
     * config.maxAttempts = 5;        // Reconnect up to 5 times
     * config.intervalMs = 3000;      // Use a 3-second interval
     * config.backoffEnabled = true;  // Enable exponential backoff
     * client->setReconnectConfig(config);
     * @endcode
     */
    virtual void setReconnectConfig(const ReconnectConfig& config) = 0;

    /**
     * \~chinese @brief 获取当前自动重连配置 \~english @brief Gets the current auto-reconnect configuration
     * \~chinese @return 当前的自动重连配置 \~english @return Current auto-reconnect configuration
     */
    virtual ReconnectConfig getReconnectConfig() const = 0;

    /**
     * \~chinese @brief 设置心跳检测配置 \~english @brief Sets the heartbeat detection configuration
     * \~chinese @param config 心跳检测配置，所有数值必须大于 0 \~english @param config Heartbeat configuration; all numeric values must be greater
     * than 0
     * \~chinese @return 错误码，成功返回空 error_code \~english @return Error code; empty error_code indicates success
     * \~chinese @note 默认配置为 3 秒发送一次心跳、单次超时 2 秒、连续失败 3 次后判定断线 \~english @note Defaults are a 3-second interval,
     * 2-second timeout, and 3 consecutive failures before disconnect
     * \~chinese @note 连接后修改会影响后续心跳检测，但不会中断已经在等待的那次心跳 RPC \~english @note Changes after connection affect
     * later heartbeat checks, but do not interrupt an already waiting heartbeat RPC
     */
    virtual std::error_code setHeartbeatConfig(const HeartbeatConfig& config) = 0;

    /**
     * \~chinese @brief 获取当前心跳检测配置 \~english @brief Gets the current heartbeat detection configuration
     * \~chinese @return 当前心跳检测配置 \~english @return Current heartbeat detection configuration
     */
    virtual HeartbeatConfig getHeartbeatConfig() const = 0;

    /**
     * \~chinese @brief 获取设置接口 \~english @brief Gets the settings interface
     *
     * \~chinese 通过设置接口可以配置传感器的运行时参数，包括图像传输质量、 \~english The settings interface configures sensor runtime parameters,
     * including image transfer quality,
     * \~chinese 传输模式以及串口号（仅 WINDOWS_X64 平台）等 \~english transfer mode, and serial port number on WINDOWS_X64 only
     *
     * \~chinese @return 设置接口智能指针 \~english @return Smart pointer to the settings interface
     *
     * \~chinese @note 返回的接口实例与 IRpcClient 共享相同生命周期 \~english @note The returned interface instance shares the same lifetime as
     * IRpcClient
     * \~chinese @note 需要在 connect() 成功后调用设置方法 \~english @note Call settings methods after connect() succeeds
     *
     * @code
     * auto client = createVision();
     * client->connect(sensor);
     *
     * auto settings = client->getSettings();
     * settings->setImageQuality(ImageQuality::Original);
     * settings->setImageTransferMode(ImageTransferMode::Both);
     *
     * if (sensor.platform == "WINDOWS_X64") {
     *     settings->setSerialPort("COM3");
     * }
     * @endcode
     */
    virtual std::shared_ptr<ISettings> getSettings() = 0;

    /**
     * \~chinese @brief 获取手眼标定接口 \~english @brief Gets the hand-eye calibration interface
     *
     * \~chinese 通过手眼标定接口可以提交一组标定输入数据， \~english The hand-eye calibration interface submits a set of calibration input data
     * \~chinese 并获取对应的标定结果数据。 \~english and returns the corresponding calibration result data.
     *
     * \~chinese @return 手眼标定接口智能指针 \~english @return Smart pointer to the hand-eye calibration interface
     *
     * \~chinese @note 返回的接口实例与 IRpcClient 共享相同生命周期 \~english @note The returned interface instance shares the same lifetime as
     * IRpcClient
     * \~chinese @note 需要在 connect() 成功后调用标定方法 \~english @note Call calibration methods after connect() succeeds
     */
    virtual std::shared_ptr<IHandEyeCalibration> getHandEyeCalibration() = 0;

    /**
     * \~chinese @brief 获取算法控制接口 \~english @brief Gets the algorithm control interface
     *
     * \~chinese 通过算法控制接口可以管理 Process（工艺库）和 Job（任务）， \~english The algorithm control interface manages Process libraries and
     * Jobs,
     * \~chinese 包括切换、查询、参数管理以及激光控制等功能 \~english including switching, querying, parameter management, and laser control
     *
     * \~chinese @return 算法控制接口智能指针 \~english @return Smart pointer to the algorithm control interface
     *
     * \~chinese @note 返回的接口实例与 IRpcClient 共享相同生命周期 \~english @note The returned interface instance shares the same lifetime as
     * IRpcClient
     * \~chinese @note 需要在 connect() 成功后调用 \~english @note Call after connect() succeeds
     *
     * @code
     * auto client = createVision();
     * client->connect(sensor);
     *
     * auto algorithm = client->getAlgorithmInterface();
     *
     * // Switch Process and Job
     * algorithm->switchProcess(1);
     * algorithm->switchJob(5);
     *
     * // Control the laser
     * algorithm->setLaserEnabled(5, true);
     *
     * // Querylist
     * std::error_code ec;
     * auto processes = algorithm->getProcessList(ec);
     * if (ec) { return; }
     * auto jobs = algorithm->getJobList();
     * @endcode
     */
    virtual std::shared_ptr<IAlgorithm> getAlgorithmInterface() = 0;

    /**
     * \~chinese @brief 设置图像数据回调函数 \~english @brief Sets the image data callback function
     *
     * \~chinese 用户可以通过此方法注册回调函数，订阅传感器通过 UDP 发送的图像数据。 \~english Registers a callback to subscribe to image data sent by
     * the sensor over UDP.
     * \~chinese 图像接收器会在 connect() 成功后自动启动监听 UDP 端口 8080， \~english The image receiver automatically starts listening on UDP port
     * 8080 after connect() succeeds,
     * \~chinese 在 reset()/disconnect() 时自动停止。 \~english and stops automatically during reset() or disconnect().
     *
     * \~chinese @param callback 图像数据回调函数 \~english @param callback Image data callback function
     *
     * \~chinese @note 回调函数会在图像接收线程中被调用，用户需确保回调函数线程安全 \~english @note The callback is invoked on the image receiving
     * thread; the user must ensure it is thread-safe
     * \~chinese @note 多次调用会覆盖之前设置的回调函数 \~english @note Calling this multiple times overwrites the previously set callback
     * \~chinese @note 图像接收器的生命周期由 SDK 自动管理，用户无需手动启动/停止 \~english @note The image receiver lifetime is managed by the SDK;
     * users do not need to start or stop it manually
     *
     * @code
     * auto client = createVision();
     *
     * // Set image callback
     * client->setImageCallback([](const Image& image) {
     *     std::cout << "Received image: " << image.width << "x" << image.height
     *               << ", type=" << static_cast<int>(image.type)
     *               << ", data_size=" << image.data.size() << std::endl;
     *
     *     // Save or process image data
     *     // cv::Mat mat(image.height, image.width, CV_8UC1, (void*)image.data.data());
     * });
     *
     * // Connect to the sensor; this automatically starts the image receiver
     * client->connect(sensor);
     * @endcode
     */
    virtual void setImageCallback(ImageCallback callback) = 0;

    /**
     * \~chinese @brief 设置激光焊缝结果数据回调函数 \~english @brief Sets the laser seam result callback function
     *
     * \~chinese 用户可以通过此方法注册回调函数，订阅传感器通过 UDP 发送的激光焊缝结果数据。 \~english Registers a callback to subscribe to laser seam
     * result data sent by the sensor over UDP.
     * \~chinese 数据接收器会在 connect() 成功后自动启动监听 UDP 端口 8080， \~english The data receiver automatically starts listening on UDP port
     * 8080 after connect() succeeds,
     * \~chinese 在 reset()/disconnect() 时自动停止。 \~english and stops automatically during reset() or disconnect().
     *
     * \~chinese @param callback 激光焊缝结果数据回调函数 \~english @param callback Laser seam result callback function
     *
     * \~chinese @note 回调函数会在数据接收线程中被调用，用户需确保回调函数线程安全 \~english @note The callback is invoked on the data receiving
     * thread; the user must ensure it is thread-safe
     * \~chinese @note 多次调用会覆盖之前设置的回调函数 \~english @note Calling this multiple times overwrites the previously set callback
     * \~chinese @note 数据接收器的生命周期由 SDK 自动管理，用户无需手动启动/停止 \~english @note The data receiver lifetime is managed by the SDK;
     * users do not need to start or stop it manually
     *
     * @code
     * auto client = createVision();
     *
     * // Set laser seam result callback
     * client->setLaserSeamResultCallback([](const LaserSeamResult& result) {
     *     std::cout << "Received laser seam result: seam_point=("
     *               << result.seam_point.x << ", " << result.seam_point.y << ")"
     *               << ", error_code=" << result.error_code << std::endl;
     *
     *     // Process weld result data
     * });
     *
     * // Connect to the sensor; this automatically starts the data receiver
     * client->connect(sensor);
     * @endcode
     */
    virtual void setLaserSeamResultCallback(LaserSeamResultCallback callback) = 0;

    /**
     * \~chinese @brief 获取当前传感器的 AoTai TCP 常驻通道
     * \~english @brief Gets the persistent AoTai TCP channel for the current
     * sensor
     * \~chinese @return 通道接口；主连接断开或切换传感器时 SDK 会停止其数据流
     * \~english @return Channel interface whose stream is stopped by
     * the SDK
     * when the main connection closes or changes sensor
     * \~chinese @note 通道需要显式调用 startStream()，不会随 connect()
     * 自动开启
     * \~english @note Call startStream()
     * explicitly; connect() does not start this channel
     */
    virtual std::shared_ptr<IAoTaiTcpChannel> getAoTaiTcpChannel() = 0;
};

/**
 * @anchor sdk_factory_entry
 * \~chinese @brief 创建 IRpcClient 实例的工厂函数 \~english @brief Factory function that creates an IRpcClient instance
 * \~chinese @return IRpcClient 智能指针 \~english @return IRpcClient smart pointer
 *
 * \~chinese @note 该函数用于创建 SDK 的总入口接口 IRpcClient 实例。 \~english @note This function creates an IRpcClient instance as the main SDK
 * entry interface.
 */
AT_VISION_API std::unique_ptr<IRpcClient> createVision();

/**
 * @anchor sdk_discover_entry
 * \~chinese @brief 搜索局域网中的传感器（带错误码输出） \~english @brief Discovers sensors on the LAN with error-code output
 * \~chinese @param[out] ec 错误码输出，成功时为空 error_code \~english @param[out] ec Error-code output; empty error_code indicates success
 * \~chinese @param timeout_ms 搜索超时时间（毫秒，默认 3 秒） \~english @param timeout_ms Discovery timeout in milliseconds; default is 3 seconds
 * \~chinese @return 搜索到的传感器列表 \~english @return List of discovered sensors
 *
 * \~chinese @note 当端口占用或网络异常时，返回空列表并通过 ec 提供错误原因 \~english @note When the port is occupied or the network fails, returns an
 * empty list and reports the reason through ec
 */
AT_VISION_API std::vector<SensorInfo> discoverSensors(std::error_code& ec, int timeout_ms = 3000);

/**
 * \~chinese @brief 修改传感器的 IP 地址（通过广播实现，无需连接） \~english @brief Changes the sensor IP address by broadcast without connecting
 *
 * \~chinese @param sensor 目标传感器信息（必须包含 sensorId、sensorIp、macAddress 和 platform） \~english @param sensor Target sensor information;
 * must include sensorId, sensorIp, macAddress, and platform
 * \~chinese @param newIp 新的 IP 地址（IPv4 格式，且不能为
 * 127.x.x.x、169.254.x.x、0.x.x.x、224.0.0.0 及以上） \~english @param newIp New IPv4 address; 127.x.x.x, 169.254.x.x, 0.x.x.x, and 224.0.0.0+ are
 * not allowed
 * \~chinese @param timeout_ms 等待设备返回 `setSensorIp` 响应的超时时间，单位毫秒；当 `timeout_ms <= 0` 时不等待响应 \~english @param timeout_ms
 * Timeout in milliseconds for waiting for the setSensorIp response; no response is waited for when timeout_ms <= 0
 * \~chinese @return 错误码；当 `timeout_ms > 0` 时，Success 表示已收到设备返回的 `setSensorIp` 响应； \~english @return Error code; when timeout_ms >
 * 0, Success means the setSensorIp response was received from the device;
 *         \~chinese 当 `timeout_ms <= 0` 时，Success 仅表示广播命令已成功发送 \~english When timeout_ms <= 0, Success only means the broadcast
 * command was sent successfully
 *
 * \~chinese @note 仅支持非 WINDOWS_X64 平台的传感器 \~english @note Only sensors on non-WINDOWS_X64 platforms are supported
 * \~chinese @note
 * 使用广播方式发送命令到端口 15556，传感器通过 sensorId 和 macAddress 识别自己 \~english @note Sends commands by broadcast to port 15556; the sensor
 * identifies itself by sensorId and macAddress
 * \~chinese @note 修改后传感器会自动应用新 IP，无需重启 \~english @note After modification, the sensor applies the new IP automatically without
 * rebooting
 * \~chinese @note 修改 IP 后需要使用新 IP 重新搜索和连接传感器 \~english @note After changing the IP, rediscover and reconnect to the sensor using
 * the new IP
 * \~chinese @note 不支持修改子网掩码和网关（如需修改请使用传感器的 Web 界面） \~english @note Subnet mask and gateway changes are not supported; use
 * the sensor Web UI if needed
 * \~chinese @note 当 `timeout_ms > 0` 时，发送命令后会等待设备返回 `setSensorIp` 响应，超时则返回 TimeoutError \~english @note When timeout_ms > 0,
 * the call waits for the setSensorIp response after sending the command; TimeoutError is returned on timeout
 * \~chinese @note 当 `timeout_ms <= 0` 时，不等待设备响应，返回 Success 仅表示广播命令已发送 \~english @note When timeout_ms <= 0, no device response
 * is waited for and Success only means the broadcast command was sent
 * \~chinese @note 无论是否等待响应，是否已完全切换到新 IP，仍建议后续重新搜索确认 \~english @note Whether or not a response is waited for,
 * rediscovery is still recommended to confirm the new IP
 *
 * @code
 * std::error_code discover_ec;
 * auto sensors = discoverSensors(discover_ec);
 * if (!sensors.empty() && sensors[0].platform != "WINDOWS_X64") {
 *     auto ec = configureSensorNetwork(sensors[0], "192.168.1.100");
 *     if (!ec) {
 *         std::cout << "IP address update command sent successfully" << std::endl;
 *         // Wait for the sensor to apply the new IP, about 1 to 2 seconds
 *         std::this_thread::sleep_for(std::chrono::seconds(2));
 *         // Rediscover using the new IP
 *         std::error_code rediscover_ec;
 *         auto new_sensors = discoverSensors(rediscover_ec);
 *     } else {
 *         std::cerr << "Failed: " << ec.message() << std::endl;
 *     }
 * }
 * @endcode
 */
AT_VISION_API std::error_code configureSensorNetwork(const SensorInfo& sensor, const std::string& newIp, int timeout_ms = 300);

/**
 * \~chinese @brief 重启传感器（通过广播实现，无需连接） \~english @brief Reboots the sensor by broadcast without connecting
 *
 * \~chinese @param sensor 目标传感器信息（必须包含 sensorId、sensorIp 和 macAddress） \~english @param sensor Target sensor information; must include
 * sensorId, sensorIp, and macAddress
 * \~chinese @return 错误码（SensorConfigError::Success 表示命令已成功发送） \~english @return Error code;
 * SensorConfigError::Success means the command was sent successfully
 *
 * \~chinese @note 支持所有传感器平台，包括 WINDOWS_X64 \~english @note Supports all sensor platforms, including WINDOWS_X64
 * \~chinese @note
 * 使用广播方式发送命令到端口 15556，传感器通过 sensorId、sensorIp 和 macAddress 识别自己 \~english @note Sends commands by broadcast to port 15556;
 * the sensor identifies itself by sensorId, sensorIp, and macAddress
 * \~chinese @note 传感器收到命令后会立即重启 \~english @note The sensor reboots immediately after receiving the command
 * \~chinese @note 重启后传感器需要约 30-60 秒才能完全启动 \~english @note After reboot, the sensor needs about 30 to 60 seconds to start completely
 * \~chinese @note 重启期间无法连接传感器 \~english @note The sensor cannot be connected during reboot
 * \~chinese @note 返回 Success 仅表示广播命令已发送，不代表传感器已成功重启（因为不等待响应） \~english @note Success only means the broadcast
 * command was sent, not that the sensor rebooted successfully, because no response is waited for
 *
 * @code
 * std::error_code discover_ec;
 * auto sensors = discoverSensors(discover_ec);
 * if (!sensors.empty()) {
 *     auto ec = rebootSensor(sensors[0]);
 *     if (!ec) {
 *         std::cout << "Sensor reboot command sent successfully" << std::endl;
 *         std::this_thread::sleep_for(std::chrono::seconds(60)); // Wait for reboot to complete
 *
 *         // Rediscover sensors
 *         std::error_code rediscover_ec;
 *         auto new_sensors = discoverSensors(rediscover_ec);
 *     } else {
 *         std::cerr << "Failed: " << ec.message() << std::endl;
 *     }
 * }
 * @endcode
 */
AT_VISION_API std::error_code rebootSensor(const SensorInfo& sensor);

} // namespace at_vision

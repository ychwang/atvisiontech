// Copyright 2020 Shandong Aotai Electric Co., Ltd. All rights reserved.
//
// This source code is proprietary and confidential. Unauthorized copying,
// modification, distribution, or use of this file, in whole or in part, is
// strictly prohibited without prior written permission from Shandong Aotai
// Electric Co., Ltd.

/** @file  error.h
 *  \~chinese @brief 错误处理系统定义 \~english @brief error handling system definitions
 */

#pragma once

#include "at_vision/export.h"
#include <string>
#include <system_error>

namespace at_vision {

/**
 * \~chinese @brief at_vision 错误码枚举 \~english at_vision error code enumeration
 * \~chinese @details 定义了 SDK 中所有可能的错误类型 \~english Defines all possible error types in the SDK
 * \~english @brief Error code enumeration for at_vision
 * \~english @details Defines all possible error types in the SDK
 */
enum class ErrorCode : uint32_t
{
    /* General error codes, range: 0x80000000-0x800000FF / 通用错误码，范围为 0x80000000-0x800000FF */
    Ok = 0,                             ///< \~chinese 成功，无错误 \~english Success, no error
    NotConnected = 0x80000001,          ///< \~chinese 未连接到传感器 \~english Not connected to sensor
    ExceptionVersionCheck = 0x80000002, ///< \~chinese SDK与服务版本不匹配 \~english SDK and service version mismatch
    InvalidParameter = 0x80000003,      ///< \~chinese 无效参数 \~english Invalid parameter
    NotInitialized = 0x80000004,        ///< \~chinese 未初始化 \~english Not initialized
    AlreadyInitialized = 0x80000005,    ///< \~chinese 已经初始化 \~english Already initialized
    OperationFailed = 0x80000006,       ///< \~chinese 操作失败 \~english Operation failed
    TimeoutError = 0x80000007,          ///< \~chinese 超时错误 \~english Timeout error
    NetworkError = 0x80000008,          ///< \~chinese 网络错误 \~english Network error
    FileNotFound = 0x80000009,          ///< \~chinese 文件未找到 \~english File not found
    PermissionDenied = 0x8000000A,      ///< \~chinese 权限拒绝 \~english Permission denied
    OutOfMemory = 0x8000000B,           ///< \~chinese 内存不足 \~english Out of memory
    InvalidState = 0x8000000C,          ///< \~chinese 无效状态 \~english Invalid state
    NotSupported = 0x8000000D,          ///< \~chinese 不支持的操作 \~english Operation not supported
    AlreadyExists = 0x8000000E,         ///< \~chinese 资源已存在 \~english Resource already exists
    NotFound = 0x8000000F,              ///< \~chinese 资源不存在 \~english Resource not found

    /* Algorithm error codes, range: 0x10000000-0x1000FFFF / 算法错误码，范围为 0x10000000-0x1000FFFF */
    AlgoParamOutOfRange = 0x10000001,               ///< \~chinese 算法参数超出范围 \~english Algorithm parameter out of range
    AlgoPointNotFound = 0x10000002,                 ///< \~chinese 找点失败 \~english Point detection failed
    AlgoInvalidImage = 0x10000003,                  ///< \~chinese 无效图像数据 \~english Invalid image data
    AlgoProcessingFailed = 0x10000004,              ///< \~chinese 算法处理失败 \~english Algorithm processing failed
    AlgoCalibrationFailed = 0x10000005,             ///< \~chinese 标定失败 \~english Calibration failed
    AlgoFeatureNotDetected = 0x10000006,            ///< \~chinese 特征未检测到 \~english Feature not detected
    AlgoInsufficientData = 0x10000007,              ///< \~chinese 数据不足 \~english Insufficient data
    AlgoSensorTypeMismatch = 0x10000008,            ///< \~chinese 传感器类型不匹配 \~english Sensor type mismatch
    AlgoTemplatePointDistanceTooSmall = 0x10000009, ///< \~chinese 模板特征点间距过小 \~english Template feature point distance too small
    JobImportVersionMismatch =
        0x1000000A, ///< \~chinese Job 导入文件与当前传感器版本不匹配 \~english Job import file does not match the current sensor version

    /* Sensor configuration error codes, range: 0x20000000-0x2000FFFF / 传感器配置错误码，范围为 0x20000000-0x2000FFFF */
    SensorPlatformNotSupported = 0x20000001, ///< \~chinese 平台不支持（WINDOWS_X64 不支持网络配置）\~english Platform not supported (WINDOWS_X64
                                             ///< does not support network configuration)
    SensorInvalidInfo = 0x20000002,       ///< \~chinese 传感器信息无效（缺少必要字段）\~english Invalid sensor information (missing required fields)
    SensorInvalidIpAddress = 0x20000003,  ///< \~chinese IP地址格式错误 \~english Invalid IP address format
    SensorNoActiveInterface = 0x20000004, ///< \~chinese 没有活动的网络接口 \~english No active network interface available
    SensorBroadcastFailed = 0x20000005,   ///< \~chinese 广播发送失败 \~english Broadcast failed
    SensorIpStartsWith127 = 0x20000006,   ///< \~chinese 传感器IP不能以127开头 \~english Sensor IP cannot start with 127
    SensorIpIsApipa = 0x20000007,         ///< \~chinese 传感器IP不能为APIPA地址 \~english Sensor IP cannot be an APIPA address
    SensorIpStartsWithZero = 0x20000008,  ///< \~chinese 传感器IP不能以0开头 \~english Sensor IP cannot start with 0
    SensorIpClassDorE = 0x20000009,       ///< \~chinese 传感器IP不能为D/E类地址 \~english Sensor IP cannot be a class D/E address

    /* Settings error codes, range: 0x30000000-0x3000FFFF / 设置错误码，范围为 0x30000000-0x3000FFFF */
    SettingInvalidValue = 0x30000002,        ///< \~chinese 设置值无效 \~english Invalid setting value
    SettingRpcFailed = 0x30000003,           ///< \~chinese RPC 调用失败 \~english RPC call failed
    SettingUnsupportedPlatform = 0x30000004, ///< \~chinese 平台不支持此设置 \~english Platform does not support this setting
    SettingIpNotClassC = 0x30000005,         ///< \~chinese 相机IP非C类地址 \~english Camera IP is not a Class C address
    SettingIpStartsWith127 = 0x30000006,     ///< \~chinese 相机IP不能以127开头 \~english Camera IP cannot start with 127
    SettingIpEndsWithOne = 0x30000007,       ///< \~chinese 相机IP不能以1结尾 \~english Camera IP cannot end with 1
    SettingIpEndsWithZero = 0x30000008,      ///< \~chinese 相机IP不能以0结尾 \~english Camera IP cannot end with 0
    SettingIpEndsWith255 = 0x30000009,       ///< \~chinese 相机IP不能以255结尾 \~english Camera IP cannot end with 255
    SettingIpIsApipa = 0x3000000A,           ///< \~chinese 相机IP不能为APIPA地址 \~english Camera IP cannot be an APIPA address
    SettingIpInvalidFormat = 0x3000000B,     ///< \~chinese IP地址格式错误 \~english Invalid IP address format
    SettingIpStartsWithZero = 0x3000000C,    ///< \~chinese IP地址不能以0开头 \~english IP address cannot start with 0
    SettingIpClassDorE = 0x3000000D,         ///< \~chinese IP地址不能为D/E类地址 \~english IP address cannot be a class D/E address
};

/**
 * \~chinese @brief at_vision 错误分类（内部实现类，不导出） \~english at_vision error category; internal implementation class, not exported
 * \~chinese @details 实现自定义的 error_category，用于将 ErrorCode 转换为 std::error_code \~english Implements a custom error_category used to
 * convert ErrorCode to std::error_code
 * \~english @brief Error category for at_vision (internal implementation, not exported)
 * \~english @details Custom error_category implementation to convert ErrorCode to std::error_code
 *
 * \~chinese @note 此类不导出到 DLL 接口，用户通过 error_code_category() 函数访问 \~english This class is not exported through the DLL interface;
 * users access it through error_code_category()
 * \~english @note This class is not exported in the DLL interface, users access it via error_code_category() function
 */
class ErrorCodeCategory : public std::error_category {
public:
    /**
     * \~chinese @brief 获取错误分类的名称 \~english Gets the error category name
     * \~chinese @return 分类名称 \~english Category name
     * \~english @brief Get the name of the error category
     * \~english @return Category name
     */
    const char* name() const noexcept override { return "at_vision"; }

    /**
     * \~chinese @brief 获取错误码的描述信息 \~english Gets the description of an error code
     * \~chinese @param ev 错误码值 \~english Error code value
     * \~chinese @return 错误描述字符串 \~english Error description string
     * \~english @brief Get the description of an error code
     * \~english @param ev Error code value
     * \~english @return Error description string
     */
    std::string message(int ev) const override;

    /**
     * \~chinese @brief 获取默认错误条件 \~english Gets the default error condition
     * \~chinese @param ev 错误码值 \~english Error code value
     * \~chinese @return 错误条件 \~english Error condition
     * \~english @brief Get the default error condition
     * \~english @param ev Error code value
     * \~english @return Error condition
     */
    std::error_condition default_error_condition(int ev) const noexcept override;
};

/**
 * \~chinese @brief 获取 at_vision 错误分类的单例 \~english Gets the singleton at_vision error category
 * \~chinese @return 错误分类的引用 \~english Reference to the error category
 * \~english @brief Get the singleton instance of at_vision error category
 * \~english @return Reference to the error category
 */
AT_VISION_API const std::error_category& error_code_category() noexcept;

/**
 * \~chinese @brief 创建 at_vision 错误码 \~english Creates an at_vision error code
 * \~chinese @param e ErrorCode 枚举值 \~english ErrorCode enum value
 * \~chinese @return std::error_code 对象 \~english @return std::error_code object
 * \~english @brief Create an at_vision error code
 * \~english @param e ErrorCode enum value
 * \~english @return std::error_code object
 */
inline std::error_code make_error_code(ErrorCode e) noexcept
{
    return {static_cast<int>(e), error_code_category()};
}

} // namespace at_vision

// \~chinese 将 ErrorCode 注册为 error_code 枚举类型 / Register ErrorCode as an error_code enum type
// \~english Register ErrorCode as an error_code enumeration type
namespace std {
template <>
struct is_error_code_enum<at_vision::ErrorCode> : true_type {};
} // namespace std
